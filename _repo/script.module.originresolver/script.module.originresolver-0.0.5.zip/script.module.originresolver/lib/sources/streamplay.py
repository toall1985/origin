import re
import requests
import xbmc

domain = 'streamplay.to'
name = 'Streamplay'
sources = []

def resolve(url):
    return []


