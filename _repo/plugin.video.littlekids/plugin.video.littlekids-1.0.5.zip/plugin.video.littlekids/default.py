if 64 - 64: i11iIiiIii
if 65 - 65: O0 / iIii1I11I1II1 % OoooooooOO - i1IIi
if 73 - 73: II111iiii
if 22 - 22: I1IiiI * Oo0Ooo / OoO0O00 . OoOoOO00 . o0oOOo0O0Ooo / I1ii11iIi11i
if 48 - 48: oO0o / OOooOOo / I11i / Ii1I
if 48 - 48: iII111i % IiII + I1Ii111 / ooOoO0o * Ii1I
if 46 - 46: ooOoO0o * I11i - OoooooooOO
if 30 - 30: o0oOOo0O0Ooo - O0 % o0oOOo0O0Ooo - OoooooooOO * O0 * OoooooooOO
if 60 - 60: iIii1I11I1II1 / i1IIi * oO0o - I1ii11iIi11i + o0oOOo0O0Ooo
if 94 - 94: i1IIi % Oo0Ooo
if 68 - 68: Ii1I / O0
if 46 - 46: O0 * II111iiii / IiII * Oo0Ooo * iII111i . I11i
if 62 - 62: i11iIiiIii - II111iiii % I1Ii111 - iIii1I11I1II1 . I1ii11iIi11i . II111iiii
if 61 - 61: oO0o / OoOoOO00 / iII111i * OoO0O00 . II111iiii
if 1 - 1: II111iiii - I1ii11iIi11i % i11iIiiIii + IiII . I1Ii111
if 55 - 55: iIii1I11I1II1 - I1IiiI . Ii1I * IiII * i1IIi / iIii1I11I1II1
import sys
import urlparse
import urllib , urllib2 , datetime , re , os , base64 , xbmc , xbmcplugin , xbmcgui , xbmcaddon , xbmcvfs , traceback , cookielib , urlparse , httplib , time
import urlresolver
import time
from datetime import datetime
import yt
if 79 - 79: oO0o + I1Ii111 . ooOoO0o * IiII % I11i . I1IiiI
O0o0o00o0Oo0 = xbmcgui . Dialog ( )
ii11 = base64 . decodestring
I1I1i1 = ii11 ( 'LnBocA==' )
IiI1i = ( ii11 ( 'aHR0cDovL3NlZWR1cmdyZWVkLngxMGhvc3QuY29tL29yaWdpbi8=' ) )
OOo0o0 = 'plugin.video.littlekids'
O0OoOoo00o = sys . argv [ 0 ]
iiiI11 = int ( sys . argv [ 1 ] )
OOooO = urlparse . parse_qs ( sys . argv [ 2 ] [ 1 : ] )
OOoO00o = "Big Kids"
II111iiiiII = "1.0.1"
oOoOo00oOo = 'Mozilla/5.0 (Windows NT 6.1; WOW64; Trident/7.0; AS; rv:11.0) like Gecko'
Oo = 'Mozilla/5.0 (Windows NT 6.3; rv:36.0) Gecko/20100101 Firefox/36.0'
o00O00O0O0O = 'Mozilla/5.0 (iPhone; CPU iPhone OS 6_0 like Mac OS X) AppleWebKit/536.26 (KHTML, like Gecko) Version/6.0 Mobile/10A5376e Safari/8536.25'
OooO0OO = 'Mozilla/5.0 (Linux; Android 4.4.2; Nexus 4 Build/KOT49H) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/34.0.1847.114 Mobile Safari/537.36'
iiiIi = 'true'
IiIIIiI1I1 = [ 'americandad!' , 'familyguy' ]
if 86 - 86: i11iIiiIii + Ii1I + ooOoO0o * I11i + o0oOOo0O0Ooo
oOoO = xbmc . translatePath ( os . path . join ( 'special://home' , 'addons' , '' ) )
oOo = os . path . join ( oOoO , OOo0o0 , 'resources' , 'art' ) + os . sep
oOoOoO = xbmc . translatePath ( os . path . join ( oOoO , OOo0o0 , 'fanart.jpg' ) )
ii1I = oOo + 'icon.png'
OooO0 = ii11 ( 'aHR0cDovL3d3dy5hbmltZXRvb24ub3JnL2NhcnRvb24=' )
if 35 - 35: OOooOOo % I1Ii111 % i11iIiiIii / OoooooooOO
def Ii11iI1i ( ) :
 if 82 - 82: i11iIiiIii . OOooOOo / Oo0Ooo * O0 % oO0o % iIii1I11I1II1
 Oo00OOOOO ( 'Classics' , '' , 6 , ii1I , oOoOoO , '' )
 Oo00OOOOO ( 'Cartoons' , '' , 1 , ii1I , oOoOoO , '' )
 Oo00OOOOO ( 'Search Cartoons' , '' , 2 , ii1I , oOoOoO , '' )
 if 85 - 85: ooOoO0o . iII111i - OoO0O00 % ooOoO0o % II111iiii
def OO0o00o ( ) :
 oOOo0oo = O0o0o00o0Oo0 . input ( 'Search' , type = xbmcgui . INPUT_ALPHANUM )
 o0oo0o0O00OO = oOOo0oo . lower ( )
 o0oO = I1i1iii ( OooO0 )
 i1iiI11I = re . compile ( '<td><a href="(.+?)">(.+)</a></td>' ) . findall ( o0oO )
 for iiii , oO0o0O0OOOoo0 in i1iiI11I :
  if oOOo0oo in oO0o0O0OOOoo0 . lower ( ) :
   if 'Dad!' in oO0o0O0OOOoo0 :
    pass
   elif 'Family Guy' in oO0o0O0OOOoo0 :
    pass
   elif '2 Stupid' in oO0o0O0OOOoo0 :
    pass
   elif 'The Zelfs' in oO0o0O0OOOoo0 :
    pass
   elif 'A Clone' in oO0o0O0OOOoo0 :
    pass
   elif 'A.T.O.M' in oO0o0O0OOOoo0 :
    pass
   elif 'Almost Naked' in oO0o0O0OOOoo0 :
    pass
   elif 'Angry Kid' in oO0o0O0OOOoo0 :
    pass
   elif 'Annoying Orange' in oO0o0O0OOOoo0 :
    pass
   elif 'Aqua Teen' in oO0o0O0OOOoo0 :
    pass
   elif 'Assy Mcgee' in oO0o0O0OOOoo0 :
    pass
   elif 'Astroblast' in oO0o0O0OOOoo0 :
    pass
   elif 'Atomic Betty' in oO0o0O0OOOoo0 :
    pass
   elif 'Axe Cop' in oO0o0O0OOOoo0 :
    pass
   elif 'Baby Playpen' in oO0o0O0OOOoo0 :
    pass
   elif 'Beavis and Butt' in oO0o0O0OOOoo0 :
    pass
   elif 'Celebrity Deathmatch' in oO0o0O0OOOoo0 :
    pass
   elif 'Clerks The' in oO0o0O0OOOoo0 :
    pass
   elif 'Crapston Villas' in oO0o0O0OOOoo0 :
    pass
   elif 'Duckman:' in oO0o0O0OOOoo0 :
    pass
   elif 'Stripperella' in oO0o0O0OOOoo0 :
    pass
   elif 'Vixen' in oO0o0O0OOOoo0 :
    pass
   else :
    Oo00OOOOO ( oO0o0O0OOOoo0 , iiii , 3 , ii1I , oOoOoO , '' )
  xbmcplugin . addSortMethod ( iiiI11 , xbmcplugin . SORT_METHOD_TITLE ) ;
  if 48 - 48: O0 + O0 - I1ii11iIi11i . ooOoO0o / iIii1I11I1II1
def OoOOO00oOO0 ( ) :
 oOoo = I1i1iii ( OooO0 )
 i1iiI11I = re . compile ( '<td><a href="(.+?)">(.+)</a></td>' ) . findall ( oOoo )
 for iiii , oO0o0O0OOOoo0 in i1iiI11I :
  if 'Dad!' in oO0o0O0OOOoo0 :
   pass
  elif 'Family Guy' in oO0o0O0OOOoo0 :
   pass
  elif '2 Stupid' in oO0o0O0OOOoo0 :
   pass
  elif 'The Zelfs' in oO0o0O0OOOoo0 :
   pass
  elif 'A Clone' in oO0o0O0OOOoo0 :
   pass
  elif 'A.T.O.M' in oO0o0O0OOOoo0 :
   pass
  elif 'Almost Naked' in oO0o0O0OOOoo0 :
   pass
  elif 'Angry Kid' in oO0o0O0OOOoo0 :
   pass
  elif 'Annoying Orange' in oO0o0O0OOOoo0 :
   pass
  elif 'Aqua Teen' in oO0o0O0OOOoo0 :
   pass
  elif 'Assy Mcgee' in oO0o0O0OOOoo0 :
   pass
  elif 'Astroblast' in oO0o0O0OOOoo0 :
   pass
  elif 'Atomic Betty' in oO0o0O0OOOoo0 :
   pass
  elif 'Axe Cop' in oO0o0O0OOOoo0 :
   pass
  elif 'Baby Playpen' in oO0o0O0OOOoo0 :
   pass
  elif 'Beavis and Butt' in oO0o0O0OOOoo0 :
   pass
  elif 'Celebrity Deathmatch' in oO0o0O0OOOoo0 :
   pass
  elif 'Clerks The' in oO0o0O0OOOoo0 :
   pass
  elif 'Crapston Villas' in oO0o0O0OOOoo0 :
   pass
  elif 'Duckman:' in oO0o0O0OOOoo0 :
   pass
  elif 'Stripperella' in oO0o0O0OOOoo0 :
   pass
  elif 'Vixen' in oO0o0O0OOOoo0 :
   pass
  else :
   Oo00OOOOO ( oO0o0O0OOOoo0 , iiii , 3 , ii1I , oOoOoO , '' )
 xbmcplugin . addSortMethod ( iiiI11 , xbmcplugin . SORT_METHOD_TITLE ) ;
 if 8 - 8: OoOoOO00
def o00O ( url ) :
 oOoo = I1i1iii ( url )
 OOO0OOO00oo = re . compile ( '<img src="(.+?)" id="series_image" width="250" height="370" alt=".+?" />' ) . findall ( oOoo )
 for Iii111II in OOO0OOO00oo :
  iiii11I = Iii111II
 Ooo0OO0oOO = re . compile ( '<li><a href="(.+?)">Next</a></li>' ) . findall ( oOoo )
 for url in Ooo0OO0oOO :
  Oo00OOOOO ( 'NEXT PAGE' , url , 4 , iiii11I , oOoOoO , '' )
 i1iiI11I = re . compile ( '&nbsp;<a href="(.+?)">(.+?)</a>' ) . findall ( oOoo )
 for url , oO0o0O0OOOoo0 in i1iiI11I :
  ii11i1 ( oO0o0O0OOOoo0 , url , 4 , iiii11I , oOoOoO , '' )
  if 29 - 29: I1ii11iIi11i % I1IiiI + ooOoO0o / o0oOOo0O0Ooo + OOooOOo * o0oOOo0O0Ooo
  if 42 - 42: Ii1I + oO0o
 xbmcplugin . addSortMethod ( iiiI11 , xbmcplugin . SORT_METHOD_TITLE ) ;
 if 76 - 76: I1Ii111 - OoO0O00
def oOooOOo00Oo0O ( url , IMAGE ) :
 oOoo = I1i1iii ( url )
 i1iiI11I = re . compile ( '"playlist">(.+?)</span></div><div><iframe src="(.+?)"' ) . findall ( oOoo )
 for oO0o0O0OOOoo0 , url in i1iiI11I :
  print oO0o0O0OOOoo0 + '     ' + url
  if 'easy' in url :
   O00oO ( url )
   if 39 - 39: IiII - II111iiii * OoO0O00 % o0oOOo0O0Ooo * II111iiii % II111iiii
   if 59 - 59: iIii1I11I1II1 + I1IiiI - o0oOOo0O0Ooo - I1IiiI + OOooOOo / I1ii11iIi11i
  xbmcplugin . addSortMethod ( iiiI11 , xbmcplugin . SORT_METHOD_TITLE ) ;
  if 24 - 24: I11i . iII111i % OOooOOo + ooOoO0o % OoOoOO00
def O00oO ( url ) :
 oOoo = I1i1iii ( url )
 i1iiI11I = re . compile ( "url: '(.+?)'," ) . findall ( oOoo )
 for url in i1iiI11I :
  I11III1II ( url )
  if 16 - 16: I1IiiI * oO0o % IiII
def Oo000o ( ) :
 oOoo = I1i1iii ( ii11 ( 'aHR0cDovL3d3dy50b29uamV0LmNvbS8=' ) )
 i1iiI11I = re . compile ( '<a href="(.+?)" style="font-size:.8em;">(.+?)</a>' ) . findall ( oOoo )
 for iiii , oO0o0O0OOOoo0 in i1iiI11I :
  Oo00OOOOO ( oO0o0O0OOOoo0 , ii11 ( 'aHR0cDovL3d3dy50b29uamV0LmNvbS8=' ) + iiii , 7 , ii1I , oOoOoO , '' )
  if 7 - 7: ooOoO0o * OoO0O00 % oO0o . IiII
def Ii1iIiII1ii1 ( url ) :
 oOoo = I1i1iii ( url )
 i1iiI11I = re . compile ( '<a href="(.+?)"><img src="(.+?)"' ) . findall ( oOoo )
 OOO0OOO00oo = re . compile ( '<a href="(.+?)">.+?</a></td></tr></table>' ) . findall ( oOoo )
 for url , Iii111II in i1iiI11I :
  if 'ol.gif' in Iii111II :
   pass
  elif 'link_block_' in Iii111II :
   pass
  elif '.png' in Iii111II :
   pass
  elif 'images/Dinky' in Iii111II :
   pass
  else :
   ii11i1 ( ( Iii111II ) . replace ( ii11 ( 'aHR0cDovL3d3dy50b29uamV0LmNvbS9pbWFnZXMvaWNvbnMv' ) , '' ) . replace ( 'images/icons/' , '' ) . replace ( '.jpg' , '' ) . replace ( '_icon' , '' ) . replace ( '_' , ' ' ) , ii11 ( 'aHR0cDovL3d3dy50b29uamV0LmNvbS8=' ) + url , 8 , Iii111II , oOoOoO , '' )
 for url in OOO0OOO00oo :
  Oo00OOOOO ( 'NEXT PAGE' , ii11 ( 'aHR0cDovL3d3dy50b29uamV0LmNvbS8=' ) + url , 7 , ii1I , oOoOoO , '' )
  if 62 - 62: iIii1I11I1II1 * OoOoOO00
def i1 ( url ) :
 oOoo = I1i1iii ( url )
 i1iiI11I = re . compile ( '<iframe width="640" height="480" src="(.+?)" frameborder="0" allowfullscreen></iframe>' ) . findall ( oOoo )
 for url in i1iiI11I :
  OOO = ( url ) . replace ( 'http://www.youtube.com/embed/' , '' ) . replace ( '?autoplay=0' , '' )
  print '<<<<<<<<<<<<<<<<<<<<<<<<<<<<<' + OOO + '>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>'
  yt . PlayVideo ( OOO )
  if 59 - 59: II111iiii + OoooooooOO * OoOoOO00 + i1IIi
  if 58 - 58: II111iiii * OOooOOo * I1ii11iIi11i / OOooOOo
def ii11i1 ( name , url , mode , iconimage , fanart , description ) :
 if 75 - 75: oO0o
 I1III = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage ) + "&fanart=" + urllib . quote_plus ( fanart ) + "&description=" + urllib . quote_plus ( description )
 OO0O0OoOO0 = True
 iiiI1I11i1 = xbmcgui . ListItem ( name , iconImage = "DefaultFolder.png" , thumbnailImage = iconimage )
 iiiI1I11i1 . setInfo ( type = "Video" , infoLabels = { "Title" : name , "Plot" : description } )
 iiiI1I11i1 . setProperty ( "Fanart_Image" , fanart )
 OO0O0OoOO0 = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = I1III , listitem = iiiI1I11i1 , isFolder = False )
 return OO0O0OoOO0
 if 49 - 49: I1IiiI % ooOoO0o . ooOoO0o . I11i * ooOoO0o
def Oo00OOOOO ( name , url , mode , iconimage , fanart , description ) :
 if 97 - 97: Ii1I + o0oOOo0O0Ooo . OOooOOo + I1ii11iIi11i % iII111i
 I1III = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage ) + "&fanart=" + urllib . quote_plus ( fanart ) + "&description=" + urllib . quote_plus ( description )
 OO0O0OoOO0 = True
 iiiI1I11i1 = xbmcgui . ListItem ( name , iconImage = "DefaultFolder.png" , thumbnailImage = iconimage )
 iiiI1I11i1 . setInfo ( type = "Video" , infoLabels = { "Title" : name , "Plot" : description } )
 iiiI1I11i1 . setProperty ( "Fanart_Image" , fanart )
 OO0O0OoOO0 = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = I1III , listitem = iiiI1I11i1 , isFolder = True )
 return OO0O0OoOO0
 if 95 - 95: i1IIi
def I1ii11iI ( ) :
 try :
  IIi1i = getSet ( "core-player" )
  if ( IIi1i == 'DVDPLAYER' ) : I1I1iIiII1 = xbmc . PLAYER_CORE_DVDPLAYER
  elif ( IIi1i == 'MPLAYER' ) : I1I1iIiII1 = xbmc . PLAYER_CORE_MPLAYER
  elif ( IIi1i == 'PAPLAYER' ) : I1I1iIiII1 = xbmc . PLAYER_CORE_PAPLAYER
  else : I1I1iIiII1 = xbmc . PLAYER_CORE_AUTO
 except : I1I1iIiII1 = xbmc . PLAYER_CORE_AUTO
 return I1I1iIiII1
 return True
 if 4 - 4: ooOoO0o + O0 * OOooOOo
 if 55 - 55: Oo0Ooo + iIii1I11I1II1 / OoOoOO00 * oO0o - i11iIiiIii - Ii1I
def ii1ii1ii ( ) :
 oooooOoo0ooo = [ ]
 I1I1IiI1 = sys . argv [ 2 ]
 if len ( I1I1IiI1 ) >= 2 :
  III1iII1I1ii = sys . argv [ 2 ]
  oOOo0 = III1iII1I1ii . replace ( '?' , '' )
  if ( III1iII1I1ii [ len ( III1iII1I1ii ) - 1 ] == '/' ) :
   III1iII1I1ii = III1iII1I1ii [ 0 : len ( III1iII1I1ii ) - 2 ]
  oo00O00oO = oOOo0 . split ( '&' )
  oooooOoo0ooo = { }
  for iIiIIIi in range ( len ( oo00O00oO ) ) :
   ooo00OOOooO = { }
   ooo00OOOooO = oo00O00oO [ iIiIIIi ] . split ( '=' )
   if ( len ( ooo00OOOooO ) ) == 2 :
    oooooOoo0ooo [ ooo00OOOooO [ 0 ] ] = ooo00OOOooO [ 1 ]
    if 67 - 67: I11i * oO0o * I1ii11iIi11i + OOooOOo / i1IIi
 return oooooOoo0ooo
 if 11 - 11: Ii1I + iII111i - ooOoO0o * oO0o % i11iIiiIii - I1Ii111
III1iII1I1ii = ii1ii1ii ( )
iiii = None
oO0o0O0OOOoo0 = None
o0oOIIiIi1iI = None
i1IiiiI1iI = None
i1iIi = None
if 68 - 68: i11iIiiIii % I1ii11iIi11i + i11iIiiIii
if 31 - 31: II111iiii . I1IiiI
try :
 iiii = urllib . unquote_plus ( III1iII1I1ii [ "url" ] )
except :
 pass
try :
 oO0o0O0OOOoo0 = urllib . unquote_plus ( III1iII1I1ii [ "name" ] )
except :
 pass
try :
 o0oOIIiIi1iI = urllib . unquote_plus ( III1iII1I1ii [ "iconimage" ] )
except :
 pass
try :
 i1IiiiI1iI = int ( III1iII1I1ii [ "mode" ] )
except :
 pass
try :
 II1I = urllib . unquote_plus ( III1iII1I1ii [ "fanart" ] )
except :
 pass
try :
 i1iIi = urllib . unquote_plus ( III1iII1I1ii [ "description" ] )
except :
 pass
 if 84 - 84: IiII . i11iIiiIii . IiII * I1ii11iIi11i - I11i
 if 42 - 42: i11iIiiIii
print str ( OOoO00o ) + ': ' + str ( II111iiiiII )
print "Mode: " + str ( i1IiiiI1iI )
print "URL: " + str ( iiii )
print "Name: " + str ( oO0o0O0OOOoo0 )
print "IconImage: " + str ( o0oOIIiIi1iI )
if 33 - 33: iII111i - O0 * i1IIi * o0oOOo0O0Ooo - Oo0Ooo
def I11III1II ( url ) :
 iiIiI = xbmc . Player ( I1ii11iI ( ) )
 import urlresolver
 try : iiIiI . play ( url )
 except : pass
 if 91 - 91: iII111i % i1IIi % iIii1I11I1II1
def I1i1iii ( url ) :
 IIi1I11I1II = urllib2 . Request ( url )
 oOoOo00oOo = 'Mozilla/5.0 (Windows NT 6.1; WOW64; Trident/7.0; AS; rv:11.0) like Gecko'
 Oo = 'Mozilla/5.0 (Windows NT 6.3; rv:36.0) Gecko/20100101 Firefox/36.0'
 o00O00O0O0O = 'Mozilla/5.0 (iPhone; CPU iPhone OS 6_0 like Mac OS X) AppleWebKit/536.26 (KHTML, like Gecko) Version/6.0 Mobile/10A5376e Safari/8536.25'
 OooO0OO = 'Mozilla/5.0 (Linux; Android 4.4.2; Nexus 4 Build/KOT49H) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/34.0.1847.114 Mobile Safari/537.36'
 IIi1I11I1II . add_header ( 'User-Agent' , 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3' )
 OooOoooOo = urllib2 . urlopen ( IIi1I11I1II )
 ii11IIII11I = OooOoooOo . read ( )
 OooOoooOo . close ( )
 return ii11IIII11I
 if 81 - 81: OoOoOO00 / O0 . IiII . I1IiiI
def OoOO ( content , viewType ) :
 if content :
  xbmcplugin . setContent ( int ( sys . argv [ 1 ] ) , content )
  if 53 - 53: Oo0Ooo
  if 29 - 29: I1ii11iIi11i + oO0o % O0
if i1IiiiI1iI == None : Ii11iI1i ( )
elif i1IiiiI1iI == 1 : OoOOO00oOO0 ( )
elif i1IiiiI1iI == 2 : OO0o00o ( )
elif i1IiiiI1iI == 3 : o00O ( iiii )
elif i1IiiiI1iI == 4 : oOooOOo00Oo0O ( iiii , o0oOIIiIi1iI )
elif i1IiiiI1iI == 5 : I11III1II ( iiii )
elif i1IiiiI1iI == 6 : Oo000o ( )
elif i1IiiiI1iI == 7 : Ii1iIiII1ii1 ( iiii )
elif i1IiiiI1iI == 8 : i1 ( iiii )
if 10 - 10: I11i / I1Ii111 - I1IiiI * iIii1I11I1II1 - I1IiiI
xbmcplugin . endOfDirectory ( int ( sys . argv [ 1 ] ) )
# dd678faae9ac167bc83abf78e5cb2f3f0688d3a3
