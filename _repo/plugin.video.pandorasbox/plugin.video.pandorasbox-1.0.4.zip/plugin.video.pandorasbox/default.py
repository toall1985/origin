if 64 - 64: i11iIiiIii
if 65 - 65: O0 / iIii1I11I1II1 % OoooooooOO - i1IIi
if 73 - 73: II111iiii
if 22 - 22: I1IiiI * Oo0Ooo / OoO0O00 . OoOoOO00 . o0oOOo0O0Ooo / I1ii11iIi11i
if 48 - 48: oO0o / OOooOOo / I11i / Ii1I
if 48 - 48: iII111i % IiII + I1Ii111 / ooOoO0o * Ii1I
if 46 - 46: ooOoO0o * I11i - OoooooooOO
if 30 - 30: o0oOOo0O0Ooo - O0 % o0oOOo0O0Ooo - OoooooooOO * O0 * OoooooooOO
if 60 - 60: iIii1I11I1II1 / i1IIi * oO0o - I1ii11iIi11i + o0oOOo0O0Ooo
if 94 - 94: i1IIi % Oo0Ooo
if 68 - 68: Ii1I / O0
if 46 - 46: O0 * II111iiii / IiII * Oo0Ooo * iII111i . I11i
if 62 - 62: i11iIiiIii - II111iiii % I1Ii111 - iIii1I11I1II1 . I1ii11iIi11i . II111iiii
if 61 - 61: oO0o / OoOoOO00 / iII111i * OoO0O00 . II111iiii
if 1 - 1: II111iiii - I1ii11iIi11i % i11iIiiIii + IiII . I1Ii111
if 55 - 55: iIii1I11I1II1 - I1IiiI . Ii1I * IiII * i1IIi / iIii1I11I1II1
import sys
import urlparse
import urllib , urllib2 , datetime , re , os , base64 , xbmc , xbmcplugin , xbmcgui , xbmcaddon , xbmcvfs , traceback , cookielib , urlparse , httplib , time
import urlresolver
import time
from t0mm0 . common . addon import Addon
from t0mm0 . common . net import Net
from datetime import datetime
if 79 - 79: oO0o + I1Ii111 . ooOoO0o * IiII % I11i . I1IiiI
O0o0o00o0Oo0 = xbmcgui . Dialog ( )
ii11 = base64 . decodestring
I1I1i1 = ii11 ( 'LnBocA==' )
IiI1i = ( ii11 ( 'aHR0cDovL3NlZWR1cmdyZWVkLngxMGhvc3QuY29tL29yaWdpbi8=' ) )
OOo0o0 = 'plugin.video.pandorasbox'
O0OoOoo00o = sys . argv [ 0 ]
iiiI11 = int ( sys . argv [ 1 ] )
OOooO = urlparse . parse_qs ( sys . argv [ 2 ] [ 1 : ] )
OOoO00o = "Pandoras Box"
II111iiiiII = "1.0.1"
oOoOo00oOo = 'Mozilla/5.0 (Windows NT 6.1; WOW64; Trident/7.0; AS; rv:11.0) like Gecko'
Oo = 'Mozilla/5.0 (Windows NT 6.3; rv:36.0) Gecko/20100101 Firefox/36.0'
o00O00O0O0O = 'Mozilla/5.0 (iPhone; CPU iPhone OS 6_0 like Mac OS X) AppleWebKit/536.26 (KHTML, like Gecko) Version/6.0 Mobile/10A5376e Safari/8536.25'
OooO0OO = 'Mozilla/5.0 (Linux; Android 4.4.2; Nexus 4 Build/KOT49H) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/34.0.1847.114 Mobile Safari/537.36'
if 28 - 28: II111iiii
iii11iII = xbmc . translatePath ( os . path . join ( 'special://home' , 'addons' , '' ) )
i1I111I = os . path . join ( iii11iII , OOo0o0 , 'resources' , 'art' ) + os . sep
i11I1IIiiIi = xbmc . translatePath ( os . path . join ( iii11iII , OOo0o0 , 'fanart.jpg' ) )
if 34 - 34: OoooooooOO + iIii1I11I1II1 + i11iIiiIii - I1ii11iIi11i + i11iIiiIii
if 65 - 65: OoOoOO00
if 6 - 6: I1IiiI / Oo0Ooo % Ii1I
def oo ( ) :
 if 54 - 54: OOooOOo + OOooOOo % I1Ii111 % i11iIiiIii / iIii1I11I1II1 . OOooOOo
 o0oO0o00oo ( 'Open Pandora\'s Box' , '' , 400 , i1I111I + 'icon.png' , i1I111I + 'fanart.jpg' , '' )
 o0oO0o00oo ( 'Search' , '' , 1 , i1I111I + 'icon.png' , i1I111I + 'fanart.jpg' , '' )
 if 32 - 32: Oo0Ooo * O0 % oO0o % Ii1I . IiII
 xbmcplugin . setContent ( iiiI11 , 'movies' )
 if 61 - 61: ooOoO0o
def oOOO00o ( ) :
 o0oO0o00oo ( 'Search Pandoras Films' , '' , 424 , i1I111I + 'icon.png' , i1I111I + 'fanart.jpg' , '' )
 o0oO0o00oo ( 'Search Pandoras TV' , '' , 425 , i1I111I + 'icon.png' , i1I111I + 'fanart.jpg' , '' )
 if 97 - 97: I11i % I11i + II111iiii * iII111i
 xbmcplugin . setContent ( iiiI11 , 'movies' )
 if 54 - 54: I11i + IiII / iII111i
 if 9 - 9: OoOoOO00 / Oo0Ooo - IiII . i1IIi / I1IiiI % IiII
def o0 ( ) :
 if 9 - 9: Ii1I + oO0o % Ii1I + i1IIi . OOooOOo
 III1i1i = iiI1 ( ii11 ( 'aHR0cDovL3NlZWR1cmdyZWVkLngxMGhvc3QuY29tL29yaWdpbi9zcG9uZ2VtYWluLnBocA==' ) )
 i11Iiii = re . compile ( '<item>.+?<title>(.+?)</title>.+?<description>(.+?)</description>.+?<link>(.+?)</link>.+?<thumbnail>(.+?)</thumbnail>.+?<fanart>(.+?)</fanart>.+?<mode>(.+?)</mode>.+?</item>' , re . DOTALL ) . findall ( III1i1i )
 for iI , I1i1I1II , i1 , IiIiiI , I1I , oOO00oOO in i11Iiii :
  o0oO0o00oo ( iI , i1 , oOO00oOO , IiIiiI , I1I , I1i1I1II )
  if 75 - 75: i1IIi / OoooooooOO - O0 / OoOoOO00 . II111iiii - i1IIi
 xbmcplugin . setContent ( iiiI11 , 'movies' )
 if 71 - 71: OOooOOo + Ii1I * OOooOOo - OoO0O00 * o0oOOo0O0Ooo
 if 65 - 65: O0 % I1IiiI . I1ii11iIi11i % iIii1I11I1II1 / OOooOOo % I1Ii111
def ooii11I ( url ) :
 if 96 - 96: II111iiii % Ii1I . OOooOOo + OoooooooOO * oO0o - OoOoOO00
 xbmcplugin . addSortMethod ( handle = int ( sys . argv [ 1 ] ) , sortMethod = xbmcplugin . SORT_METHOD_TITLE )
 i11i1 = iiI1 ( url )
 i11Iiii = re . compile ( '<a href="(.+?)" target="_blank"><img src="(.+?)" style="max-width:200px;" /><description = "(.+?)" /><background = "(.+?)" </background></a><br><b>(.+?)</b>' ) . findall ( i11i1 )
 for url , IIIii1II1II , I1i1I1II , i1I1iI , iI in i11Iiii :
  oo0OooOOo0 ( iI , url , 401 , IIIii1II1II , i1I1iI , I1i1I1II )
  if 92 - 92: iII111i . I11i + o0oOOo0O0Ooo
  xbmcplugin . setContent ( iiiI11 , 'movies' )
  xbmcplugin . addSortMethod ( iiiI11 , xbmcplugin . SORT_METHOD_TITLE ) ;
  if 28 - 28: i1IIi * Oo0Ooo - o0oOOo0O0Ooo * IiII * Ii1I / OoO0O00
def OooO0OoOOOO ( ) :
 if 46 - 46: OOooOOo / I1ii11iIi11i
 I1 = O0o0o00o0Oo0 . input ( 'Search' , type = xbmcgui . INPUT_ALPHANUM )
 OO00Oo = I1 . lower ( )
 O0OOO0OOoO0O = [ 'mova' , 'movb' , 'movc' , 'movd' , 'move' , 'movf' , 'movg' , 'movh' , 'movi' , 'movj' , 'movk' , 'movl' , 'movm' , 'movn' , 'movo' , 'movp' , 'movq' , 'movr' , 'movs' , 'movt' , 'movu' , 'movv' , 'movw' , 'movx' , 'movy' , 'movz' ]
 if 70 - 70: IiII * Oo0Ooo * I11i / Ii1I
 for oO in O0OOO0OOoO0O :
  OOoO0O00o0 = IiI1i + oO + I1I1i1
  iII = iiI1 ( OOoO0O00o0 )
  i11Iiii = re . compile ( '<a href="(.+?)" target="_blank"><img src="(.+?)" style="max-width:200px;" /><description = "(.+?)" /><background = "(.+?)" </background></a><br><b>(.+?)</b>' ) . findall ( iII )
  for i1 , IIIii1II1II , I1i1I1II , I1I , iI in i11Iiii :
   if I1 in iI . lower ( ) :
    oo0OooOOo0 ( iI , i1 , 401 , IIIii1II1II , I1I , I1i1I1II )
    if 80 - 80: IiII . oO0o
    xbmcplugin . setContent ( iiiI11 , 'movies' )
    xbmcplugin . addSortMethod ( iiiI11 , xbmcplugin . SORT_METHOD_TITLE ) ;
    if 25 - 25: OoOoOO00 . II111iiii / iII111i . OOooOOo * OoO0O00 . I1IiiI
    if 59 - 59: II111iiii + OoooooooOO * OoOoOO00 + i1IIi
def Oo0OoO00oOO0o ( ) :
 if 80 - 80: oO0o + OOooOOo - OOooOOo % iII111i
 I1 = O0o0o00o0Oo0 . input ( 'Search' , type = xbmcgui . INPUT_ALPHANUM )
 OO00Oo = I1 . lower ( )
 O0OOO0OOoO0O = [ 'a' , 'b' , 'c' , 'd' , 'e' , 'f' , 'g' , 'h' , 'i' , 'j' , 'k' , 'l' , 'm' , 'n' , 'o' , 'p' , 'q' , 'r' , 's' , 't' , 'u' , 'v' , 'w' , 'x' , 'y' , 'z' ]
 if 63 - 63: I1IiiI - I1ii11iIi11i + O0 % I11i / iIii1I11I1II1 / o0oOOo0O0Ooo
 for oO in O0OOO0OOoO0O :
  O0o0O00Oo0o0 = IiI1i + oO + I1I1i1
  iII = iiI1 ( O0o0O00Oo0o0 )
  i11Iiii = re . compile ( '<item>.+?<title>(.+?)</title>.+?<description>(.+?)</description>.+?<link>(.+?)</link>.+?<thumbnail>(.+?)</thumbnail>.+?<fanart>(.+?)</fanart>.+?<mode>(.+?)</mode>.+?</item>' , re . DOTALL ) . findall ( iII )
  for iI , I1i1I1II , i1 , IiIiiI , I1I , oOO00oOO in i11Iiii :
   if I1 in iI . lower ( ) :
    o0oO0o00oo ( iI , i1 , oOO00oOO , IiIiiI , I1I , I1i1I1II )
    if 87 - 87: ooOoO0o * Oo0Ooo % i11iIiiIii % OoOoOO00 - OOooOOo
    xbmcplugin . setContent ( iiiI11 , 'movies' )
    xbmcplugin . addSortMethod ( iiiI11 , xbmcplugin . SORT_METHOD_TITLE ) ;
    if 68 - 68: I1Ii111 % i1IIi . IiII . I1ii11iIi11i
    if 92 - 92: iII111i . I1Ii111
def i1i ( url ) :
 if 50 - 50: IiII
 III1i1i = iiI1 ( url )
 i11Iiii = re . compile ( '<item>.+?<title>(.+?)</title>.+?<description>(.+?)</description>.+?<link>(.+?)</link>.+?<thumbnail>(.+?)</thumbnail>.+?<fanart>(.+?)</fanart>.+?<mode>(.+?)</mode>.+?</item>' , re . DOTALL ) . findall ( III1i1i )
 for iI , I1i1I1II , url , IiIiiI , I1I , oOO00oOO in i11Iiii :
  o0oO0o00oo ( iI , url , oOO00oOO , IiIiiI , I1I , I1i1I1II )
  if 14 - 14: I11i % OoO0O00 * I11i
  xbmcplugin . setContent ( iiiI11 , 'movies' )
  xbmcplugin . addSortMethod ( iiiI11 , xbmcplugin . SORT_METHOD_TITLE ) ;
  if 16 - 16: OoOoOO00 . ooOoO0o + i11iIiiIii
def oo0OooOOo0 ( name , url , mode , iconimage , fanart , description ) :
 if 38 - 38: IiII * OOooOOo . o0oOOo0O0Ooo
 ooo0OO = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage ) + "&fanart=" + urllib . quote_plus ( fanart ) + "&description=" + urllib . quote_plus ( description )
 O0ii1ii1ii = True
 oooooOoo0ooo = xbmcgui . ListItem ( name , iconImage = "DefaultFolder.png" , thumbnailImage = iconimage )
 oooooOoo0ooo . setInfo ( type = "Video" , infoLabels = { "Title" : name , "Plot" : description } )
 oooooOoo0ooo . setProperty ( "Fanart_Image" , fanart )
 O0ii1ii1ii = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = ooo0OO , listitem = oooooOoo0ooo , isFolder = False )
 return O0ii1ii1ii
 if 6 - 6: I11i - Ii1I + iIii1I11I1II1 - I1Ii111 - i11iIiiIii
def o0oO0o00oo ( name , url , mode , iconimage , fanart , description ) :
 if 79 - 79: OoOoOO00 - O0 * OoO0O00 + OoOoOO00 % O0 * O0
 ooo0OO = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage ) + "&fanart=" + urllib . quote_plus ( fanart ) + "&description=" + urllib . quote_plus ( description )
 O0ii1ii1ii = True
 oooooOoo0ooo = xbmcgui . ListItem ( name , iconImage = "DefaultFolder.png" , thumbnailImage = iconimage )
 oooooOoo0ooo . setInfo ( type = "Video" , infoLabels = { "Title" : name , "Plot" : description } )
 oooooOoo0ooo . setProperty ( "Fanart_Image" , fanart )
 O0ii1ii1ii = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = ooo0OO , listitem = oooooOoo0ooo , isFolder = True )
 return O0ii1ii1ii
 if 61 - 61: II111iiii
 if 64 - 64: ooOoO0o / OoOoOO00 - O0 - I11i
def O0oOoOOOoOO ( ) :
 ii1ii11IIIiiI = [ ]
 O00OOOoOoo0O = sys . argv [ 2 ]
 if len ( O00OOOoOoo0O ) >= 2 :
  O000OOo00oo = sys . argv [ 2 ]
  oo0OOo = O000OOo00oo . replace ( '?' , '' )
  if ( O000OOo00oo [ len ( O000OOo00oo ) - 1 ] == '/' ) :
   O000OOo00oo = O000OOo00oo [ 0 : len ( O000OOo00oo ) - 2 ]
  ooOOO00Ooo = oo0OOo . split ( '&' )
  ii1ii11IIIiiI = { }
  for IiIIIi1iIi in range ( len ( ooOOO00Ooo ) ) :
   ooOOoooooo = { }
   ooOOoooooo = ooOOO00Ooo [ IiIIIi1iIi ] . split ( '=' )
   if ( len ( ooOOoooooo ) ) == 2 :
    ii1ii11IIIiiI [ ooOOoooooo [ 0 ] ] = ooOOoooooo [ 1 ]
    if 1 - 1: Oo0Ooo / o0oOOo0O0Ooo % iII111i * IiII . i11iIiiIii
 return ii1ii11IIIiiI
 if 2 - 2: I1ii11iIi11i * I11i - iIii1I11I1II1 + I1IiiI . oO0o % iII111i
O000OOo00oo = O0oOoOOOoOO ( )
i1 = None
iI = None
IIIii1II1II = None
oOO00oOO = None
ooOOOoOooOoO = None
if 91 - 91: iII111i % i1IIi % iIii1I11I1II1
if 20 - 20: OOooOOo % Ii1I / Ii1I + Ii1I
try :
 i1 = urllib . unquote_plus ( O000OOo00oo [ "url" ] )
except :
 pass
try :
 iI = urllib . unquote_plus ( O000OOo00oo [ "name" ] )
except :
 pass
try :
 IIIii1II1II = urllib . unquote_plus ( O000OOo00oo [ "iconimage" ] )
except :
 pass
try :
 oOO00oOO = int ( O000OOo00oo [ "mode" ] )
except :
 pass
try :
 I1I = urllib . unquote_plus ( O000OOo00oo [ "fanart" ] )
except :
 pass
try :
 ooOOOoOooOoO = urllib . unquote_plus ( O000OOo00oo [ "description" ] )
except :
 pass
 if 45 - 45: oO0o - IiII - OoooooooOO - OoO0O00 . II111iiii / O0
 if 51 - 51: O0 + iII111i
print str ( OOoO00o ) + ': ' + str ( II111iiiiII )
print "Mode: " + str ( oOO00oOO )
print "URL: " + str ( i1 )
print "Name: " + str ( iI )
print "IconImage: " + str ( IIIii1II1II )
if 8 - 8: oO0o * OoOoOO00 - Ii1I - OoO0O00 * OOooOOo % I1IiiI
def ii ( ) :
 try :
  oOooOOOoOo = getSet ( "core-player" )
  if ( oOooOOOoOo == 'DVDPLAYER' ) : i1Iii1i1I = xbmc . PLAYER_CORE_DVDPLAYER
  elif ( oOooOOOoOo == 'MPLAYER' ) : i1Iii1i1I = xbmc . PLAYER_CORE_MPLAYER
  elif ( oOooOOOoOo == 'PAPLAYER' ) : i1Iii1i1I = xbmc . PLAYER_CORE_PAPLAYER
  else : i1Iii1i1I = xbmc . PLAYER_CORE_AUTO
 except : i1Iii1i1I = xbmc . PLAYER_CORE_AUTO
 return i1Iii1i1I
 return True
 if 91 - 91: I1ii11iIi11i + I1IiiI . OOooOOo * I1ii11iIi11i + I1IiiI * Oo0Ooo
 if 80 - 80: iII111i % OOooOOo % oO0o - Oo0Ooo + Oo0Ooo
def iIiii1i111iI1 ( url ) :
 i11 = xbmc . Player ( ii ( ) )
 import urlresolver
 try : i11 . play ( url )
 except : pass
 from urlresolver import common
 oO0oOo0 = xbmcgui . DialogProgress ( )
 oO0oOo0 . create ( 'LOADING' , 'Opening %s Now' % ( iI ) )
 i11 = xbmc . Player ( ii ( ) )
 url = urlresolver . HostedMediaFile ( url ) . resolve ( )
 if oO0oOo0 . iscanceled ( ) :
  print "[COLORred]STREAM CANCELLED[/COLOR]"
  I1I1I = xbmcgui . Dialog ( )
  if I1I1I . yesno ( "[B]CANCELLED[/B]" , '[B]Was There A Problem[/B]' , '' , "" , 'Yes' , 'No' ) :
   I1I1I . ok ( "Message Send" , "Your Message Has Been Sent" )
  else :
   return
 else :
  try : i11 . play ( url )
  except : pass
  try : ADDON . resolve_url ( url )
  except : pass
  oO0oOo0 . close ( )
  if 95 - 95: II111iiii + o0oOOo0O0Ooo + iII111i * iIii1I11I1II1 % oO0o / IiII
def iiI1 ( url ) :
 o0o0o0oO0oOO = urllib2 . Request ( url )
 oOoOo00oOo = 'Mozilla/5.0 (Windows NT 6.1; WOW64; Trident/7.0; AS; rv:11.0) like Gecko'
 Oo = 'Mozilla/5.0 (Windows NT 6.3; rv:36.0) Gecko/20100101 Firefox/36.0'
 o00O00O0O0O = 'Mozilla/5.0 (iPhone; CPU iPhone OS 6_0 like Mac OS X) AppleWebKit/536.26 (KHTML, like Gecko) Version/6.0 Mobile/10A5376e Safari/8536.25'
 OooO0OO = 'Mozilla/5.0 (Linux; Android 4.4.2; Nexus 4 Build/KOT49H) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/34.0.1847.114 Mobile Safari/537.36'
 o0o0o0oO0oOO . add_header ( 'User-Agent' , 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3' )
 ii1Ii11I = urllib2 . urlopen ( o0o0o0oO0oOO )
 i11i1 = ii1Ii11I . read ( )
 ii1Ii11I . close ( )
 return i11i1
 if 80 - 80: II111iiii
def O0O ( content , viewType ) :
 if content :
  xbmcplugin . setContent ( int ( sys . argv [ 1 ] ) , content )
  if 1 - 1: II111iiii
  if 84 - 84: o0oOOo0O0Ooo % II111iiii . i11iIiiIii / OoO0O00
if oOO00oOO == None : oo ( )
elif oOO00oOO == 1 : oOOO00o ( )
elif oOO00oOO == 400 : o0 ( )
elif oOO00oOO == 401 : iIiii1i111iI1 ( i1 )
elif oOO00oOO == 423 : i1i ( i1 )
elif oOO00oOO == 424 : OooO0OoOOOO ( )
elif oOO00oOO == 425 : Oo0OoO00oOO0o ( )
elif oOO00oOO == 426 : ooii11I ( i1 )
elif oOO00oOO == 427 : oo0OooOOo0 ( iI , i1 , oOO00oOO , IIIii1II1II , I1I , ooOOOoOooOoO )
if 80 - 80: I1Ii111 . i11iIiiIii - o0oOOo0O0Ooo
xbmcplugin . endOfDirectory ( int ( sys . argv [ 1 ] ) )
# dd678faae9ac167bc83abf78e5cb2f3f0688d3a3
