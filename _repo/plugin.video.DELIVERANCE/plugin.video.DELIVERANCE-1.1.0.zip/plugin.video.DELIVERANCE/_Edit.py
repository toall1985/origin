import xbmcaddon

MainBase = 'http://kodeeresurrection.com/DELIVERANCE%20TXT%20FILES/home.txt'
addon = xbmcaddon.Addon('plugin.video.DELIVERANCE')