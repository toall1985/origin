if 64 - 64: i11iIiiIii
if 65 - 65: O0 / iIii1I11I1II1 % OoooooooOO - i1IIi
if 73 - 73: II111iiii
if 22 - 22: I1IiiI * Oo0Ooo / OoO0O00 . OoOoOO00 . o0oOOo0O0Ooo / I1ii11iIi11i
if 48 - 48: oO0o / OOooOOo / I11i / Ii1I
if 48 - 48: iII111i % IiII + I1Ii111 / ooOoO0o * Ii1I
if 46 - 46: ooOoO0o * I11i - OoooooooOO
if 30 - 30: o0oOOo0O0Ooo - O0 % o0oOOo0O0Ooo - OoooooooOO * O0 * OoooooooOO
if 60 - 60: iIii1I11I1II1 / i1IIi * oO0o - I1ii11iIi11i + o0oOOo0O0Ooo
if 94 - 94: i1IIi % Oo0Ooo
if 68 - 68: Ii1I / O0
if 46 - 46: O0 * II111iiii / IiII * Oo0Ooo * iII111i . I11i
if 62 - 62: i11iIiiIii - II111iiii % I1Ii111 - iIii1I11I1II1 . I1ii11iIi11i . II111iiii
if 61 - 61: oO0o / OoOoOO00 / iII111i * OoO0O00 . II111iiii
if 1 - 1: II111iiii - I1ii11iIi11i % i11iIiiIii + IiII . I1Ii111
if 55 - 55: iIii1I11I1II1 - I1IiiI . Ii1I * IiII * i1IIi / iIii1I11I1II1
import sys
import urlparse
import urllib , urllib2 , datetime , re , os , base64 , xbmc , xbmcplugin , xbmcgui , xbmcaddon , xbmcvfs , traceback , cookielib , urlparse , httplib , time
import urlresolver
import time
from datetime import datetime
if 79 - 79: oO0o + I1Ii111 . ooOoO0o * IiII % I11i . I1IiiI
O0o0o00o0Oo0 = xbmcgui . Dialog ( )
ii11 = base64 . decodestring
I1I1i1 = ii11 ( 'LnBocA==' )
IiI1i = ( ii11 ( 'aHR0cDovL3NlZWR1cmdyZWVkLngxMGhvc3QuY29tL29yaWdpbi8=' ) )
OOo0o0 = 'plugin.video.footballrepeat'
O0OoOoo00o = sys . argv [ 0 ]
iiiI11 = int ( sys . argv [ 1 ] )
OOooO = urlparse . parse_qs ( sys . argv [ 2 ] [ 1 : ] )
OOoO00o = "Football Repeat"
II111iiiiII = "1.0.1"
oOoOo00oOo = 'Mozilla/5.0 (Windows NT 6.1; WOW64; Trident/7.0; AS; rv:11.0) like Gecko'
Oo = 'Mozilla/5.0 (Windows NT 6.3; rv:36.0) Gecko/20100101 Firefox/36.0'
o00O00O0O0O = 'Mozilla/5.0 (iPhone; CPU iPhone OS 6_0 like Mac OS X) AppleWebKit/536.26 (KHTML, like Gecko) Version/6.0 Mobile/10A5376e Safari/8536.25'
OooO0OO = 'Mozilla/5.0 (Linux; Android 4.4.2; Nexus 4 Build/KOT49H) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/34.0.1847.114 Mobile Safari/537.36'
if 28 - 28: II111iiii
iii11iII = xbmc . translatePath ( os . path . join ( 'special://home' , 'addons' , '' ) )
i1I111I = os . path . join ( iii11iII , OOo0o0 , 'resources' , 'art' ) + os . sep
i11I1IIiiIi = xbmc . translatePath ( os . path . join ( iii11iII , OOo0o0 , 'fanart.jpg' ) )
if 34 - 34: OoooooooOO + iIii1I11I1II1 + i11iIiiIii - I1ii11iIi11i + i11iIiiIii
if 65 - 65: OoOoOO00
if 6 - 6: I1IiiI / Oo0Ooo % Ii1I
def oo ( ) :
 OO0O00 ( 'Highlights' , '' , 3 , i1I111I + 'icon.png' , i11I1IIiiIi , '' )
 OO0O00 ( 'Fixtures' , '' , 4 , i1I111I + 'icon.png' , i11I1IIiiIi , '' )
 if 20 - 20: OoooooooOO
def Ii11iI1i ( ) :
 Ooo = O0o0Oo ( ii11 ( 'aHR0cDovL2xpdmVvbnNhdC5jb20vcXVpY2tpbmRleC5odG1s' ) )
 Oo00OOOOO = re . compile ( '<a target="_self" href="(.+?)".+?src="(.+?)" alt="(.+?)"' , re . DOTALL ) . findall ( Ooo )
 for O0O , O00o0OO , I11i1 in Oo00OOOOO :
  OO0O00 ( ( I11i1 ) . replace ( 'amp;' , '' ) , ii11 ( 'aHR0cDovL2xpdmVvbnNhdC5jb20v' ) + O0O , 5 , ii11 ( 'aHR0cDovL2xpdmVvbnNhdC5jb20v' ) + O00o0OO , i11I1IIiiIi , '' )
  if 25 - 25: Oo0Ooo - IiII . OoooooooOO
def I11ii1 ( url ) :
 I11II1i = O0o0Oo ( url )
 IIIII = re . compile ( 'AndClearL.+?><h2.+?head>(.*?)float' , re . DOTALL ) . findall ( I11II1i )
 for IIIII in IIIII :
  ooooooO0oo = re . compile ( '(.*?)</h2>' ) . findall ( str ( IIIII ) )
  for IIiiiiiiIi1I1 in ooooooO0oo :
   IIiiiiiiIi1I1 = IIiiiiiiIi1I1
  I1IIIii = re . compile ( 'comp_head>(.*?)</span>.*?<div class = fLeft width = ".*?"><img src="(.*?)">.*?</div>.*?ST:(.*?)</div>(.+?)<!-- around all of channel types ENDS 2-->' , re . DOTALL ) . findall ( str ( IIIII ) )
  for oOoOooOo0o0 , O00o0OO , time , OOOO in I1IIIii :
   OOO00 = re . compile ( ",CAPTION, '(.+?)&nbsp" ) . findall ( OOOO )
   OO0O00 ( IIiiiiiiIi1I1 + ' - ' + oOoOooOo0o0 + ' - ' + time , '' , 5 , ii11 ( 'aHR0cDovL2xpdmVvbnNhdC5jb20=' ) + O00o0OO , i11I1IIiiIi , ( str ( OOO00 ) ) )
   if 21 - 21: OoooooooOO - OoooooooOO
 iIii11I ( 'tvshows' , 'Media Info 3' )
 if 69 - 69: oO0o % I1Ii111 - o0oOOo0O0Ooo + I1Ii111 - O0 % OoooooooOO
def Iii111II ( ) :
 if 9 - 9: OoO0O00
 OO0O00 ( 'Shows' , 'http://www.fullmatchesandshows.com/category/show/' , 1 , 'http://www.fm-base.co.uk/forum/attachments/club-competition-logos/3885-soccer-am-logo-socceram.png' , i1I111I + 'fanart.jpg' , '' )
 OO0O00 ( 'Premier League' , 'http://www.fullmatchesandshows.com/premier-league/' , 1 , 'https://footballseasons.files.wordpress.com/2013/05/premier-league.png' , i1I111I + 'fanart.jpg' , '' )
 OO0O00 ( 'La Liga' , 'http://www.fullmatchesandshows.com/la-liga/' , 1 , 'http://1.bp.blogspot.com/-c6kQ40ryhyo/U19cUlz25sI/AAAAAAAABak/qtn5chSFZm0/s1600/la-liga-logo_display_image.png' , i1I111I + 'fanart.jpg' , '' )
 OO0O00 ( 'Bundesliga' , 'http://www.fullmatchesandshows.com/bundesliga/' , 1 , 'http://m.img.brothersoft.com/iphone/189/518670189_icon175x175.jpg' , i1I111I + 'fanart.jpg' , '' )
 OO0O00 ( 'Champions League' , 'http://www.fullmatchesandshows.com/champions-league/' , 1 , 'http://www.ecursuri.ro/images/teste/test-champions-league.jpg' , i1I111I + 'fanart.jpg' , '' )
 OO0O00 ( 'Serie A' , 'http://www.fullmatchesandshows.com/category/serie-a/' , 1 , 'http://files.jcriccione.it/200000223-2484526782/serie%20a.png' , i1I111I + 'fanart.jpg' , '' )
 OO0O00 ( 'Ligue 1' , 'http://www.fullmatchesandshows.com/category/ligue-1/' , 1 , 'http://a1.mzstatic.com/us/r30/Purple5/v4/37/c7/44/37c744ae-5824-42b7-6ce0-5f471f52baab/icon180x180.jpeg' , i1I111I + 'fanart.jpg' , '' )
 OO0O00 ( 'Copa America 2015' , 'http://www.fullmatchesandshows.com/copa-america-2015/' , 1 , 'https://pbs.twimg.com/profile_images/521966985907691520/Nq9OAPIo_400x400.png' , i1I111I + 'fanart.jpg' , '' )
 OO0O00 ( 'CONCACAF' , 'http://www.fullmatchesandshows.com/category/concacaf/' , 1 , 'http://a3.mzstatic.com/us/r30/Purple3/v4/40/26/14/4026147c-7022-4ca3-504e-e78950cc3f1c/icon175x175.png' , i1I111I + 'fanart.jpg' , '' )
 OO0O00 ( 'Women World Cup' , 'http://www.fullmatchesandshows.com/category/women-world-cup/' , 1 , 'https://upload.wikimedia.org/wikipedia/en/thumb/7/76/2015_FIFA_Women\'s_World_Cup_logo.svg/967px-2015_FIFA_Women\'s_World_Cup_logo.svg.png' , i1I111I + 'fanart.jpg' , '' )
 if 33 - 33: ooOoO0o . iII111i
 if 58 - 58: OOooOOo * i11iIiiIii / OoOoOO00 % I1Ii111 - I1ii11iIi11i / oO0o
 if 50 - 50: I1IiiI
def Ii1i11IIii1I ( url ) :
 OOOoO0O0o = O0o0Oo ( url )
 O0o0Ooo = re . compile ( '<div class="td-block-row">(.*?)</div><!--./row-fluid-->' , re . DOTALL ) . findall ( OOOoO0O0o )
 for O00 in O0o0Ooo :
  iI1Ii11iII1 ( O00 )
  if 51 - 51: II111iiii * OoO0O00 % o0oOOo0O0Ooo * II111iiii % I1ii11iIi11i / ooOoO0o
  if 49 - 49: o0oOOo0O0Ooo
def iI1Ii11iII1 ( row ) :
 IIii1Ii1 = re . compile ( '<div class="td-block-span4">(.+?)<!-- ./td-block-span4 -->' , re . DOTALL ) . findall ( row )
 for I1II11IiII in IIii1Ii1 :
  OOO0OOo ( I1II11IiII )
  if 47 - 47: OOooOOo + IiII - IiII * I1IiiI + Ii1I % IiII
  if 4 - 4: oO0o
def OOO0OOo ( row_Item ) :
 OOoO0O00o0 = re . findall ( r'<a href="(.+?)" rel="bookmark" title="(.+?)">' , str ( row_Item ) )
 iII = [ ]
 o0 = ''
 for o0 , ooOooo000oOO in OOoO0O00o0 :
  iII . append ( ooOooo000oOO )
  o0 = o0
  if 59 - 59: II111iiii + OoooooooOO * OoOoOO00 + i1IIi
 Oo0OoO00oOO0o ( iII , row_Item , o0 )
 if 80 - 80: oO0o + OOooOOo - OOooOOo % iII111i
 if 63 - 63: I1IiiI - I1ii11iIi11i + O0 % I11i / iIii1I11I1II1 / o0oOOo0O0Ooo
def Oo0OoO00oOO0o ( item_Data , row_Item , link ) :
 O0o0O00Oo0o0 = re . compile ( '<img width=".+?" height=".+?" itemprop=".+?" class="entry-thumb" src="(.+?)" alt=".+?" title=".+?"/>' , re . DOTALL ) . findall ( row_Item )
 for O00O0oOO00O00 in O0o0O00Oo0o0 :
  item_Data . append ( O00O0oOO00O00 )
  if 11 - 11: IiII . I1ii11iIi11i
 o0oo0oOo ( item_Data , link )
 if 89 - 89: OoOoOO00
 # For Each Video In Row Get Play Link
 if 68 - 68: OoO0O00 * OoooooooOO % O0 + OoO0O00 + ooOoO0o
def o0oo0oOo ( item_Data , link ) :
 i11i1I1 = O0o0Oo ( link )
 ii1I = re . compile ( '<script data-config="(.+?)" data-css=".+?" data-height=".+?" data-width=".+?" src=".+?" type="text/javascript"></script>' , re . DOTALL ) . findall ( i11i1I1 )
 for Oo0ooOo0o in ii1I :
  item_Data . append ( Oo0ooOo0o )
  if 22 - 22: iIii1I11I1II1 / i11iIiiIii * iIii1I11I1II1 * II111iiii . OOooOOo / i11iIiiIii
 Iiii ( item_Data )
 if 75 - 75: OoOoOO00 % o0oOOo0O0Ooo % o0oOOo0O0Ooo . I1Ii111
 if 5 - 5: o0oOOo0O0Ooo * ooOoO0o + OoOoOO00 . OOooOOo + OoOoOO00
def Iiii ( item_Data ) :
 oO = item_Data [ 0 ]
 iIi1IIIi1 = item_Data [ 1 ]
 O0oOoOOOoOO = item_Data [ 2 ]
 if 38 - 38: I1Ii111
 if 7 - 7: O0 . iII111i % I1ii11iIi11i - I1IiiI - iIii1I11I1II1
 if 36 - 36: IiII % ooOoO0o % Oo0Ooo - I1ii11iIi11i
 oO = oO . replace ( '&#8211;' , '-' ) . replace ( '&#038;' , '&' )
 O0oOoOOOoOO = O0oOoOOOoOO . replace ( '/v2' , '' ) . replace ( 'zeus.json' , 'video-sd.mp4?hosting_id=21772' ) . replace ( 'config.playwire.com' , 'cdn.video.playwire.com' )
 print '~~~~~~~~~~~~~~~~~~~~'
 print oO
 print iIi1IIIi1
 print O0oOoOOOoOO
 print '~~~~~~~~~~~~~~~~~~~~'
 Ii1IO000OOo00oo ( oO , 'http:' + O0oOoOOOoOO , 2 , iIi1IIIi1 , i1I111I + 'fanart.jpg' , '' )
 if 71 - 71: i11iIiiIii + IiII
 if 57 - 57: oO0o . I11i . i1IIi
 if 42 - 42: I11i + I1ii11iIi11i % O0
def Ii1IO000OOo00oo ( name , url , mode , iconimage , fanart , description ) :
 if 6 - 6: oO0o
 oOOo0oOo0 = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage ) + "&fanart=" + urllib . quote_plus ( fanart ) + "&description=" + urllib . quote_plus ( description )
 II = True
 ooooo = xbmcgui . ListItem ( name , iconImage = "DefaultFolder.png" , thumbnailImage = iconimage )
 ooooo . setInfo ( type = "Video" , infoLabels = { "Title" : name , "Plot" : description } )
 ooooo . setProperty ( "Fanart_Image" , fanart )
 II = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = oOOo0oOo0 , listitem = ooooo , isFolder = False )
 return II
 if 1 - 1: Oo0Ooo / o0oOOo0O0Ooo % iII111i * IiII . i11iIiiIii
def OO0O00 ( name , url , mode , iconimage , fanart , description ) :
 if 2 - 2: I1ii11iIi11i * I11i - iIii1I11I1II1 + I1IiiI . oO0o % iII111i
 oOOo0oOo0 = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage ) + "&fanart=" + urllib . quote_plus ( fanart ) + "&description=" + urllib . quote_plus ( description )
 II = True
 ooooo = xbmcgui . ListItem ( name , iconImage = "DefaultFolder.png" , thumbnailImage = iconimage )
 ooooo . setInfo ( type = "Video" , infoLabels = { "Title" : name , "Plot" : description } )
 ooooo . setProperty ( "Fanart_Image" , fanart )
 II = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = oOOo0oOo0 , listitem = ooooo , isFolder = True )
 return II
 if 92 - 92: iII111i
def IIiIiiIi ( ) :
 try :
  O000oo = getSet ( "core-player" )
  if ( O000oo == 'DVDPLAYER' ) : IIi1I11I1II = xbmc . PLAYER_CORE_DVDPLAYER
  elif ( O000oo == 'MPLAYER' ) : IIi1I11I1II = xbmc . PLAYER_CORE_MPLAYER
  elif ( O000oo == 'PAPLAYER' ) : IIi1I11I1II = xbmc . PLAYER_CORE_PAPLAYER
  else : IIi1I11I1II = xbmc . PLAYER_CORE_AUTO
 except : IIi1I11I1II = xbmc . PLAYER_CORE_AUTO
 return IIi1I11I1II
 return True
 if 63 - 63: OoooooooOO - OoO0O00 . II111iiii / o0oOOo0O0Ooo . OoOoOO00 / O0
def o0OOOO00O0Oo ( ) :
 ii = [ ]
 oOooOOOoOo = sys . argv [ 2 ]
 if len ( oOooOOOoOo ) >= 2 :
  i1Iii1i1I = sys . argv [ 2 ]
  OOoO00 = i1Iii1i1I . replace ( '?' , '' )
  if ( i1Iii1i1I [ len ( i1Iii1i1I ) - 1 ] == '/' ) :
   i1Iii1i1I = i1Iii1i1I [ 0 : len ( i1Iii1i1I ) - 2 ]
  IiI111111IIII = OOoO00 . split ( '&' )
  ii = { }
  for i1Ii in range ( len ( IiI111111IIII ) ) :
   ii111iI1iIi1 = { }
   ii111iI1iIi1 = IiI111111IIII [ i1Ii ] . split ( '=' )
   if ( len ( ii111iI1iIi1 ) ) == 2 :
    ii [ ii111iI1iIi1 [ 0 ] ] = ii111iI1iIi1 [ 1 ]
    if 78 - 78: OoO0O00 . OOooOOo + OoO0O00 / I11i / OoO0O00
 return ii
 if 54 - 54: OoOoOO00 % iII111i
i1Iii1i1I = o0OOOO00O0Oo ( )
O0O = None
I11i1 = None
IIiII111iiI1I = None
Ii1i1iI1iIIi = None
I1Ii = None
if 94 - 94: Ii1I - II111iiii . OOooOOo % I11i . i11iIiiIii + O0
if 26 - 26: I11i - iIii1I11I1II1 - I1IiiI / OoO0O00 . OoOoOO00 % iIii1I11I1II1
try :
 O0O = urllib . unquote_plus ( i1Iii1i1I [ "url" ] )
except :
 pass
try :
 I11i1 = urllib . unquote_plus ( i1Iii1i1I [ "name" ] )
except :
 pass
try :
 IIiII111iiI1I = urllib . unquote_plus ( i1Iii1i1I [ "iconimage" ] )
except :
 pass
try :
 Ii1i1iI1iIIi = int ( i1Iii1i1I [ "mode" ] )
except :
 pass
try :
 OO = urllib . unquote_plus ( i1Iii1i1I [ "fanart" ] )
except :
 pass
try :
 I1Ii = urllib . unquote_plus ( i1Iii1i1I [ "description" ] )
except :
 pass
 if 25 - 25: OoO0O00
 if 62 - 62: OOooOOo + O0
print str ( OOoO00o ) + ': ' + str ( II111iiiiII )
print "Mode: " + str ( Ii1i1iI1iIIi )
print "URL: " + str ( O0O )
print "Name: " + str ( I11i1 )
print "IconImage: " + str ( IIiII111iiI1I )
if 98 - 98: o0oOOo0O0Ooo
def OOOO0oo0 ( url ) :
 I11iiI1i1 = xbmc . Player ( IIiIiiIi ( ) )
 import urlresolver
 try : I11iiI1i1 . play ( url )
 except : pass
 if 47 - 47: iII111i - Ii1I . II111iiii + OoooooooOO . i11iIiiIii
def O0o0Oo ( url ) :
 OOo0oO00ooO00 = urllib2 . Request ( url )
 oOoOo00oOo = 'Mozilla/5.0 (Windows NT 6.1; WOW64; Trident/7.0; AS; rv:11.0) like Gecko'
 Oo = 'Mozilla/5.0 (Windows NT 6.3; rv:36.0) Gecko/20100101 Firefox/36.0'
 o00O00O0O0O = 'Mozilla/5.0 (iPhone; CPU iPhone OS 6_0 like Mac OS X) AppleWebKit/536.26 (KHTML, like Gecko) Version/6.0 Mobile/10A5376e Safari/8536.25'
 OooO0OO = 'Mozilla/5.0 (Linux; Android 4.4.2; Nexus 4 Build/KOT49H) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/34.0.1847.114 Mobile Safari/537.36'
 OOo0oO00ooO00 . add_header ( 'User-Agent' , 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3' )
 oOO0O00oO0Ooo = urllib2 . urlopen ( OOo0oO00ooO00 )
 o0 = oOO0O00oO0Ooo . read ( )
 oOO0O00oO0Ooo . close ( )
 return o0
 if 67 - 67: OoO0O00 - OOooOOo
def iIii11I ( content , viewType ) :
 if content :
  xbmcplugin . setContent ( int ( sys . argv [ 1 ] ) , content )
  if 36 - 36: IiII
  if 36 - 36: ooOoO0o / O0 * Oo0Ooo - OOooOOo % iIii1I11I1II1 * oO0o
if Ii1i1iI1iIIi == None : oo ( )
elif Ii1i1iI1iIIi == 1 : Ii1i11IIii1I ( O0O )
elif Ii1i1iI1iIIi == 2 : OOOO0oo0 ( O0O )
elif Ii1i1iI1iIIi == 3 : Iii111II ( )
elif Ii1i1iI1iIIi == 4 : Ii11iI1i ( )
elif Ii1i1iI1iIIi == 5 : I11ii1 ( O0O )
if 79 - 79: O0
xbmcplugin . endOfDirectory ( int ( sys . argv [ 1 ] ) )
# dd678faae9ac167bc83abf78e5cb2f3f0688d3a3
