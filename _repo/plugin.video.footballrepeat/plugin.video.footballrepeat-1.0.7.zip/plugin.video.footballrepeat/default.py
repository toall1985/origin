if 64 - 64: i11iIiiIii
if 65 - 65: O0 / iIii1I11I1II1 % OoooooooOO - i1IIi
if 73 - 73: II111iiii
if 22 - 22: I1IiiI * Oo0Ooo / OoO0O00 . OoOoOO00 . o0oOOo0O0Ooo / I1ii11iIi11i
if 48 - 48: oO0o / OOooOOo / I11i / Ii1I
if 48 - 48: iII111i % IiII + I1Ii111 / ooOoO0o * Ii1I
if 46 - 46: ooOoO0o * I11i - OoooooooOO
if 30 - 30: o0oOOo0O0Ooo - O0 % o0oOOo0O0Ooo - OoooooooOO * O0 * OoooooooOO
if 60 - 60: iIii1I11I1II1 / i1IIi * oO0o - I1ii11iIi11i + o0oOOo0O0Ooo
if 94 - 94: i1IIi % Oo0Ooo
if 68 - 68: Ii1I / O0
if 46 - 46: O0 * II111iiii / IiII * Oo0Ooo * iII111i . I11i
if 62 - 62: i11iIiiIii - II111iiii % I1Ii111 - iIii1I11I1II1 . I1ii11iIi11i . II111iiii
if 61 - 61: oO0o / OoOoOO00 / iII111i * OoO0O00 . II111iiii
if 1 - 1: II111iiii - I1ii11iIi11i % i11iIiiIii + IiII . I1Ii111
if 55 - 55: iIii1I11I1II1 - I1IiiI . Ii1I * IiII * i1IIi / iIii1I11I1II1
import sys
import urlparse
import urllib , urllib2 , datetime , re , os , base64 , xbmc , xbmcplugin , xbmcgui , xbmcaddon , xbmcvfs , traceback , cookielib , urlparse , httplib , time
import urlresolver
if 79 - 79: oO0o + I1Ii111 . ooOoO0o * IiII % I11i . I1IiiI
O0o0o00o0Oo0 = xbmcgui . Dialog ( )
ii11 = base64 . decodestring
I1I1i1 = ii11 ( 'LnBocA==' )
IiI1i = ( ii11 ( 'aHR0cDovL3NlZWR1cmdyZWVkLngxMGhvc3QuY29tL29yaWdpbi8=' ) )
OOo0o0 = 'plugin.video.footballrepeat'
O0OoOoo00o = sys . argv [ 0 ]
iiiI11 = int ( sys . argv [ 1 ] )
OOooO = urlparse . parse_qs ( sys . argv [ 2 ] [ 1 : ] )
OOoO00o = "Football Repeat"
II111iiiiII = "1.0.7"
oOoOo00oOo = 'Mozilla/5.0 (Windows NT 6.1; WOW64; Trident/7.0; AS; rv:11.0) like Gecko'
Oo = 'Mozilla/5.0 (Windows NT 6.3; rv:36.0) Gecko/20100101 Firefox/36.0'
o00O00O0O0O = 'Mozilla/5.0 (iPhone; CPU iPhone OS 6_0 like Mac OS X) AppleWebKit/536.26 (KHTML, like Gecko) Version/6.0 Mobile/10A5376e Safari/8536.25'
OooO0OO = 'Mozilla/5.0 (Linux; Android 4.4.2; Nexus 4 Build/KOT49H) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/34.0.1847.114 Mobile Safari/537.36'
if 28 - 28: II111iiii
iii11iII = xbmc . translatePath ( os . path . join ( 'special://home' , 'addons' , '' ) )
i1I111I = os . path . join ( iii11iII , OOo0o0 , 'resources' , 'art' ) + os . sep
i11I1IIiiIi = xbmc . translatePath ( os . path . join ( iii11iII , OOo0o0 , 'fanart.jpg' ) )
if 34 - 34: OoooooooOO + iIii1I11I1II1 + i11iIiiIii - I1ii11iIi11i + i11iIiiIii
if 65 - 65: OoOoOO00
if 6 - 6: I1IiiI / Oo0Ooo % Ii1I
def oo ( ) :
 OO0O00 ( 'Highlights' , '' , 3 , i1I111I + 'icon.png' , i11I1IIiiIi , '' )
 OO0O00 ( 'Fixtures' , '' , 4 , i1I111I + 'icon.png' , i11I1IIiiIi , '' )
 if 20 - 20: OoooooooOO
def Ii11iI1i ( ) :
 Ooo = O0o0Oo ( ii11 ( 'http://liveonsat.com/quickindex.html' ) )
 Oo00OOOOO = re . compile ( '<a target="_self" href="(.+?)".+?src="(.+?)" alt="(.+?)"' , re . DOTALL ) . findall ( Ooo )
 for O0O , O00o0OO , I11i1 in Oo00OOOOO :
  OO0O00 ( ( I11i1 ) . replace ( 'amp;' , '' ) , ii11 ( 'aHR0cDovL2xpdmVvbnNhdC5jb20v' ) + O0O , 5 , ii11 ( 'aHR0cDovL2xpdmVvbnNhdC5jb20v' ) + O00o0OO , i11I1IIiiIi , '' )
  if 25 - 25: Oo0Ooo - IiII . OoooooooOO
def I11ii1 ( url ) :
 I11II1i = O0o0Oo ( url )
 IIIII = re . compile ( 'AndClearL.+?><h2.+?head>(.*?)float' , re . DOTALL ) . findall ( I11II1i )
 for IIIII in IIIII :
  ooooooO0oo = re . compile ( '(.*?)</h2>' ) . findall ( str ( IIIII ) )
  for IIiiiiiiIi1I1 in ooooooO0oo :
   IIiiiiiiIi1I1 = IIiiiiiiIi1I1
  I1IIIii = re . compile ( 'comp_head>(.*?)</span>.*?<div class = fLeft width = ".*?"><img src="(.*?)">.*?</div>.*?ST:(.*?)</div>(.+?)<!-- around all of channel types ENDS 2-->' , re . DOTALL ) . findall ( str ( IIIII ) )
  for oOoOooOo0o0 , O00o0OO , time , OOOO in I1IIIii :
   OOO00 = re . compile ( ",CAPTION, '(.+?)&nbsp" ) . findall ( OOOO )
   OO0O00 ( IIiiiiiiIi1I1 + ' - ' + oOoOooOo0o0 + ' - ' + time , '' , 5 , ii11 ( 'aHR0cDovL2xpdmVvbnNhdC5jb20=' ) + O00o0OO , i11I1IIiiIi , ( str ( OOO00 ) ) )
   if 21 - 21: OoooooooOO - OoooooooOO
 iIii11I ( 'tvshows' , 'Media Info 3' )
 if 69 - 69: oO0o % I1Ii111 - o0oOOo0O0Ooo + I1Ii111 - O0 % OoooooooOO
def Iii111II ( ) :
 if 9 - 9: OoO0O00
 OO0O00 ( 'Shows' , 'http://www.fullmatchesandshows.com/category/show/' , 1 , 'http://www.fm-base.co.uk/forum/attachments/club-competition-logos/3885-soccer-am-logo-socceram.png' , i1I111I + 'fanart.jpg' , '' )
 OO0O00 ( 'Premier League' , 'http://www.fullmatchesandshows.com/premier-league/' , 1 , 'https://footballseasons.files.wordpress.com/2013/05/premier-league.png' , i1I111I + 'fanart.jpg' , '' )
 OO0O00 ( 'La Liga' , 'http://www.fullmatchesandshows.com/la-liga/' , 1 , 'http://1.bp.blogspot.com/-c6kQ40ryhyo/U19cUlz25sI/AAAAAAAABak/qtn5chSFZm0/s1600/la-liga-logo_display_image.png' , i1I111I + 'fanart.jpg' , '' )
 OO0O00 ( 'Bundesliga' , 'http://www.fullmatchesandshows.com/bundesliga/' , 1 , 'http://m.img.brothersoft.com/iphone/189/518670189_icon175x175.jpg' , i1I111I + 'fanart.jpg' , '' )
 OO0O00 ( 'Champions League' , 'http://www.fullmatchesandshows.com/champions-league/' , 1 , 'http://www.ecursuri.ro/images/teste/test-champions-league.jpg' , i1I111I + 'fanart.jpg' , '' )
 OO0O00 ( 'Serie A' , 'http://www.fullmatchesandshows.com/category/serie-a/' , 1 , 'http://files.jcriccione.it/200000223-2484526782/serie%20a.png' , i1I111I + 'fanart.jpg' , '' )
 OO0O00 ( 'Ligue 1' , 'http://www.fullmatchesandshows.com/category/ligue-1/' , 1 , 'http://a1.mzstatic.com/us/r30/Purple5/v4/37/c7/44/37c744ae-5824-42b7-6ce0-5f471f52baab/icon180x180.jpeg' , i1I111I + 'fanart.jpg' , '' )
 OO0O00 ( 'Copa America 2015' , 'http://www.fullmatchesandshows.com/copa-america-2015/' , 1 , 'https://pbs.twimg.com/profile_images/521966985907691520/Nq9OAPIo_400x400.png' , i1I111I + 'fanart.jpg' , '' )
 OO0O00 ( 'CONCACAF' , 'http://www.fullmatchesandshows.com/category/concacaf/' , 1 , 'http://a3.mzstatic.com/us/r30/Purple3/v4/40/26/14/4026147c-7022-4ca3-504e-e78950cc3f1c/icon175x175.png' , i1I111I + 'fanart.jpg' , '' )
 OO0O00 ( 'Women World Cup' , 'http://www.fullmatchesandshows.com/category/women-world-cup/' , 1 , 'https://upload.wikimedia.org/wikipedia/en/thumb/7/76/2015_FIFA_Women\'s_World_Cup_logo.svg/967px-2015_FIFA_Women\'s_World_Cup_logo.svg.png' , i1I111I + 'fanart.jpg' , '' )
 if 33 - 33: ooOoO0o . iII111i
 if 58 - 58: OOooOOo * i11iIiiIii / OoOoOO00 % I1Ii111 - I1ii11iIi11i / oO0o
 if 50 - 50: I1IiiI
def Ii1i11IIii1I ( url ) :
 I11II1i = O0o0Oo ( url )
 Oo00OOOOO = re . compile ( 'class="entry-thumb" src="(.+?)" alt="".+?<h3 class="entry-title td-module-title"><a href="(.+?)" rel="bookmark" title=".+?">(.+?)</a></h3>' , re . DOTALL ) . findall ( I11II1i )
 for O00o0OO , url , I11i1 in Oo00OOOOO :
  OOOoO0O0o = I11i1 . replace ( '&#8211;' , '-' ) . replace ( '&#038;' , '&' )
  O0o0Ooo ( OOOoO0O0o , url , 2 , O00o0OO , '' , '' )
  if 56 - 56: ooOoO0o . OoOoOO00 * iII111i . OoOoOO00
def O00oO ( url ) :
 I11II1i = O0o0Oo ( url )
 Oo00OOOOO = re . compile ( '<script data-config="(.+?)" data-height' ) . findall ( I11II1i )
 for I11i1I1I in Oo00OOOOO :
  oO0Oo = ( I11i1I1I ) . replace ( '/v2' , '' ) . replace ( 'zeus.json' , 'video-sd.mp4?hosting_id=21772' ) . replace ( 'config.playwire.com' , 'cdn.video.playwire.com' )
  oOOoo0Oo ( 'http:' + oO0Oo )
  if 78 - 78: I11i
  if 71 - 71: OOooOOo + ooOoO0o % i11iIiiIii + I1ii11iIi11i - IiII
  if 88 - 88: OoOoOO00 - OoO0O00 % OOooOOo
def O0o0Ooo ( name , url , mode , iconimage , fanart , description ) :
 if 16 - 16: I1IiiI * oO0o % IiII
 Oo000o = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage ) + "&fanart=" + urllib . quote_plus ( fanart ) + "&description=" + urllib . quote_plus ( description )
 I11IiI1I11i1i = True
 iI1ii1Ii = xbmcgui . ListItem ( name , iconImage = "DefaultFolder.png" , thumbnailImage = iconimage )
 iI1ii1Ii . setInfo ( type = "Video" , infoLabels = { "Title" : name , "Plot" : description } )
 iI1ii1Ii . setProperty ( "Fanart_Image" , fanart )
 I11IiI1I11i1i = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = Oo000o , listitem = iI1ii1Ii , isFolder = False )
 return I11IiI1I11i1i
 if 92 - 92: OoOoOO00
def OO0O00 ( name , url , mode , iconimage , fanart , description ) :
 if 26 - 26: iII111i . I1Ii111
 Oo000o = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage ) + "&fanart=" + urllib . quote_plus ( fanart ) + "&description=" + urllib . quote_plus ( description )
 I11IiI1I11i1i = True
 iI1ii1Ii = xbmcgui . ListItem ( name , iconImage = "DefaultFolder.png" , thumbnailImage = iconimage )
 iI1ii1Ii . setInfo ( type = "Video" , infoLabels = { "Title" : name , "Plot" : description } )
 iI1ii1Ii . setProperty ( "Fanart_Image" , fanart )
 I11IiI1I11i1i = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = Oo000o , listitem = iI1ii1Ii , isFolder = True )
 return I11IiI1I11i1i
 if 68 - 68: OoO0O00
def IIi1iIIiI ( ) :
 try :
  O0OoO = getSet ( "core-player" )
  if ( O0OoO == 'DVDPLAYER' ) : OO = xbmc . PLAYER_CORE_DVDPLAYER
  elif ( O0OoO == 'MPLAYER' ) : OO = xbmc . PLAYER_CORE_MPLAYER
  elif ( O0OoO == 'PAPLAYER' ) : OO = xbmc . PLAYER_CORE_PAPLAYER
  else : OO = xbmc . PLAYER_CORE_AUTO
 except : OO = xbmc . PLAYER_CORE_AUTO
 return OO
 return True
 if 50 - 50: Ii1I / Oo0Ooo - oO0o - I11i % iII111i - oO0o
def OOO0o ( ) :
 IiI1 = [ ]
 Oo0O00Oo0o0 = sys . argv [ 2 ]
 if len ( Oo0O00Oo0o0 ) >= 2 :
  O00O0oOO00O00 = sys . argv [ 2 ]
  i1 = O00O0oOO00O00 . replace ( '?' , '' )
  if ( O00O0oOO00O00 [ len ( O00O0oOO00O00 ) - 1 ] == '/' ) :
   O00O0oOO00O00 = O00O0oOO00O00 [ 0 : len ( O00O0oOO00O00 ) - 2 ]
  Oo00 = i1 . split ( '&' )
  IiI1 = { }
  for i1i in range ( len ( Oo00 ) ) :
   iiI111I1iIiI = { }
   iiI111I1iIiI = Oo00 [ i1i ] . split ( '=' )
   if ( len ( iiI111I1iIiI ) ) == 2 :
    IiI1 [ iiI111I1iIiI [ 0 ] ] = iiI111I1iIiI [ 1 ]
    if 41 - 41: Oo0Ooo . ooOoO0o + O0 * o0oOOo0O0Ooo % Oo0Ooo * Oo0Ooo
 return IiI1
 if 19 - 19: iII111i
O00O0oOO00O00 = OOO0o ( )
O0O = None
I11i1 = None
IIi1iiIi1 = None
iii1i1iiiiIi = None
Iiii = None
if 75 - 75: OoOoOO00 % o0oOOo0O0Ooo % o0oOOo0O0Ooo . I1Ii111
if 5 - 5: o0oOOo0O0Ooo * ooOoO0o + OoOoOO00 . OOooOOo + OoOoOO00
try :
 O0O = urllib . unquote_plus ( O00O0oOO00O00 [ "url" ] )
except :
 pass
try :
 I11i1 = urllib . unquote_plus ( O00O0oOO00O00 [ "name" ] )
except :
 pass
try :
 IIi1iiIi1 = urllib . unquote_plus ( O00O0oOO00O00 [ "iconimage" ] )
except :
 pass
try :
 iii1i1iiiiIi = int ( O00O0oOO00O00 [ "mode" ] )
except :
 pass
try :
 oO = urllib . unquote_plus ( O00O0oOO00O00 [ "fanart" ] )
except :
 pass
try :
 Iiii = urllib . unquote_plus ( O00O0oOO00O00 [ "description" ] )
except :
 pass
 if 7 - 7: o0oOOo0O0Ooo - I1IiiI
 if 100 - 100: oO0o + I11i . OOooOOo * Ii1I
print str ( OOoO00o ) + ': ' + str ( II111iiiiII )
print "Mode: " + str ( iii1i1iiiiIi )
print "URL: " + str ( O0O )
print "Name: " + str ( I11i1 )
print "IconImage: " + str ( IIi1iiIi1 )
if 73 - 73: i1IIi + I1IiiI
def oOOoo0Oo ( url ) :
 iII = xbmc . Player ( IIi1iIIiI ( ) )
 import urlresolver
 try : iII . play ( url )
 except : pass
 if 38 - 38: I1Ii111
def O0o0Oo ( url ) :
 Ii1 = urllib2 . Request ( url )
 oOoOo00oOo = 'Mozilla/5.0 (Windows NT 6.1; WOW64; Trident/7.0; AS; rv:11.0) like Gecko'
 Oo = 'Mozilla/5.0 (Windows NT 6.3; rv:36.0) Gecko/20100101 Firefox/36.0'
 o00O00O0O0O = 'Mozilla/5.0 (iPhone; CPU iPhone OS 6_0 like Mac OS X) AppleWebKit/536.26 (KHTML, like Gecko) Version/6.0 Mobile/10A5376e Safari/8536.25'
 OooO0OO = 'Mozilla/5.0 (Linux; Android 4.4.2; Nexus 4 Build/KOT49H) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/34.0.1847.114 Mobile Safari/537.36'
 Ii1 . add_header ( 'User-Agent' , 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3' )
 OOooOO000 = urllib2 . urlopen ( Ii1 )
 OOoOoo = OOooOO000 . read ( )
 OOooOO000 . close ( )
 return OOoOoo
 if 85 - 85: I1ii11iIi11i % iII111i % ooOoO0o
def iIii11I ( content , viewType ) :
 if content :
  xbmcplugin . setContent ( int ( sys . argv [ 1 ] ) , content )
  if 82 - 82: i11iIiiIii - iII111i * OoooooooOO / I11i
  if 31 - 31: IiII . OoO0O00 - iIii1I11I1II1
if iii1i1iiiiIi == None : oo ( )
elif iii1i1iiiiIi == 1 : Ii1i11IIii1I ( O0O )
elif iii1i1iiiiIi == 2 : O00oO ( O0O )
elif iii1i1iiiiIi == 3 : Iii111II ( )
elif iii1i1iiiiIi == 4 : Ii11iI1i ( )
elif iii1i1iiiiIi == 5 : I11ii1 ( O0O )
if 64 - 64: I11i
xbmcplugin . endOfDirectory ( int ( sys . argv [ 1 ] ) )
# dd678faae9ac167bc83abf78e5cb2f3f0688d3a3
