if 64 - 64: i11iIiiIii
if 65 - 65: O0 / iIii1I11I1II1 % OoooooooOO - i1IIi
if 73 - 73: II111iiii
if 22 - 22: I1IiiI * Oo0Ooo / OoO0O00 . OoOoOO00 . o0oOOo0O0Ooo / I1ii11iIi11i
if 48 - 48: oO0o / OOooOOo / I11i / Ii1I
if 48 - 48: iII111i % IiII + I1Ii111 / ooOoO0o * Ii1I
if 46 - 46: ooOoO0o * I11i - OoooooooOO
if 30 - 30: o0oOOo0O0Ooo - O0 % o0oOOo0O0Ooo - OoooooooOO * O0 * OoooooooOO
if 60 - 60: iIii1I11I1II1 / i1IIi * oO0o - I1ii11iIi11i + o0oOOo0O0Ooo
if 94 - 94: i1IIi % Oo0Ooo
if 68 - 68: Ii1I / O0
if 46 - 46: O0 * II111iiii / IiII * Oo0Ooo * iII111i . I11i
if 62 - 62: i11iIiiIii - II111iiii % I1Ii111 - iIii1I11I1II1 . I1ii11iIi11i . II111iiii
if 61 - 61: oO0o / OoOoOO00 / iII111i * OoO0O00 . II111iiii
if 1 - 1: II111iiii - I1ii11iIi11i % i11iIiiIii + IiII . I1Ii111
if 55 - 55: iIii1I11I1II1 - I1IiiI . Ii1I * IiII * i1IIi / iIii1I11I1II1
import sys
import urlparse
import urllib , urllib2 , datetime , re , os , base64 , xbmc , xbmcplugin , xbmcgui , xbmcaddon , xbmcvfs , traceback , cookielib , urlparse , httplib , time
import urlresolver
import time
from datetime import datetime
if 79 - 79: oO0o + I1Ii111 . ooOoO0o * IiII % I11i . I1IiiI
O0o0o00o0Oo0 = xbmcgui . Dialog ( )
ii11 = base64 . decodestring
I1I1i1 = 'plugin.audio.kidible'
IiI1i = sys . argv [ 0 ]
OOo0o0 = int ( sys . argv [ 1 ] )
O0OoOoo00o = urlparse . parse_qs ( sys . argv [ 2 ] [ 1 : ] )
iiiI11 = "Kidible"
OOooO = "1.0.1"
OOoO00o = 'Mozilla/5.0 (Windows NT 6.1; WOW64; Trident/7.0; AS; rv:11.0) like Gecko'
II111iiiiII = 'Mozilla/5.0 (Windows NT 6.3; rv:36.0) Gecko/20100101 Firefox/36.0'
oOoOo00oOo = 'Mozilla/5.0 (iPhone; CPU iPhone OS 6_0 like Mac OS X) AppleWebKit/536.26 (KHTML, like Gecko) Version/6.0 Mobile/10A5376e Safari/8536.25'
Oo = 'Mozilla/5.0 (Linux; Android 4.4.2; Nexus 4 Build/KOT49H) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/34.0.1847.114 Mobile Safari/537.36'
if 85 - 85: OOooOOo % I1ii11iIi11i * ooOoO0o
OO0O00OooO = xbmc . translatePath ( os . path . join ( 'special://home' , 'addons' , '' ) )
OoooooOoo = os . path . join ( OO0O00OooO , I1I1i1 , 'resources' , 'art' ) + os . sep
OO = xbmc . translatePath ( os . path . join ( OO0O00OooO , I1I1i1 , 'fanart.jpg' ) )
oO0O = base64 . decodestring ( 'LnBocA==' )
OOoO000O0OO = base64 . decodestring ( 'aHR0cDovL2JhY2syYmFzaWNzYnVpbGQuY28udWsvdGVzdC8=' )
if 23 - 23: i11iIiiIii + I1IiiI
if 68 - 68: OoOoOO00 . oO0o . i11iIiiIii
def II ( ) :
 iI ( 'A-Z' , '' , 7 , OoooooOoo + 'icon.png' , OoooooOoo + 'fanart.jpg' , '' )
 iI ( 'All' , '' , 3 , OoooooOoo + 'icon.png' , OoooooOoo + 'fanart.jpg' , '' )
 iI ( 'Search' , '' , 14 , OoooooOoo + 'icon.png' , OoooooOoo + 'fanart.jpg' , '' )
 if 22 - 22: Oo0Ooo % Ii1I
def oo ( ) :
 OO0O00 = ii1 ( ii11 ( 'aHR0cDovL3d3dy5raWRzYXVkaW9ib29rcy5jby51ay9tcDNfZG93bmxvYWRzLmh0bQ==' ) )
 o0oO0o00oo = re . compile ( '<td width=".+?" align="center">.+?<a href="(.*?)">.+?<img border="0" src="images/Squeeze%20(.*?).gif" width="74" height=".*?"></a></td>' , re . DOTALL ) . findall ( OO0O00 )
 for II1i1Ii11Ii11 , iII11i in o0oO0o00oo :
  print '<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<' + II1i1Ii11Ii11 + '>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>'
  if '-x' in iII11i :
   pass
  else :
   iI ( iII11i , ( ii11 ( 'aHR0cDovL3d3dy5raWRzYXVkaW9ib29rcy5jby51ay8=' ) ) + ( II1i1Ii11Ii11 ) . replace ( 'colour_it' , 'books_audio/audio_books_a' ) , 8 , ( ii11 ( 'aHR0cDovL3d3dy5raWRzYXVkaW9ib29rcy5jby51ay9pbWFnZXMvU3F1ZWV6ZSUyMA==' ) ) + iII11i + '.gif' , OoooooOoo + 'fanart.jpg' , '' )
   if 97 - 97: I11i % I11i + II111iiii * iII111i
 xbmcplugin . addSortMethod ( OOo0o0 , xbmcplugin . SORT_METHOD_TITLE ) ;
 if 54 - 54: I11i + IiII / iII111i
 if 9 - 9: OoOoOO00 / Oo0Ooo - IiII . i1IIi / I1IiiI % IiII
def o0 ( url ) :
 OO0O00 = ii1 ( url )
 o0oO0o00oo = re . compile ( '<td width=".*?" height=".*?"><b>.*?<a href="(.*?)">(.*?)</a></b></td>' , re . DOTALL ) . findall ( OO0O00 )
 for url , I11II1i in o0oO0o00oo :
  if '</a>' in I11II1i :
   pass
  elif '(' in I11II1i :
   iI ( ( I11II1i ) . replace ( '&nbsp;' , '' ) . replace ( '  ' , '' ) . replace ( '.mp3' , '' ) , ii11 ( 'aHR0cDovL3d3dy5raWRzYXVkaW9ib29rcy5jby51ay9ib29rc19hdWRpby8=' ) + url , 5 , OoooooOoo + 'icon.png' , OoooooOoo + 'fanart.jpg' , '' )
  else :
   IIIII ( ( I11II1i ) . replace ( '&nbsp;' , '' ) . replace ( '  ' , '' ) . replace ( '.mp3' , '' ) , ii11 ( 'aHR0cDovL3d3dy5raWRzYXVkaW9ib29rcy5jby51ay9ib29rc19hdWRpby8=' ) + url , 4 , OoooooOoo + 'icon.png' , OoooooOoo + 'fanart.jpg' , '' )
   if 75 - 75: II111iiii % II111iiii
 xbmcplugin . addSortMethod ( OOo0o0 , xbmcplugin . SORT_METHOD_TITLE ) ;
 if 13 - 13: o0oOOo0O0Ooo . Ii1I
def i11Iiii ( ) :
 iII1i1I1II = O0o0o00o0Oo0 . input ( 'Search' , type = xbmcgui . INPUT_ALPHANUM )
 i1 = iII1i1I1II . lower ( )
 OO0O00 = ii1 ( ii11 ( 'aHR0cDovL3d3dy5raWRzYXVkaW9ib29rcy5jby51ay9jb21wbGV0ZV9saXN0Lmh0bQ==' ) )
 o0oO0o00oo = re . compile ( '<td width=".+?">.*?<b>.+?<a href="(.*?)">(.*?)</a></b></td>' , re . DOTALL ) . findall ( OO0O00 )
 for II1i1Ii11Ii11 , I11II1i in o0oO0o00oo :
  if iII1i1I1II in I11II1i . lower ( ) :
   if '</a>' in I11II1i :
    pass
   elif '(' in I11II1i :
    iI ( ( I11II1i ) . replace ( '&nbsp;' , '' ) . replace ( '  ' , '' ) . replace ( '+' , '' ) . replace ( '.mp3' , '' ) , ii11 ( 'aHR0cDovL3d3dy5raWRzYXVkaW9ib29rcy5jby51ay8=' ) + II1i1Ii11Ii11 , 5 , OoooooOoo + 'icon.png' , OoooooOoo + 'fanart.jpg' , '' )
   else :
    IIIII ( ( I11II1i ) . replace ( '&nbsp;' , '' ) . replace ( '  ' , '' ) . replace ( '+' , '' ) . replace ( '.mp3' , '' ) , ii11 ( 'aHR0cDovL3d3dy5raWRzYXVkaW9ib29rcy5jby51ay8=' ) + II1i1Ii11Ii11 , 4 , OoooooOoo + 'icon.png' , OoooooOoo + 'fanart.jpg' , '' )
    if 48 - 48: O0 + O0 - I1ii11iIi11i . ooOoO0o / iIii1I11I1II1
    if 77 - 77: i1IIi % OoOoOO00 - IiII + ooOoO0o
def I11iiIiii ( ) :
 OO0O00 = ii1 ( ii11 ( 'aHR0cDovL3d3dy5raWRzYXVkaW9ib29rcy5jby51ay9jb21wbGV0ZV9saXN0Lmh0bQ==' ) )
 o0oO0o00oo = re . compile ( '<td width=".+?">.*?<b>.+?<a href="(.*?)">(.*?)</a></b></td>' , re . DOTALL ) . findall ( OO0O00 )
 for II1i1Ii11Ii11 , I11II1i in o0oO0o00oo :
  if '</a>' in I11II1i :
   pass
  elif '(' in I11II1i :
   iI ( ( I11II1i ) . replace ( '&nbsp;' , '' ) . replace ( '  ' , '' ) . replace ( '+' , '' ) . replace ( '.mp3' , '' ) , ii11 ( 'aHR0cDovL3d3dy5raWRzYXVkaW9ib29rcy5jby51ay8=' ) + II1i1Ii11Ii11 , 5 , OoooooOoo + 'icon.png' , OoooooOoo + 'fanart.jpg' , '' )
  else :
   IIIII ( ( I11II1i ) . replace ( '&nbsp;' , '' ) . replace ( '  ' , '' ) . replace ( '+' , '' ) . replace ( '.mp3' , '' ) , ii11 ( 'aHR0cDovL3d3dy5raWRzYXVkaW9ib29rcy5jby51ay8=' ) + II1i1Ii11Ii11 , 4 , OoooooOoo + 'icon.png' , OoooooOoo + 'fanart.jpg' , '' )
   if 1 - 1: II111iiii - I11i / I11i
 xbmcplugin . addSortMethod ( OOo0o0 , xbmcplugin . SORT_METHOD_TITLE ) ;
 if 46 - 46: Ii1I * OOooOOo - OoO0O00 * oO0o - I1Ii111
 if 83 - 83: OoooooooOO
def Iii111II ( url ) :
 OO0O00 = ii1 ( url )
 o0oO0o00oo = re . compile ( '<a href="(.+?)">Download</a></b></td>' ) . findall ( OO0O00 )
 for url in o0oO0o00oo :
  iiii11I = ( ii11 ( 'aHR0cDovL3d3dy5raWRzYXVkaW9ib29rcy5jby51ay9ib29rc19hdWRpby8=' ) ) + url
  Ooo0OO0oOO ( iiii11I )
  if 50 - 50: I1IiiI
def Ii1i11IIii1I ( url ) :
 OO0O00 = ii1 ( url )
 o0oO0o00oo = re . compile ( '<td width="247">(.*?)</td>.*?<a href="(.+?)">' , re . DOTALL ) . findall ( OO0O00 )
 for I11II1i , url in o0oO0o00oo :
  if '<p align' in I11II1i :
   pass
  elif '&nbsp;' in I11II1i :
   pass
  else :
   IIIII ( ( I11II1i ) . replace ( '&nbsp;' , '' ) , ii11 ( 'aHR0cDovL3d3dy5raWRzYXVkaW9ib29rcy5jby51ay9ib29rc19hdWRpby8=' ) + url , 2 , OoooooOoo + 'icon.png' , OoooooOoo + 'fanart.jpg' , '' )
   if 52 - 52: o0oOOo0O0Ooo - OoooooooOO + Ii1I + Ii1I - o0oOOo0O0Ooo / I1Ii111
 xbmcplugin . addSortMethod ( OOo0o0 , xbmcplugin . SORT_METHOD_TITLE ) ;
 if 44 - 44: ooOoO0o . i1IIi - I1ii11iIi11i . O0 - ooOoO0o
def IIIII ( name , url , mode , iconimage , fanart , description ) :
 if 92 - 92: iII111i . I11i + o0oOOo0O0Ooo
 IiII1I11i1I1I = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage ) + "&fanart=" + urllib . quote_plus ( fanart ) + "&description=" + urllib . quote_plus ( description )
 oO0Oo = True
 oOOoo0Oo = xbmcgui . ListItem ( name , iconImage = "DefaultFolder.png" , thumbnailImage = iconimage )
 oOOoo0Oo . setInfo ( type = "Video" , infoLabels = { "Title" : name , "Plot" : description } )
 oOOoo0Oo . setProperty ( "Fanart_Image" , fanart )
 oO0Oo = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = IiII1I11i1I1I , listitem = oOOoo0Oo , isFolder = False )
 return oO0Oo
 if 78 - 78: I11i
def iI ( name , url , mode , iconimage , fanart , description ) :
 if 71 - 71: OOooOOo + ooOoO0o % i11iIiiIii + I1ii11iIi11i - IiII
 IiII1I11i1I1I = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage ) + "&fanart=" + urllib . quote_plus ( fanart ) + "&description=" + urllib . quote_plus ( description )
 oO0Oo = True
 oOOoo0Oo = xbmcgui . ListItem ( name , iconImage = "DefaultFolder.png" , thumbnailImage = iconimage )
 oOOoo0Oo . setInfo ( type = "Video" , infoLabels = { "Title" : name , "Plot" : description } )
 oOOoo0Oo . setProperty ( "Fanart_Image" , fanart )
 oO0Oo = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = IiII1I11i1I1I , listitem = oOOoo0Oo , isFolder = True )
 return oO0Oo
 if 88 - 88: OoOoOO00 - OoO0O00 % OOooOOo
def iI1I111Ii111i ( ) :
 I11IiI1I11i1i = [ ]
 iI1ii1Ii = sys . argv [ 2 ]
 if len ( iI1ii1Ii ) >= 2 :
  oooo000 = sys . argv [ 2 ]
  iIIIi1 = oooo000 . replace ( '?' , '' )
  if ( oooo000 [ len ( oooo000 ) - 1 ] == '/' ) :
   oooo000 = oooo000 [ 0 : len ( oooo000 ) - 2 ]
  iiII1i1 = iIIIi1 . split ( '&' )
  I11IiI1I11i1i = { }
  for o00oOO0o in range ( len ( iiII1i1 ) ) :
   OOO00O = { }
   OOO00O = iiII1i1 [ o00oOO0o ] . split ( '=' )
   if ( len ( OOO00O ) ) == 2 :
    I11IiI1I11i1i [ OOO00O [ 0 ] ] = OOO00O [ 1 ]
    if 84 - 84: oO0o * OoO0O00 / I11i - O0
 return I11IiI1I11i1i
 if 30 - 30: iIii1I11I1II1 / ooOoO0o - I1Ii111 - II111iiii % iII111i
oooo000 = iI1I111Ii111i ( )
II1i1Ii11Ii11 = None
I11II1i = None
IIi1i11111 = None
ooOO00O00oo = None
I1ii11iI = None
if 14 - 14: OoOoOO00 / IiII . OoOoOO00 . I11i % OoO0O00 * I11i
if 16 - 16: OoOoOO00 . ooOoO0o + i11iIiiIii
try :
 II1i1Ii11Ii11 = urllib . unquote_plus ( oooo000 [ "url" ] )
except :
 pass
try :
 I11II1i = urllib . unquote_plus ( oooo000 [ "name" ] )
except :
 pass
try :
 IIi1i11111 = urllib . unquote_plus ( oooo000 [ "iconimage" ] )
except :
 pass
try :
 ooOO00O00oo = int ( oooo000 [ "mode" ] )
except :
 pass
try :
 i1i1I1IIii1II = urllib . unquote_plus ( oooo000 [ "fanart" ] )
except :
 pass
try :
 I1ii11iI = urllib . unquote_plus ( oooo000 [ "description" ] )
except :
 pass
 if 65 - 65: Ii1I . iIii1I11I1II1 / O0 - Ii1I
 if 21 - 21: I1IiiI * iIii1I11I1II1
print str ( iiiI11 ) + ': ' + str ( OOooO )
print "Mode: " + str ( ooOO00O00oo )
print "URL: " + str ( II1i1Ii11Ii11 )
print "Name: " + str ( I11II1i )
print "IconImage: " + str ( IIi1i11111 )
if 91 - 91: IiII
def iiIii ( ) :
 try :
  ooo0O = getSet ( "core-player" )
  if ( ooo0O == 'DVDPLAYER' ) : oOoO0o00OO0 = xbmc . PLAYER_CORE_DVDPLAYER
  elif ( ooo0O == 'MPLAYER' ) : oOoO0o00OO0 = xbmc . PLAYER_CORE_MPLAYER
  elif ( ooo0O == 'PAPLAYER' ) : oOoO0o00OO0 = xbmc . PLAYER_CORE_PAPLAYER
  else : oOoO0o00OO0 = xbmc . PLAYER_CORE_AUTO
 except : oOoO0o00OO0 = xbmc . PLAYER_CORE_AUTO
 return oOoO0o00OO0
 return True
 if 7 - 7: OOooOOo + I1Ii111 + O0
 if 9 - 9: II111iiii . o0oOOo0O0Ooo - ooOoO0o / o0oOOo0O0Ooo
def Ooo0OO0oOO ( url ) :
 I11 = xbmc . Player ( iiIii ( ) )
 import urlresolver
 try : I11 . play ( url )
 except : pass
 if 66 - 66: i1IIi % i1IIi + OoOoOO00 + O0 + OoO0O00
def ii1 ( url ) :
 o0o = urllib2 . Request ( url )
 OOoO00o = 'Mozilla/5.0 (Windows NT 6.1; WOW64; Trident/7.0; AS; rv:11.0) like Gecko'
 II111iiiiII = 'Mozilla/5.0 (Windows NT 6.3; rv:36.0) Gecko/20100101 Firefox/36.0'
 oOoOo00oOo = 'Mozilla/5.0 (iPhone; CPU iPhone OS 6_0 like Mac OS X) AppleWebKit/536.26 (KHTML, like Gecko) Version/6.0 Mobile/10A5376e Safari/8536.25'
 Oo = 'Mozilla/5.0 (Linux; Android 4.4.2; Nexus 4 Build/KOT49H) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/34.0.1847.114 Mobile Safari/537.36'
 o0o . add_header ( 'User-Agent' , 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3' )
 o00 = urllib2 . urlopen ( o0o )
 OooOO000 = o00 . read ( )
 o00 . close ( )
 return OooOO000
 if 97 - 97: I1ii11iIi11i + OOooOOo / iIii1I11I1II1 / iII111i
def I1111IIi ( content , viewType ) :
 if content :
  xbmcplugin . setContent ( int ( sys . argv [ 1 ] ) , content )
  if 93 - 93: OoooooooOO / I1IiiI % i11iIiiIii + I1ii11iIi11i * OoO0O00
  if 15 - 15: I11i . OoO0O00 / Oo0Ooo + I11i
if ooOO00O00oo == None : II ( )
elif ooOO00O00oo == 2 : Ooo0OO0oOO ( II1i1Ii11Ii11 )
elif ooOO00O00oo == 3 : I11iiIiii ( )
elif ooOO00O00oo == 4 : Iii111II ( II1i1Ii11Ii11 )
elif ooOO00O00oo == 5 : Ii1i11IIii1I ( II1i1Ii11Ii11 )
elif ooOO00O00oo == 6 : Kids_Menu ( )
elif ooOO00O00oo == 7 : oo ( )
elif ooOO00O00oo == 8 : o0 ( II1i1Ii11Ii11 )
elif ooOO00O00oo == 14 : i11Iiii ( )
xbmcplugin . endOfDirectory ( int ( sys . argv [ 1 ] ) )
# dd678faae9ac167bc83abf78e5cb2f3f0688d3a3
