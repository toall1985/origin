if 64 - 64: i11iIiiIii
if 65 - 65: O0 / iIii1I11I1II1 % OoooooooOO - i1IIi
if 73 - 73: II111iiii
if 22 - 22: I1IiiI * Oo0Ooo / OoO0O00 . OoOoOO00 . o0oOOo0O0Ooo / I1ii11iIi11i
if 48 - 48: oO0o / OOooOOo / I11i / Ii1I
if 48 - 48: iII111i % IiII + I1Ii111 / ooOoO0o * Ii1I
if 46 - 46: ooOoO0o * I11i - OoooooooOO
if 30 - 30: o0oOOo0O0Ooo - O0 % o0oOOo0O0Ooo - OoooooooOO * O0 * OoooooooOO
if 60 - 60: iIii1I11I1II1 / i1IIi * oO0o - I1ii11iIi11i + o0oOOo0O0Ooo
if 94 - 94: i1IIi % Oo0Ooo
if 68 - 68: Ii1I / O0
if 46 - 46: O0 * II111iiii / IiII * Oo0Ooo * iII111i . I11i
if 62 - 62: i11iIiiIii - II111iiii % I1Ii111 - iIii1I11I1II1 . I1ii11iIi11i . II111iiii
if 61 - 61: oO0o / OoOoOO00 / iII111i * OoO0O00 . II111iiii
if 1 - 1: II111iiii - I1ii11iIi11i % i11iIiiIii + IiII . I1Ii111
if 55 - 55: iIii1I11I1II1 - I1IiiI . Ii1I * IiII * i1IIi / iIii1I11I1II1
import sys
import urlparse
import yt
import urllib , urllib2 , datetime , re , os , base64 , xbmc , xbmcplugin , xbmcgui , xbmcaddon , xbmcvfs , traceback , cookielib , urlparse , httplib , time
import urlresolver
from bs4 import BeautifulSoup
from BeautifulSoup import BeautifulStoneSoup , BeautifulSOAP
try :
 import json
except :
 import simplejson as json
import time
import requests
from t0mm0 . common . addon import Addon
from t0mm0 . common . net import Net
from resources import streams , lists , utube , TV , Standup , Films , premierleague , Google , client , CNF_Studio_Indexer , Alluc_Indexer , FootballReplays , SoapsCatchup , documentary
from resources import M3Uscrape , search_addon , SEO_INFO , Xvideos
from resources . lib . parsers import TVParser
from datetime import datetime
if 79 - 79: oO0o + I1Ii111 . ooOoO0o * IiII % I11i . I1IiiI
O0o0o00o0Oo0 = base64 . decodestring
ii11 = lists . BASE2
I1I1i1 = lists . BASE3
IiI1i = lists . BASE4
OOo0o0 = lists . BASE5
O0OoOoo00o = lists . BASE6
iiiI11 = lists . BASE7
OOooO = lists . CAT
OOoO00o = lists . BASE
II111iiiiII = 'plugin.video.originentertainment'
oOoOo00oOo = sys . argv [ 0 ]
Oo = int ( sys . argv [ 1 ] )
o00O00O0O0O = urlparse . parse_qs ( sys . argv [ 2 ] [ 1 : ] )
OooO0OO = "Origin Entertainment"
iiiIi = "1.0.1"
IiIIIiI1I1 = 'Mozilla/5.0 (Windows NT 6.1; WOW64; Trident/7.0; AS; rv:11.0) like Gecko'
OoO000 = 'Mozilla/5.0 (Windows NT 6.3; rv:36.0) Gecko/20100101 Firefox/36.0'
IIiiIiI1 = 'Mozilla/5.0 (iPhone; CPU iPhone OS 6_0 like Mac OS X) AppleWebKit/536.26 (KHTML, like Gecko) Version/6.0 Mobile/10A5376e Safari/8536.25'
iiIiIIi = 'Mozilla/5.0 (Linux; Android 4.4.2; Nexus 4 Build/KOT49H) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/34.0.1847.114 Mobile Safari/537.36'
if 65 - 65: OoOoOO00
ii1I = xbmc . translatePath ( os . path . join ( 'special://home' , 'addons' , '' ) )
OooO0 = os . path . join ( ii1I , II111iiiiII , 'resources' , 'art' ) + os . sep
II11iiii1Ii = xbmc . translatePath ( os . path . join ( ii1I , II111iiiiII , 'fanart.jpg' ) )
OO0o = Net ( )
Ooo = [ ]
O0o0Oo = [ ]
Oo00OOOOO = [ ]
O0O = xbmcaddon . Addon ( id = II111iiiiII )
O00o0OO = O0O . getSetting ( 'Password' )
I11i1 = O0o0o00o0Oo0 ( 'aHR0cDovL2JhY2syYmFzaWNzLngxMGhvc3QuY29tL0FkdWx0L2luZGV4LnBocD9tb2RlPVh4WCZwYXNzd29yZD0=' )
iIi1ii1I1 = I11i1 + O00o0OO
o0 = O0o0o00o0Oo0 ( 'aHR0cDovL2lkYS5vbXJvZXAubmwvbnBvcGxheWVyL2kuanM=' )
I11II1i = xbmc . translatePath ( os . path . join ( 'special://home/userdata/addon_data/' + II111iiiiII + 'Article_Dump.txt' ) )
if 23 - 23: I1ii11iIi11i / o0oOOo0O0Ooo + I11i + I11i / II111iiii
if 26 - 26: OoooooooOO
IiiI11Iiiii = os . path . join ( xbmc . translatePath ( "special://userdata/addon_data" ) . decode ( "utf-8" ) , II111iiiiII )
if not os . path . exists ( IiiI11Iiiii ) :
 os . makedirs ( IiiI11Iiiii )
 if 18 - 18: o0oOOo0O0Ooo
I1i1I1II = os . path . join ( IiiI11Iiiii , 'tempList.txt' )
if 45 - 45: I1Ii111 . OoOoOO00
#def ChangeLog():
#    TextBoxes('Change Log, Future Plans and General Info', ' [CR] ---------------------------------------------------------------------------------------------------------- [CR]Going to look at adding TV guide to new live tv streams [CR] ---------------------------------------------------------------------------------------------------------- [CR]Hoping to get search function in soon to make things easier to find [CR] ---------------------------------------------------------------------------------------------------------- [CR]Am thinking of making a second release of the addon once my knowledge grows to tidy things up a bit [CR] ---------------------------------------------------------------------------------------------------------- [CR]11/12/15 Fixed Scraper, still need to work on some streams not playing [CR] ---------------------------------------------------------------------------------------------------------- [CR]Massive thanks and respect to Chris for all his help lately helping me push forwards [CR] ---------------------------------------------------------------------------------------------------------- [CR]Also to Jay, Damian and Sponge head for being here from the start and of course Team H20 [CR] ---------------------------------------------------------------------------------------------------------- [CR]Will look at adding a music section once search function in and working properly [CR] ---------------------------------------------------------------------------------------------------------- [CR]Fixes Needed - Scraper streams not working. Newspaper Article and Prem League table windows not working on android  ')
if 83 - 83: oO0o . iIii1I11I1II1 . I1ii11iIi11i
if 31 - 31: Ii1I . Ii1I - o0oOOo0O0Ooo / OoO0O00 + ooOoO0o * I1IiiI
if 63 - 63: I1Ii111 % i1IIi / OoooooooOO - OoooooooOO
def iIii11I ( query ) :
 return oOoOo00oOo + '?' + urllib . urlencode ( query )
 if 69 - 69: oO0o % I1Ii111 - o0oOOo0O0Ooo + I1Ii111 - O0 % OoooooooOO
def Iii111II ( ) :
 if 9 - 9: OoO0O00
 if 33 - 33: ooOoO0o . iII111i
 O0oo0OO0oOOOo ( '24/7 Shows' , OOoO00o + '24-7' + OOooO , 400 , OooO0 + '24shows.png' )
 if 35 - 35: IiII % I1IiiI
 if 70 - 70: iII111i * I1ii11iIi11i
 if 46 - 46: ooOoO0o / OoO0O00
 OOOoO0O0o ( 'Movies' , '' , 10 , OooO0 + 'movies.png' , OooO0 + 'background.png' , '' )
 if 55 - 55: OOooOOo + ooOoO0o . i1IIi - I1ii11iIi11i . O0 - ooOoO0o
 OOOoO0O0o ( 'Pandoras Box' , '' , 55 , OooO0 + 'pandorasbox.png' , OooO0 + 'background.png' , '' )
 if 92 - 92: iII111i . I11i + o0oOOo0O0Ooo
 if 28 - 28: i1IIi * Oo0Ooo - o0oOOo0O0Ooo * IiII * Ii1I / OoO0O00
 OOOoO0O0o ( 'Search' , '' , 175 , OooO0 + 'search.png' , OooO0 + 'background.png' , '' )
 if 94 - 94: II111iiii % I1ii11iIi11i / OoOoOO00 * iIii1I11I1II1
 if 54 - 54: o0oOOo0O0Ooo - I1IiiI + OoooooooOO
 OOOoO0O0o ( 'Stand Up' , '' , 12 , OooO0 + 'comedy.png' , OooO0 + 'background.png' , '' )
 if 70 - 70: Ii1I / I11i . iII111i % Oo0Ooo
 if 67 - 67: OoOoOO00 * o0oOOo0O0Ooo . IiII - OoO0O00 * o0oOOo0O0Ooo
 OOOoO0O0o ( 'TV Shows' , '' , 11 , OooO0 + 'tv.png' , OooO0 + 'background.png' , '' )
 if 46 - 46: OOooOOo + OoOoOO00 . I1IiiI * oO0o % IiII
 if 86 - 86: I1IiiI + Ii1I % i11iIiiIii * oO0o . ooOoO0o * I11i
 if 44 - 44: oO0o
 if 88 - 88: I1Ii111 % Ii1I . II111iiii
 if 38 - 38: o0oOOo0O0Ooo
def Oo0O ( ) :
 if 25 - 25: OoOoOO00 . II111iiii / iII111i . OOooOOo * OoO0O00 . I1IiiI
 OOOoO0O0o ( 'Football' , '' , 57 , OooO0 + 'icon.png' , OooO0 + 'background.png' , '' )
 OOOoO0O0o ( 'Sports Channels' , '' , 86 , OooO0 + 'icon.png' , OooO0 + 'background.png' , '' )
 if 59 - 59: II111iiii + OoooooooOO * OoOoOO00 + i1IIi
 if 58 - 58: II111iiii * OOooOOo * I1ii11iIi11i / OOooOOo
 xbmcplugin . endOfDirectory ( Oo )
 if 75 - 75: oO0o
 if 50 - 50: Ii1I / Oo0Ooo - oO0o - I11i % iII111i - oO0o
def OOO0o ( ) :
 if 30 - 30: iIii1I11I1II1 / ooOoO0o - I1Ii111 - II111iiii % iII111i
 IIi1i11111 = ooOO00O00oo ( O0o0o00o0Oo0 ( 'aHR0cDovL3d3dy5saXN0ZW5saXZlLmV1Lw==' ) )
 I1ii11iI = re . compile ( '<tr>.+?<a href="(.+?)">(.+?)</a>' , re . DOTALL ) . findall ( IIi1i11111 )
 for IIi1i , I1I1iIiII1 in I1ii11iI :
  O0oo0OO0oOOOo ( ( I1I1iIiII1 ) . replace ( 'email me' , '' ) . replace ( 'External services' , '' ) , O0o0o00o0Oo0 ( 'aHR0cDovL3d3dy5saXN0ZW5saXZlLmV1LyVz' ) % IIi1i , 62 , OooO0 + 'icon.png' )
  if 4 - 4: ooOoO0o + O0 * OOooOOo
  if 55 - 55: Oo0Ooo + iIii1I11I1II1 / OoOoOO00 * oO0o - i11iIiiIii - Ii1I
def ii1ii1ii ( url ) :
 if 91 - 91: IiII
 IIi1i11111 = ooOO00O00oo ( url )
 I1ii11iI = re . compile ( '<tr>.+?<td><a href=".+?"><b>(.+?)</b>.+?<td><a href="(.+?)">' , re . DOTALL ) . findall ( IIi1i11111 )
 for I1I1iIiII1 , url in I1ii11iI :
  iiIii ( I1I1iIiII1 , url , 401 , OooO0 + 'icon.png' )
  if 79 - 79: OoooooooOO / O0
  if 75 - 75: OoOoOO00 % o0oOOo0O0Ooo % o0oOOo0O0Ooo . I1Ii111
def III1iII1I1ii ( ) :
 O0oo0OO0oOOOo ( 'Fixtures' , '' , 58 , OooO0 + 'icon.png' )
 if 61 - 61: II111iiii
 O0OOO ( 'Replays' , '' , 93 , OooO0 + 'icon.png' )
 if 10 - 10: OOooOOo * I11i % OoOoOO00 / I1IiiI / OoOoOO00
 if 42 - 42: OoO0O00
 if 67 - 67: I1Ii111 . iII111i . O0
 if 10 - 10: I1ii11iIi11i % I1ii11iIi11i - iIii1I11I1II1 / OOooOOo + Ii1I
 if 87 - 87: oO0o * I1ii11iIi11i + OOooOOo / iIii1I11I1II1 / iII111i
 if 37 - 37: iII111i - ooOoO0o * oO0o % i11iIiiIii - I1Ii111
 if 83 - 83: I11i / I1IiiI
 if 34 - 34: IiII
 if 57 - 57: oO0o . I11i . i1IIi
def i11Iii ( ) :
 if 16 - 16: II111iiii % OoOoOO00 - II111iiii + Ii1I
 IIi1i11111 = ooOO00O00oo ( O0o0o00o0Oo0 ( 'aHR0cDovL3NlZWR1cmdyZWVkLngxMGhvc3QuY29tL29yaWdpbi9zcG9uZ2VtYWluLnBocA==' ) )
 I1ii11iI = re . compile ( '<item>.+?<title>(.+?)</title>.+?<description>(.+?)</description>.+?<link>(.+?)</link>.+?<thumbnail>(.+?)</thumbnail>.+?<fanart>(.+?)</fanart>.+?<mode>(.+?)</mode>.+?</item>' , re . DOTALL ) . findall ( IIi1i11111 )
 for I1I1iIiII1 , i1I1i , IIi1i , Ii , iii1i , I11i1ii1 in I1ii11iI :
  O0Oooo0O ( I1I1iIiII1 , IIi1i , I11i1ii1 , Ii , iii1i , i1I1i )
  if 84 - 84: iII111i . I1ii11iIi11i / Oo0Ooo - I1IiiI / OoooooooOO / o0oOOo0O0Ooo
def II111iiiI1Ii ( url ) :
 if 78 - 78: Ii1I % I1Ii111 + I1ii11iIi11i
 xbmcplugin . addSortMethod ( handle = int ( sys . argv [ 1 ] ) , sortMethod = xbmcplugin . SORT_METHOD_TITLE )
 OOooOoooOoOo = ( '%s%s' % ( OOoO00o , url ) )
 o0OOOO00O0Oo = ooOO00O00oo ( url )
 I1ii11iI = re . compile ( '<a href="(.+?)" target="_blank"><img src="(.+?)" style="max-width:200px;" /><description = "(.+?)" /><background = "(.+?)" </background></a><br><b>(.+?)</b>' ) . findall ( o0OOOO00O0Oo )
 for url , ii , i1I1i , oOooOOOoOo , I1I1iIiII1 in I1ii11iI :
  O0Oooo0O ( I1I1iIiII1 , url , 401 , ii , oOooOOOoOo , i1I1i )
  if 41 - 41: Ii1I - O0 - O0
  oO00OOoO00 ( 'tvshows' , 'Media Info 3' )
  if 40 - 40: I1IiiI * Ii1I + OOooOOo % iII111i
  xbmcplugin . addSortMethod ( Oo , xbmcplugin . SORT_METHOD_TITLE ) ;
  if 74 - 74: oO0o - Oo0Ooo + OoooooooOO + I1Ii111 / OoOoOO00
  if 23 - 23: O0
def o00oO0oOo00 ( url ) :
 if 81 - 81: OoO0O00
 IIi1i11111 = ooOO00O00oo ( url )
 I1ii11iI = re . compile ( '<item>.+?<title>(.+?)</title>.+?<description>(.+?)</description>.+?<link>(.+?)</link>.+?<thumbnail>(.+?)</thumbnail>.+?<fanart>(.+?)</fanart>.+?<mode>(.+?)</mode>.+?</item>' , re . DOTALL ) . findall ( IIi1i11111 )
 for I1I1iIiII1 , i1I1i , url , Ii , iii1i , I11i1ii1 in I1ii11iI :
  IIi1 ( I1I1iIiII1 , url , I11i1ii1 , Ii , iii1i , i1I1i )
  if 45 - 45: iII111i / iII111i + I1Ii111 + ooOoO0o
 oO00OOoO00 ( 'tvshows' , 'Media Info 3' )
 if 47 - 47: o0oOOo0O0Ooo + ooOoO0o
 if 82 - 82: II111iiii . IiII - iIii1I11I1II1 - IiII * II111iiii
 xbmcplugin . addSortMethod ( Oo , xbmcplugin . SORT_METHOD_TITLE ) ;
 if 77 - 77: iIii1I11I1II1 * OoO0O00
def O0Oooo0O ( name , url , mode , iconimage , fanart , description ) :
 if 95 - 95: I1IiiI + i11iIiiIii
 I1Ii = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage ) + "&fanart=" + urllib . quote_plus ( fanart ) + "&description=" + urllib . quote_plus ( description )
 O0oo00o0O = True
 i1I1I = xbmcgui . ListItem ( name , iconImage = "DefaultFolder.png" , thumbnailImage = iconimage )
 i1I1I . setInfo ( type = "Video" , infoLabels = { "Title" : name , "Plot" : description } )
 i1I1I . setProperty ( "Fanart_Image" , fanart )
 O0oo00o0O = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = I1Ii , listitem = i1I1I , isFolder = False )
 return O0oo00o0O
 if 12 - 12: i11iIiiIii / OoO0O00
def IIi1 ( name , url , mode , iconimage , fanart , description ) :
 if 80 - 80: I1Ii111 . i11iIiiIii - o0oOOo0O0Ooo
 I1Ii = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage ) + "&fanart=" + urllib . quote_plus ( fanart ) + "&description=" + urllib . quote_plus ( description )
 O0oo00o0O = True
 i1I1I = xbmcgui . ListItem ( name , iconImage = "DefaultFolder.png" , thumbnailImage = iconimage )
 i1I1I . setInfo ( type = "Video" , infoLabels = { "Title" : name , "Plot" : description } )
 i1I1I . setProperty ( "Fanart_Image" , fanart )
 O0oo00o0O = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = I1Ii , listitem = i1I1I , isFolder = True )
 return O0oo00o0O
 if 25 - 25: OoO0O00
 if 62 - 62: OOooOOo + O0
 if 98 - 98: o0oOOo0O0Ooo
 if 51 - 51: Oo0Ooo - oO0o + II111iiii * Ii1I . I11i + oO0o
def oO00OOoO00 ( content , viewType ) :
 if content :
  xbmcplugin . setContent ( int ( sys . argv [ 1 ] ) , content )
  if 78 - 78: i11iIiiIii / iII111i - Ii1I / OOooOOo + oO0o
  if 82 - 82: Ii1I
  if 46 - 46: OoooooooOO . i11iIiiIii
def OOo0oO00ooO00 ( ) :
 if 90 - 90: OoOoOO00 * I1Ii111 + o0oOOo0O0Ooo
 O0oo0OO0oOOOo ( 'List 1' , '' , 411 , OooO0 + 'icon.png' )
 O0oo0OO0oOOOo ( 'List 2' , '' , 413 , OooO0 + 'icon.png' )
 O0oo0OO0oOOOo ( 'List 3' , '' , 414 , OooO0 + 'icon.png' )
 O0oo0OO0oOOOo ( 'List 4' , '' , 415 , OooO0 + 'icon.png' )
 O0oo0OO0oOOOo ( 'List 5' , '' , 416 , OooO0 + 'icon.png' )
 if 81 - 81: oO0o . o0oOOo0O0Ooo % O0 / I1IiiI - oO0o
 if 43 - 43: i11iIiiIii + Oo0Ooo * II111iiii * I1Ii111 * O0
def o00oO0oo0OO ( ) :
 if 57 - 57: I1Ii111 % Ii1I + o0oOOo0O0Ooo - Oo0Ooo
 O0oo0OO0oOOOo ( 'Test Area' , OOoO00o + 'test' + OOooO , 400 , OooO0 + 'icon.png' )
 O0oo0OO0oOOOo ( 'Sponge Test' , OOo0o0 + 'badlands' + OOooO , 400 , OooO0 + 'icon.png' )
 O0oo0OO0oOOOo ( 'Dizilab Scraper Test' , '' , 410 , OooO0 + 'icon.png' )
 if 65 - 65: I11i . OoOoOO00
 if 39 - 39: II111iiii / ooOoO0o + I1Ii111 / OoOoOO00
 xbmcplugin . endOfDirectory ( Oo )
 if 13 - 13: IiII + O0 + iII111i % I1IiiI / o0oOOo0O0Ooo . IiII
 if 86 - 86: oO0o * o0oOOo0O0Ooo % i1IIi . Ii1I . i11iIiiIii
 if 56 - 56: I1ii11iIi11i % O0 - I1IiiI
 if 100 - 100: Ii1I - O0 % oO0o * OOooOOo + I1IiiI
def OOOoO0O0o ( name , url , mode , iconimage , fanart , description ) :
 I1Ii = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage ) + "&fanart=" + urllib . quote_plus ( fanart ) + "&description=" + urllib . quote_plus ( description )
 O0oo00o0O = True
 i1I1I = xbmcgui . ListItem ( name , iconImage = "DefaultFolder.png" , thumbnailImage = iconimage )
 i1I1I . setInfo ( type = "Video" , infoLabels = { "Title" : name , "Plot" : description } )
 i1I1I . setProperty ( "Fanart_Image" , fanart )
 if mode == 5 :
  O0oo00o0O = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = I1Ii , listitem = i1I1I , isFolder = False )
 else :
  O0oo00o0O = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = I1Ii , listitem = i1I1I , isFolder = True )
  if 88 - 88: OoooooooOO - OoO0O00 * O0 * OoooooooOO . OoooooooOO
 return O0oo00o0O
 if 33 - 33: I1Ii111 + iII111i * oO0o / iIii1I11I1II1 - I1IiiI
 if 54 - 54: I1Ii111 / OOooOOo . oO0o % iII111i
def O0OOO ( name , url , mode , iconimage ) :
 I1Ii = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name )
 O0oo00o0O = True
 i1I1I = xbmcgui . ListItem ( name , iconImage = "DefaultFolder.png" , thumbnailImage = iconimage )
 i1I1I . setInfo ( type = "Video" , infoLabels = { "Title" : name } )
 O0oo00o0O = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = I1Ii , listitem = i1I1I , isFolder = True )
 return O0oo00o0O
 if 57 - 57: i11iIiiIii . I1ii11iIi11i - Ii1I - oO0o + OoOoOO00
def iiIii ( name , url , mode , iconimage ) :
 I1Ii = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name )
 O0oo00o0O = True
 i1I1I = xbmcgui . ListItem ( name , iconImage = "DefaultFolder.png" , thumbnailImage = iconimage )
 i1I1I . setInfo ( type = "Video" , infoLabels = { "Title" : name } )
 O0oo00o0O = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = I1Ii , listitem = i1I1I , isFolder = False )
 return O0oo00o0O
if 63 - 63: OoOoOO00 * iII111i
if 69 - 69: O0 . OoO0O00
if 49 - 49: I1IiiI - I11i
if 74 - 74: iIii1I11I1II1 * I1ii11iIi11i + OoOoOO00 / i1IIi / II111iiii . Oo0Ooo
if 62 - 62: OoooooooOO * I1IiiI
if 58 - 58: OoOoOO00 % o0oOOo0O0Ooo
if 50 - 50: I1Ii111 . o0oOOo0O0Ooo
if 97 - 97: O0 + OoOoOO00
if 89 - 89: o0oOOo0O0Ooo + OoO0O00 * I11i * Ii1I
def iiIiI1i1 ( ) :
 IIi1i11111 = ooOO00O00oo ( 'http://back2basics.x10host.com/back2basics/test/m3u1.m3u' )
 I1ii11iI = re . compile ( '^#EXTINF:-?[0-9]*(.*?),(.*?)\n(.*?)$' , re . I + re . M + re . U + re . S ) . findall ( IIi1i11111 )
 for oO0O00oOOoooO , I1I1iIiII1 , IIi1i in I1ii11iI :
  iiIii ( I1I1iIiII1 , IIi1i , 401 , OooO0 + 'icon.png' )
  if 46 - 46: I1IiiI - OoooooooOO - I11i * II111iiii
def I1i1I11I ( ) :
 IIi1i11111 = ooOO00O00oo ( 'http://back2basics.x10host.com/back2basics/test/m3u2.m3u' )
 I1ii11iI = re . compile ( '^#EXTINF:-?[0-9]*(.*?),(.*?)\n(.*?)$' , re . I + re . M + re . U + re . S ) . findall ( IIi1i11111 )
 for oO0O00oOOoooO , I1I1iIiII1 , IIi1i in I1ii11iI :
  iiIii ( I1I1iIiII1 , IIi1i , 401 , OooO0 + 'icon.png' )
  if 80 - 80: i11iIiiIii % ooOoO0o + Ii1I % I11i - I1ii11iIi11i
def I1i1i1iii ( ) :
 IIi1i11111 = ooOO00O00oo ( 'http://back2basics.x10host.com/back2basics/test/m3u3.m3u' )
 I1ii11iI = re . compile ( '^#EXTINF:-?[0-9]*(.*?),(.*?)\n(.*?)$' , re . I + re . M + re . U + re . S ) . findall ( IIi1i11111 )
 for oO0O00oOOoooO , I1I1iIiII1 , IIi1i in I1ii11iI :
  iiIii ( I1I1iIiII1 , IIi1i , 401 , OooO0 + 'icon.png' )
  if 16 - 16: Ii1I + IiII * O0 % i1IIi . I1IiiI
def Oo0OO ( ) :
 IIi1i11111 = ooOO00O00oo ( 'http://back2basics.x10host.com/back2basics/test/m3u4.m3u' )
 I1ii11iI = re . compile ( '^#EXTINF:-?[0-9]*(.*?),(.*?)\n(.*?)$' , re . I + re . M + re . U + re . S ) . findall ( IIi1i11111 )
 for oO0O00oOOoooO , I1I1iIiII1 , IIi1i in I1ii11iI :
  iiIii ( I1I1iIiII1 , IIi1i , 401 , OooO0 + 'icon.png' )
  if 78 - 78: OOooOOo - OoooooooOO - I1ii11iIi11i / ooOoO0o / II111iiii
def iiI11ii1I1 ( ) :
 IIi1i11111 = ooOO00O00oo ( 'http://back2basics.x10host.com/back2basics/test/m3u5.m3u' )
 I1ii11iI = re . compile ( '^#EXTINF:-?[0-9]*(.*?),(.*?)\n(.*?)$' , re . I + re . M + re . U + re . S ) . findall ( IIi1i11111 )
 for oO0O00oOOoooO , I1I1iIiII1 , IIi1i in I1ii11iI :
  iiIii ( I1I1iIiII1 , IIi1i , 401 , OooO0 + 'icon.png' )
  if 82 - 82: II111iiii % I11i / OoO0O00 + OoOoOO00 / o0oOOo0O0Ooo / I1Ii111
  if 70 - 70: oO0o
  if 59 - 59: o0oOOo0O0Ooo % oO0o
  if 6 - 6: iIii1I11I1II1 % i11iIiiIii % I1ii11iIi11i
  if 93 - 93: IiII * OoooooooOO + ooOoO0o
def IiII111i1i11 ( ) :
 IIi1i11111 = ooOO00O00oo ( O0o0o00o0Oo0 ( 'aHR0cDovL2xpdmVvbnNhdC5jb20vcXVpY2tpbmRleC5odG1s' ) )
 I1ii11iI = re . compile ( '<a target="_self" href="(.+?)".+?src="(.+?)" alt="(.+?)"' , re . DOTALL ) . findall ( IIi1i11111 )
 for IIi1i , Ii , I1I1iIiII1 in I1ii11iI :
  O0OOO ( ( I1I1iIiII1 ) . replace ( 'amp;' , '' ) , O0o0o00o0Oo0 ( 'aHR0cDovL2xpdmVvbnNhdC5jb20v' ) + IIi1i , 59 , O0o0o00o0Oo0 ( 'aHR0cDovL2xpdmVvbnNhdC5jb20v' ) + Ii )
  if 40 - 40: ooOoO0o * IiII * i11iIiiIii
def oo0OO00OoooOo ( url ) :
 II1i111Ii1i = ooOO00O00oo ( url )
 iii1 = re . compile ( 'AndClearL.+?><h2.+?head>(.*?)float' , re . DOTALL ) . findall ( II1i111Ii1i )
 for iii1 in iii1 :
  ooO0oooOO0 = re . compile ( '(.*?)</h2>' ) . findall ( str ( iii1 ) )
  for o0o in ooO0oooOO0 :
   o0o = o0o
  oo0 = re . compile ( 'comp_head>(.*?)</span>.*?<div class = fLeft width = ".*?"><img src="(.*?)">.*?</div>.*?ST:(.*?)</div>(.+?)<!-- around all of channel types ENDS 2-->' , re . DOTALL ) . findall ( str ( iii1 ) )
  for oOOOoo00 , Ii , time , iiIiIIIiiI in oo0 :
   iiI1IIIi = re . compile ( ",CAPTION, '(.+?)&nbsp" ) . findall ( iiIiIIIiiI )
   IIi1 ( o0o + ' - ' + oOOOoo00 + ' - ' + time , '' , 65 , O0o0o00o0Oo0 ( 'aHR0cDovL2xpdmVvbnNhdC5jb20=' ) + Ii , '' , ( str ( iiI1IIIi ) ) )
   if 47 - 47: Oo0Ooo % I11i % i11iIiiIii - O0 + ooOoO0o
 oO00OOoO00 ( 'tvshows' , 'Media Info 3' )
 if 94 - 94: I1Ii111
def i11II1I11I1 ( ) :
 if 67 - 67: I1IiiI - o0oOOo0O0Ooo / I11i - i1IIi
 if 1 - 1: II111iiii
 OOOoO0O0o ( 'Basic' , '' , 65 , OooO0 + 'tvguide.png' , OooO0 + 'background.png' , '' )
 OOOoO0O0o ( 'Full' , '' , 71 , OooO0 + 'tvguide.png' , OooO0 + 'background.png' , '' )
 OOOoO0O0o ( 'Sky Basic' , '' , 70 , OooO0 + 'tvguide.png' , OooO0 + 'background.png' , '' )
 if 68 - 68: iII111i - I1IiiI / I1Ii111 / I11i
 if 12 - 12: Ii1I + i11iIiiIii * iIii1I11I1II1 / I1ii11iIi11i . I11i
def Iii1iI ( ) :
 IIi1i11111 = ooOO00O00oo ( 'http://www.locatetv.com/uk/listings/sky' )
 I1ii11iI = re . compile ( '<li>.+?<li class="channel" data-name="(.+?)">.+?<a href="(.+?)">.+?<img src="(.+?)" alt=".+?title="(.+?)" class' , re . DOTALL ) . findall ( IIi1i11111 )
 for I1I1iIiII1 , IIi1i , Ii , IiI1iiiIii in I1ii11iI :
  O0OOO ( ( I1I1iIiII1 + ' - ' + IiI1iiiIii ) . replace ( '&#039;s' , '' ) . replace ( '&amp;' , '&' ) , 'http://www.locatetv.com' + IIi1i , '' , Ii )
  if 7 - 7: I1Ii111 * OoO0O00 - ooOoO0o + OOooOOo * I1IiiI % OoO0O00
  if 15 - 15: OoOoOO00 % I1IiiI * I11i
def O0OoooO0 ( ) :
 IIi1i11111 = ooOO00O00oo ( 'http://tvguideuk.telegraph.co.uk/' )
 I1ii11iI = re . compile ( '<li class="tabs"><span><a href="(.+?)">(.+?)</a></span></li>' ) . findall ( IIi1i11111 )
 for IIi1i , I1I1iIiII1 in I1ii11iI :
  if 'amp;' in IIi1i :
   IIi1i = IIi1i . replace ( 'amp;' , '' )
  O0OOO ( I1I1iIiII1 , 'http://tvguideuk.telegraph.co.uk/' + IIi1i , 65 , '' )
  if 85 - 85: I11i
def iI1i11II1i ( ) :
 OOOoO0O0o ( 'Site 1 Films' , '' , 77 , OooO0 + 'scraper.png' , OooO0 + 'background.png' , '' )
 OOOoO0O0o ( 'Search Alluc*in testing*' , '' , 90 , OooO0 + 'scraper.png' , OooO0 + 'background.png' , '' )
 OOOoO0O0o ( 'Scraped M3U8 Lists' , '' , 109 , OooO0 + 'scraper.png' , OooO0 + 'background.png' , '' )
 OOOoO0O0o ( 'IMDB Search' , '' , 106 , OooO0 + 'scraper.png' , OooO0 + 'background.png' , '' )
 if 96 - 96: I1Ii111
 if 97 - 97: ooOoO0o
 if 48 - 48: i1IIi - I1Ii111
def OOOoOO ( url ) :
 IIi1i11111 = ooOO00O00oo ( url )
 I1ii11iI = re . compile ( '<div class="channel_name">(.+?)<.+?channel_id=(.+?).+?>(.+?)</a>' , re . DOTALL ) . findall ( IIi1i11111 )
 for I1I1iIiII1 , id , OOOoOO in I1ii11iI :
  O0OOO ( I1I1iIiII1 + ' - ' + OOOoOO , '' , 41 , '' )
  if 10 - 10: iII111i + Oo0Ooo * I1ii11iIi11i + iIii1I11I1II1 / I1Ii111 / I1ii11iIi11i
def iI1II ( ) :
 IIi1i11111 = ooOO00O00oo ( '' )
 I1ii11iI = re . compile ( '<td><a href="(.+?)"><img src="(.+?)" width="100" height="100" border="0"><br>(.+?)</a></td>' ) . findall ( IIi1i11111 )
 for IIi1i , Ii , I1I1iIiII1 in I1ii11iI :
  O0OOO ( I1I1iIiII1 , '' , 420 , OooO0 + 'icon.png' )
  if 69 - 69: ooOoO0o % oO0o
def ii1I1IIii11 ( url ) :
 IIi1i11111 = ooOO00O00oo ( url )
 I1ii11iI = re . compile ( '' , re . DOTALL ) . findall ( IIi1i11111 )
 for url , I1I1iIiII1 , Ii in I1ii11iI :
  O0OOO ( I1I1iIiII1 , url , 421 , 'http://www.movietubenow.biz%s' % Ii )
  if 67 - 67: iII111i + I11i / o0oOOo0O0Ooo . oO0o + OOooOOo
def ooOoOo0 ( url ) :
 IIi1i11111 = ooOO00O00oo ( url )
 I1ii11iI = re . compile ( '<iframe width="680" height="430" scrolling="no" frameborder="0" src="(.+?)"' , re . DOTALL ) . findall ( IIi1i11111 )
 for url in I1ii11iI :
  O0OOO ( I1I1iIiII1 , url , 422 , OooO0 + 'icon.png' )
  if 2 - 2: iII111i % iIii1I11I1II1 * iIii1I11I1II1 . o0oOOo0O0Ooo / iII111i
def iII1i1 ( url ) :
 IIi1i11111 = ooOO00O00oo ( url )
 I1ii11iI = re . compile ( '<source src="(.+?)" type="video/mp4"/>' ) . findall ( IIi1i11111 )
 for url in I1ii11iI :
  O0OOO ( I1I1iIiII1 , url , 401 , '' )
  if 85 - 85: Ii1I * Oo0Ooo . O0 - i11iIiiIii
  if 18 - 18: Ii1I + IiII - O0
def o00O ( ) :
 IIi1i11111 = ooOO00O00oo ( 'http://www.animetoon.org/cartoon' )
 I1ii11iI = re . compile ( '<td><a href="(.+?)">(.+)</a></td>' ) . findall ( IIi1i11111 )
 for IIi1i , I1I1iIiII1 in I1ii11iI :
  O0OOO ( I1I1iIiII1 , IIi1i , 407 , OooO0 + 'icon.png' )
if 5 - 5: I1Ii111
if 90 - 90: I1Ii111 . ooOoO0o / Ii1I - I11i
if 40 - 40: OoooooooOO
if 25 - 25: IiII + Ii1I / ooOoO0o . o0oOOo0O0Ooo % O0 * OoO0O00
if 84 - 84: ooOoO0o % Ii1I + i11iIiiIii
if 28 - 28: Oo0Ooo + OoO0O00 * OOooOOo % oO0o . I11i % O0
if 16 - 16: I11i - iIii1I11I1II1 / I1IiiI . II111iiii + iIii1I11I1II1
if 19 - 19: OoO0O00 - Oo0Ooo . O0
if 60 - 60: II111iiii + Oo0Ooo
if 9 - 9: ooOoO0o * OoooooooOO - iIii1I11I1II1 + OoOoOO00 / OoO0O00 . OoO0O00
if 49 - 49: II111iiii
if 25 - 25: OoooooooOO - I1IiiI . I1IiiI * oO0o
if 81 - 81: iII111i + IiII
if 98 - 98: I1IiiI
if 95 - 95: ooOoO0o / ooOoO0o
if 30 - 30: I1ii11iIi11i + Oo0Ooo / Oo0Ooo % I1ii11iIi11i . I1ii11iIi11i
if 55 - 55: ooOoO0o - I11i + II111iiii + iII111i % Ii1I
def iiI11i1II ( url ) :
 IIi1i11111 = ooOO00O00oo ( url )
 I1ii11iI = re . compile ( '&nbsp;<a href="(.+?)">(.+?)</a>' ) . findall ( IIi1i11111 )
 for url , I1I1iIiII1 in I1ii11iI :
  O0OOO ( I1I1iIiII1 , url , 408 , OooO0 + 'icon.png' )
  if 51 - 51: o0oOOo0O0Ooo % Oo0Ooo % o0oOOo0O0Ooo * O0 - OOooOOo % Oo0Ooo
def o0O00OooOOOOO ( url ) :
 IIi1i11111 = ooOO00O00oo ( url )
 I1ii11iI = re . compile ( '"playlist">(.+?)</span></div><div><iframe src="(.+?)"' ) . findall ( IIi1i11111 )
 for I1I1iIiII1 , url in I1ii11iI :
  O0OOO ( I1I1iIiII1 , url , 409 , OooO0 + 'icon.png' )
  if 40 - 40: o0oOOo0O0Ooo - i11iIiiIii + OoO0O00 . iIii1I11I1II1 * I1Ii111
def iiIII1i ( url ) :
 IIi1i11111 = ooOO00O00oo ( url )
 I1ii11iI = re . compile ( "url: '(.+?)'," ) . findall ( IIi1i11111 )
 for url in I1ii11iI :
  iiIii ( 'STREAM' , url , 401 , OooO0 + 'icon.png' )
  if 31 - 31: iII111i . OOooOOo - ooOoO0o . OoooooooOO / OoooooooOO
def OOoO ( ) :
 IIi1i11111 = ooOO00O00oo ( 'http://tvshows.cnfstudio.com/' )
 I1ii11iI = re . compile ( '<a href="http://tvshows.cnfstudio.com/genre/(.+?)">(.+?)</a>' ) . findall ( IIi1i11111 )
 for IIi1i , I1I1iIiII1 in I1ii11iI :
  O0OOO ( I1I1iIiII1 , 'http://tvshows.cnfstudio.com/genre/' + IIi1i , 82 , OooO0 + 'icon.png' )
  print '>>>>>>>>>>' + IIi1i
  if 44 - 44: oO0o
def I1i11i ( url ) :
 IIi1i11111 = ooOO00O00oo ( url )
 I1ii11iI = re . compile ( '<div class="movie">.+?<img src="(.+?)" alt=".+?" />.+?<a href="(.+?)"><span class="player"></span></a>.+?<h2>(.+?)</h2>' , re . DOTALL ) . findall ( IIi1i11111 )
 IiIi = re . compile ( "<link rel='prev' href='(.+?)'/>" ) . findall ( IIi1i11111 )
 next = re . compile ( "<link rel='next' href='(.+?)'/>" ) . findall ( IIi1i11111 )
 for Ii , url , I1I1iIiII1 in I1ii11iI :
  O0OOO ( ( I1I1iIiII1 ) . replace ( '&#038;' , '' ) . replace ( '&#8216;' , '' ) . replace ( '&#8217;' , '' ) . replace ( '&#8211;' , '' ) , url , 83 , Ii )
 IiIi = IiIi
 for url in IiIi :
  O0OOO ( 'Prev' , url , 82 , '' )
 next = next
 for url in next :
  O0OOO ( 'Next' , url , 82 , '' )
  if 87 - 87: I1ii11iIi11i - I1ii11iIi11i - iII111i + oO0o
def OOooo ( url ) :
 IIi1i11111 = ooOO00O00oo ( url )
 I1ii11iI = re . compile ( '<li>.+?<a href="(.+?)" target="_blank">.+?<span class="datex">(.+?)</span>.+?</b>(.+?)</span>.+?</li>' , re . DOTALL ) . findall ( IIi1i11111 )
 for url , iIIiIiI1I1 , I1I1iIiII1 in I1ii11iI :
  iiIii ( ( 'Season' ) + iIIiIiI1I1 + ( '  ' ) + I1I1iIiII1 , url , 100 , OooO0 + 'icon.png' )
  if 56 - 56: I1IiiI . O0 + Oo0Ooo
def i1II1I1Iii1 ( ) :
 IIi1i11111 = ooOO00O00oo ( 'http://cnfstudio.com/' )
 I1ii11iI = re . compile ( '<a href="http://cnfstudio.com/genre/(.+?)">(.+?)</a>' ) . findall ( IIi1i11111 )
 for IIi1i , I1I1iIiII1 in I1ii11iI :
  O0OOO ( I1I1iIiII1 , 'http://cnfstudio.com/genre/' + IIi1i , 78 , OooO0 + 'icon.png' )
  if 30 - 30: OoooooooOO - OoOoOO00
Ooo00O0o = xbmcgui . Dialog ( )
if 72 - 72: iIii1I11I1II1 * Ii1I % ooOoO0o / OoO0O00
def I11i1II ( url ) :
 if 72 - 72: iIii1I11I1II1 . i1IIi / Oo0Ooo . II111iiii
 ooo000o000 = 1
 O0o = 0
 O0OOoOOO0oO = ooOO00O00oo ( url )
 I1ii11 = re . compile ( '<iframe width=".*?" height=".*?" frameborder=".*?" src="(.*?)" scrolling=".*?" marginwidth=".*?" marginheight=".*?" vspace=".*?" hspace=".*?" allowfullscreen=".*?" webkitallowfullscreen=".*?" mozallowfullscreen=".*?"></iframe>' , re . DOTALL ) . findall ( O0OOoOOO0oO )
 for url in I1ii11 :
  if 74 - 74: Oo0Ooo - o0oOOo0O0Ooo . i1IIi
  try :
   i1III = Google . resolve ( url )
  except :
   pass
   if 49 - 49: i11iIiiIii % Ii1I . OoOoOO00
  Ii1i1iI = re . findall ( r"{'url': u'(.*?)', 'quality': 'HD'}, {'url': u'(.*?)', 'quality': 'SD'}" , str ( i1III ) )
  for IIiI1 , i1iI1 in Ii1i1iI :
   if 1 - 1: i1IIi . i11iIiiIii % OOooOOo
   Ooo . append ( IIiI1 )
   O0o0Oo . append ( i1iI1 )
   if 82 - 82: iIii1I11I1II1 + Oo0Ooo . iIii1I11I1II1 % IiII / Ii1I . Ii1I
   if 14 - 14: o0oOOo0O0Ooo . OOooOOo . I11i + OoooooooOO - OOooOOo + IiII
  iiIii ( 'HD LINKS' , '' , '' , '' )
  for o0OOOO00O0Oo in Ooo :
   iiIii ( 'Part ' + ooo000o000 , Ooo [ O0o ] , 100 , '' )
   ooo000o000 = ooo000o000 + 1
   O0o = O0o + 1
   if 9 - 9: Ii1I
  ooo000o000 = 0
  O0o = 0
  iiIii ( 'SD LINKS' , '' , '' , '' )
  for o0OOOO00O0Oo in O0o0Oo :
   iiIii ( 'Part ' + ooo000o000 , O0o0Oo [ O0o ] , 100 , '' )
   ooo000o000 = ooo000o000 + 1
   O0o = O0o + 1
   if 59 - 59: I1IiiI * II111iiii . O0
  ooo000o000 = 0
  O0o = 0
  if 56 - 56: Ii1I - iII111i % I1IiiI - o0oOOo0O0Ooo
  if 51 - 51: O0 / ooOoO0o * iIii1I11I1II1 + I1ii11iIi11i + o0oOOo0O0Ooo
def Oo0OO0000oooo ( url ) :
 IIi1i11111 = ooOO00O00oo ( url )
 I1ii11iI = re . compile ( '<div class="movie">.+?<img src="(.+?)" alt=".+?" />.+?<a href="(.+?)"><span class="player"></span></a>.+?<h2>(.+?)</h2>' , re . DOTALL ) . findall ( IIi1i11111 )
 IiIi = re . compile ( "<link rel='next' href='(.+?)'/>" ) . findall ( IIi1i11111 )
 for Ii , url , I1I1iIiII1 in I1ii11iI :
  iiIii ( ( I1I1iIiII1 ) . replace ( '&#038;' , '' ) . replace ( '&#8216;' , '' ) . replace ( '&#8217;' , '' ) . replace ( '&#8211;' , '' ) , url , 169 , Ii )
 IiIi = IiIi
 for url in IiIi :
  O0OOO ( 'Next Page' , url , 79 , '' )
  if 7 - 7: oO0o - OoO0O00 - O0 % oO0o - II111iiii
  if 31 - 31: iII111i / Oo0Ooo - iII111i - OOooOOo
  if 7 - 7: iII111i % O0 . OoOoOO00 + I1IiiI - I11i
  if 75 - 75: I11i
def oO00oo0o00o0o ( url ) :
 if 7 - 7: O0 - Oo0Ooo + I1ii11iIi11i + II111iiii + iIii1I11I1II1
 IIi1i11111 = ooOO00O00oo ( url )
 I1ii11iI = re . compile ( '<div id="play-1" class="player-content"><iframe class="playerframe" src="(.+?)" scrolling="no".+?</div>' , re . DOTALL ) . findall ( IIi1i11111 )
 for url in I1ii11iI :
  o0OOOO00O0Oo = url + '&fv=&sou='
  o0OOOO00O0Oo = o0OOOO00O0Oo . replace ( 'player' , 'watch' )
  OOo0 = ii11I1 ( o0OOOO00O0Oo )
  oO0oo = ii11I1 ( url )
  if 38 - 38: OoooooooOO * ooOoO0o % O0 * OoOoOO00
  if 29 - 29: I1ii11iIi11i / i1IIi . I1IiiI - OoOoOO00 - OoOoOO00 - Ii1I
def ii11I1 ( url ) :
 if 20 - 20: i1IIi % OoO0O00 . I1IiiI / IiII * i11iIiiIii * OOooOOo
 IIi1i11111 = ooOO00O00oo ( url )
 I1ii11iI = re . compile ( '<video id=".+?<source src="(.+?)" type="video/mp4">' , re . DOTALL ) . findall ( IIi1i11111 )
 for url in I1ii11iI :
  OOo ( url )
  if 50 - 50: ooOoO0o
  if 72 - 72: I1Ii111
def OO0ooo0oOO ( type , name , url , mode , iconimage = '' , fanart = '' , video = '' , description = '' ) :
 if type != 'folder2' and type != 'addon' :
  if len ( iconimage ) > 0 :
   iconimage = OooO0 + iconimage
  else :
   iconimage = 'DefaultFolder.png'
 if type == 'addon' :
  if len ( iconimage ) > 0 :
   iconimage = iconimage
  else :
   iconimage = 'http://totalxbmc.tv/addons/cache/images/4c79319887e240789ca125f144d989_addon-dummy.png'
 if fanart == '' :
  fanart = II11iiii1Ii
 I1Ii = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&fanart=" + urllib . quote_plus ( fanart ) + "&video=" + urllib . quote_plus ( video ) + "&description=" + urllib . quote_plus ( description )
 O0oo00o0O = True
 i1I1I = xbmcgui . ListItem ( name , iconImage = "DefaultFolder.png" , thumbnailImage = iconimage )
 i1I1I . setInfo ( type = "Video" , infoLabels = { "Title" : name , "Plot" : description } )
 i1I1I . setProperty ( "Fanart_Image" , fanart )
 i1I1I . setProperty ( "Build.Video" , video )
 if ( type == 'folder' ) or ( type == 'folder2' ) or ( type == 'tutorial_folder' ) or ( type == 'news_folder' ) :
  O0oo00o0O = oo000 ( handle = int ( sys . argv [ 1 ] ) , url = I1Ii , listitem = i1I1I , isFolder = True )
 else :
  O0oo00o0O = oo000 ( handle = int ( sys . argv [ 1 ] ) , url = I1Ii , listitem = i1I1I , isFolder = False )
 return O0oo00o0O
 if 32 - 32: i1IIi . Ii1I
def oo000 ( handle , url , listitem , isFolder ) :
 if 59 - 59: OoooooooOO
 xbmcplugin . addDirectoryItem ( handle , url , listitem , isFolder )
 if 47 - 47: ooOoO0o - I1IiiI / II111iiii
 if 12 - 12: OOooOOo
def O0iII1 ( name , url , img ) :
 II1i111Ii1i = ooOO00O00oo ( url )
 II = re . compile ( '<iframe class="playerframe" src="(.+?)" scrolling=".+?" marginwidth=".+?" marginheight=".+?" vspace=".+?" hspace=".+?" allowfullscreen=".+?" webkitallowfullscreen=".+?" mozallowfullscreen=".+?" width=".+?" height=".+?" frameborder=".+?"></iframe>' , re . DOTALL ) . findall ( II1i111Ii1i )
 II1i = len ( II )
 if 2 - 2: iIii1I11I1II1 * Oo0Ooo % oO0o - II111iiii - iII111i
 if 3 - 3: I1Ii111
 if II1i == 1 :
  for i1iiIiI1Ii1i in II :
   i1iiIiI1Ii1i = i1iiIiI1Ii1i . replace ( 'player' , 'watch' )
   i1iIi = i1iiIiI1Ii1i + '&fv=&sou='
   iiiii1II = ooOO00O00oo ( i1iIi )
   O0OOO0OOooo00 = re . compile ( '<source src="(.+?)" type=".+?">' , re . DOTALL ) . findall ( iiiii1II )
   for I111iIi1 in O0OOO0OOooo00 :
    oo00O00oO000o = False
    OOo ( I111iIi1 )
    if 71 - 71: I1ii11iIi11i - ooOoO0o / OoOoOO00 * OoOoOO00 / i1IIi . i1IIi
 elif II1i > 1 :
  if 53 - 53: I1Ii111
  for i1iiIiI1Ii1i in II :
   O0OOoOOO0oO = ooOO00O00oo ( i1iiIiI1Ii1i )
   I1ii11 = re . compile ( '<iframe width=".*?" height=".*?" frameborder=".*?" src="(.*?)" scrolling=".*?" marginwidth=".*?" marginheight=".*?" vspace=".*?" hspace=".*?" allowfullscreen=".*?" webkitallowfullscreen=".*?" mozallowfullscreen=".*?"></iframe>' , re . DOTALL ) . findall ( O0OOoOOO0oO )
   i11iiI1111 = I1ii11
   i11iiI1111 = ( str ( i11iiI1111 ) ) . replace ( '[\'' , '' ) . replace ( '\']' , '' ) ;
   print 'Stripped url : ' + i11iiI1111
   iiIii ( 'DOUBLE LINK' , i11iiI1111 , 424 , '' )
   if 97 - 97: Oo0Ooo * I1IiiI . iIii1I11I1II1
   for url in I1ii11 :
    O0OOO ( 'DOUBLE LINK' , url , 424 , '' )
    try :
     i1III = Google . resolve ( url )
    except :
     pass
    try :
     Ii1i1iI = re . findall ( r"{'url': u'(.*?)', 'quality': 'HD'}, {'url': u'(.*?)', 'quality': 'SD'}" , str ( i1III ) )
     for IIiI1 , i1iI1 in Ii1i1iI :
      if 16 - 16: ooOoO0o % OoooooooOO - OOooOOo * Ii1I * I1ii11iIi11i / OoooooooOO
      Ooo . append ( IIiI1 )
      O0o0Oo . append ( i1iI1 )
    except :
     pass
 else :
  pass
  if 31 - 31: I11i . I1Ii111 * ooOoO0o + i11iIiiIii * oO0o
  if 93 - 93: I1ii11iIi11i / iIii1I11I1II1 * i1IIi % OoooooooOO * O0 * I11i
def ooOO00O00oo ( url ) :
 if 64 - 64: II111iiii + O0 / iIii1I11I1II1 / Oo0Ooo . ooOoO0o % IiII
 if 50 - 50: iIii1I11I1II1 - IiII + OOooOOo
 if 69 - 69: O0
 if 85 - 85: ooOoO0o / O0
 if 18 - 18: o0oOOo0O0Ooo % O0 * I1ii11iIi11i
 if 62 - 62: I1Ii111 . IiII . OoooooooOO
 if 11 - 11: OOooOOo / I11i
 if 73 - 73: i1IIi / i11iIiiIii
 if 58 - 58: Oo0Ooo . II111iiii + oO0o - i11iIiiIii / II111iiii / O0
 if 85 - 85: OoOoOO00 + OOooOOo
 if 10 - 10: IiII / OoO0O00 + OoOoOO00 / i1IIi
 i1iII1II11I = urllib2 . Request ( url )
 IiIIIiI1I1 = 'Mozilla/5.0 (Windows NT 6.1; WOW64; Trident/7.0; AS; rv:11.0) like Gecko'
 OoO000 = 'Mozilla/5.0 (Windows NT 6.3; rv:36.0) Gecko/20100101 Firefox/36.0'
 IIiiIiI1 = 'Mozilla/5.0 (iPhone; CPU iPhone OS 6_0 like Mac OS X) AppleWebKit/536.26 (KHTML, like Gecko) Version/6.0 Mobile/10A5376e Safari/8536.25'
 iiIiIIi = 'Mozilla/5.0 (Linux; Android 4.4.2; Nexus 4 Build/KOT49H) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/34.0.1847.114 Mobile Safari/537.36'
 i1iII1II11I . add_header ( 'User-Agent' , 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3' )
 O0Oo00O = urllib2 . urlopen ( i1iII1II11I )
 o0OOOO00O0Oo = O0Oo00O . read ( )
 O0Oo00O . close ( )
 return o0OOOO00O0Oo
 if 91 - 91: oO0o % Ii1I . ooOoO0o / iII111i * iIii1I11I1II1
def I1I1i11 ( url ) :
 xbmcplugin . addSortMethod ( handle = int ( sys . argv [ 1 ] ) , sortMethod = xbmcplugin . SORT_METHOD_TITLE )
 OOooOoooOoOo = ( '%s%s' % ( OOoO00o , url ) )
 o0OOOO00O0Oo = ooOO00O00oo ( url )
 I1ii11iI = re . compile ( '<a.href="(.+?)".target="_blank"><img.src="(.+?)".style="max-width:200px;"./></a><br><b>(.+?)</b>' ) . findall ( o0OOOO00O0Oo )
 for url , ii , I1I1iIiII1 in I1ii11iI :
  iiiI11OOoO000 ( '%s' % ( I1I1iIiII1 ) . replace ( 'Origin Entertainment' , 'Origin Entertainment' ) . replace ( '.' , ' ' ) . replace ( 'mp4' , '' ) . replace ( 'mkv' , '' ) . replace ( '_' , ' ' ) , '%s' % ( url ) , 401 , '%s' % ( ii ) )
  if 57 - 57: II111iiii
 xbmcplugin . addSortMethod ( Oo , xbmcplugin . SORT_METHOD_TITLE ) ;
 if 54 - 54: Oo0Ooo + oO0o + i11iIiiIii
 if 28 - 28: oO0o
def ooo000o0ooO0 ( url ) :
 xbmcplugin . addSortMethod ( handle = int ( sys . argv [ 1 ] ) , sortMethod = xbmcplugin . SORT_METHOD_TITLE )
 OOooOoooOoOo = ( '%s%s' % ( OOoO00o , url ) )
 o0OOOO00O0Oo = ooOO00O00oo ( url )
 I1ii11iI = re . compile ( '<a.href="(.+?)".target="_blank"><img.src="(.+?)".style="max-width:200px;"./></a><br><b>(.+?)</b>' ) . findall ( o0OOOO00O0Oo )
 for url , ii , I1I1iIiII1 in I1ii11iI :
  I1I ( I1I1iIiII1 , url , 402 , ii )
  if 83 - 83: oO0o + OoooooooOO
 xbmcplugin . addSortMethod ( Oo , xbmcplugin . SORT_METHOD_TITLE ) ;
 if 22 - 22: Ii1I % iII111i * OoooooooOO - o0oOOo0O0Ooo / iIii1I11I1II1
 if 86 - 86: OoooooooOO . iII111i % OoOoOO00 / I11i * iII111i / o0oOOo0O0Ooo
def oO ( url ) :
 if 60 - 60: I1ii11iIi11i * I1IiiI
 xbmcplugin . addSortMethod ( handle = int ( sys . argv [ 1 ] ) , sortMethod = xbmcplugin . SORT_METHOD_TITLE )
 I1iIiI11I1 = ( '%s%s' % ( OOoO00o , url ) )
 o0OOOO00O0Oo = ooOO00O00oo ( url )
 I1ii11iI = re . compile ( "addDir('','','','','','')" ) . findall ( o0OOOO00O0Oo )
 if 27 - 27: Ii1I . i11iIiiIii % I1Ii111
 if 65 - 65: II111iiii . I1IiiI % oO0o * OoO0O00
 if 38 - 38: OoOoOO00 / iII111i % Oo0Ooo
def OOo ( url ) :
 I1IIIiii1 = xbmc . Player ( O00oo ( ) )
 import urlresolver
 try : I1IIIiii1 . play ( url )
 except : pass
 from urlresolver import common
 O0OO00O0oOO = xbmcgui . DialogProgress ( )
 O0OO00O0oOO . create ( 'LOADING' , 'Opening %s Now' % ( I1I1iIiII1 ) )
 I1IIIiii1 = xbmc . Player ( O00oo ( ) )
 url = urlresolver . HostedMediaFile ( url ) . resolve ( )
 if O0OO00O0oOO . iscanceled ( ) :
  print "[COLORred]STREAM CANCELLED[/COLOR]"
  Ooo00O0o = xbmcgui . Dialog ( )
  if Ooo00O0o . yesno ( "[B]CANCELLED[/B]" , '[B]Was There A Problem[/B]' , '' , "" , 'Yes' , 'No' ) :
   Ooo00O0o . ok ( "Message Send" , "Your Message Has Been Sent" )
  else :
   return
 else :
  try : I1IIIiii1 . play ( url )
  except : pass
  try : O0O . resolve_url ( url )
  except : pass
  O0OO00O0oOO . close ( )
  if 4 - 4: OoooooooOO - i1IIi % Ii1I - OOooOOo * o0oOOo0O0Ooo
def Ooooo00o0OoO ( url ) :
 I1IIIiii1 = xbmc . Player ( O00oo ( ) )
 import urlresolver
 try : I1IIIiii1 . play ( url )
 except : pass
 if 75 - 75: I1IiiI % II111iiii
 if 30 - 30: IiII + I1Ii111 - IiII . IiII - II111iiii + O0
def oOO0 ( ) :
 i1IIiIii1i = ''
 ooOOO0OooOo = xbmc . Keyboard ( i1IIiIii1i , 'Search' )
 ooOOO0OooOo . doModal ( )
 if ( ooOOO0OooOo . isConfirmed ( ) == False ) :
  return
 i1IIiIii1i = ooOOO0OooOo . getText ( )
 if len ( i1IIiIii1i ) == 0 :
  return
 else :
  return i1IIiIii1i
  if 33 - 33: OOooOOo / i1IIi - I1IiiI % Oo0Ooo . I1ii11iIi11i
def Ii1II ( name , url , iconimage = None ) :
 print '--- Playing "{0}". {1}' . format ( name , url )
 O0Oo00 = xbmcgui . ListItem ( path = url , thumbnailImage = iconimage )
 O0Oo00 . setInfo ( type = "Video" , infoLabels = { "Title" : name } )
 xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , O0Oo00 )
 if 41 - 41: iIii1I11I1II1 % I11i
def O00oo ( ) :
 try :
  oOo0oO = getSet ( "core-player" )
  if ( oOo0oO == 'DVDPLAYER' ) : IIi1IIIIi = xbmc . PLAYER_CORE_DVDPLAYER
  elif ( oOo0oO == 'MPLAYER' ) : IIi1IIIIi = xbmc . PLAYER_CORE_MPLAYER
  elif ( oOo0oO == 'PAPLAYER' ) : IIi1IIIIi = xbmc . PLAYER_CORE_PAPLAYER
  else : IIi1IIIIi = xbmc . PLAYER_CORE_AUTO
 except : IIi1IIIIi = xbmc . PLAYER_CORE_AUTO
 return IIi1IIIIi
 return True
 if 70 - 70: OOooOOo / II111iiii - iIii1I11I1II1 - iII111i
def O0oo0OO0oOOOo ( name , url , mode , iconimage ) :
 I1Ii = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name )
 O0oo00o0O = True
 i1I1I = xbmcgui . ListItem ( name , iconImage = "DefaultFolder.png" , thumbnailImage = iconimage )
 i1I1I . setInfo ( type = "Video" , infoLabels = { "Title" : name } )
 O0oo00o0O = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = I1Ii , listitem = i1I1I , isFolder = True )
 return O0oo00o0O
def I1I ( name , url , mode , iconimage ) :
 I1Ii = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name )
 O0oo00o0O = True
 i1I1I = xbmcgui . ListItem ( name , iconImage = "DefaultFolder.png" , thumbnailImage = iconimage )
 i1I1I . setInfo ( type = "Video" , infoLabels = { "Title" : name } )
 O0oo00o0O = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = I1Ii , listitem = i1I1I , isFolder = True )
 return O0oo00o0O
def iiiI11OOoO000 ( name , url , mode , iconimage ) :
 I1Ii = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name )
 O0oo00o0O = True
 i1I1I = xbmcgui . ListItem ( name , iconImage = "DefaultFolder.png" , thumbnailImage = iconimage )
 i1I1I . setInfo ( type = "Video" , infoLabels = { "Title" : name } )
 O0oo00o0O = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = I1Ii , listitem = i1I1I , isFolder = False )
 return O0oo00o0O
 if 11 - 11: iIii1I11I1II1 . OoooooooOO . II111iiii / i1IIi - I11i
 if 30 - 30: OoOoOO00
def Ii111 ( name , url ) :
 i1iII1II11I = ooOO00O00oo ( url )
 oO0 = BeautifulSoup ( i1iII1II11I )
 i1iI = open ( I11II1i , 'w' )
 iioo0o0OoOOO = name
 if 88 - 88: iII111i
 iiI11I1i1i1iI = oO0 . find_all ( 'div' , { 'class' : 'body' } )
 for OoOOo000o0 in iiI11I1i1i1iI :
  iiI1II11II1i = OoOOo000o0 . find_all ( 'p' )
  for o0O0O0 in iiI1II11II1i :
   o0O0O0 = o0O0O0 . text
   o0O0O0 = o0O0O0 . encode ( 'utf-8' )
   if 6 - 6: iII111i . IiII * OoOoOO00 . i1IIi
   oOOo = open ( I11II1i , 'a' )
   oOOo . write ( o0O0O0 )
   oOOo . write ( '\n' )
   if 46 - 46: IiII + iIii1I11I1II1 + OOooOOo + OoO0O00 . I1ii11iIi11i
  iIiIi11Ii = open ( I11II1i , 'r' )
  iIII1i1i = iIiIi11Ii . read ( )
  IiI1iii11iIi1 ( iioo0o0OoOOO , iIII1i1i )
  oOOo . close ( )
  if 40 - 40: I11i % OoO0O00 . I1Ii111
def IiI1iii11iIi1 ( heading , announce ) :
 class OOO0oOOo00O ( ) :
  WINDOW = 10147
  CONTROL_LABEL = 1
  CONTROL_TEXTBOX = 5
  isFolder = True
  def __init__ ( self , * args , ** kwargs ) :
   xbmc . executebuiltin ( "ActivateWindow(%d)" % ( self . WINDOW , ) )
   self . win = xbmcgui . Window ( self . WINDOW )
   xbmc . sleep ( 500 )
   self . setControls ( )
  def setControls ( self ) :
   self . win . getControl ( self . CONTROL_LABEL ) . setLabel ( heading )
   try : OO0oIII111i11IiI = open ( announce ) ; O0000 = OO0oIII111i11IiI . read ( )
   except : O0000 = announce
   self . win . getControl ( self . CONTROL_TEXTBOX ) . setText ( str ( O0000 ) )
   return
 OOO0oOOo00O ( )
 if 64 - 64: II111iiii - I1IiiI
 if 68 - 68: ooOoO0o - OOooOOo - iIii1I11I1II1 / OoOoOO00 + OOooOOo - OoO0O00
def O00Oo ( ) :
 i1iII1II11I = urllib2 . Request ( o0 )
 i1iII1II11I . add_header ( 'User-Agent' , USER_AGENT )
 O0Oo00O = urllib2 . urlopen ( i1iII1II11I )
 I1ii = O0Oo00O . read ( )
 O0Oo00O . close ( )
 Ii1i1i1111 = re . search ( r'npoplayer.token = "(.*?)"' , I1ii ) . group ( 1 )
 if 57 - 57: Ii1I % II111iiii
 if 67 - 67: ooOoO0o + I1IiiI * i11iIiiIii - oO0o / IiII % iII111i
 O0OO00oo0 = - 1
 iIIIiIii = - 1
 for ooo in range ( 5 , len ( Ii1i1i1111 ) - 5 , 1 ) :
  if 94 - 94: OoOoOO00 - Oo0Ooo - I1IiiI % i1IIi
  if Ii1i1i1111 [ ooo ] . isdigit ( ) :
   if O0OO00oo0 < 0 :
    O0OO00oo0 = ooo
    if 19 - 19: o0oOOo0O0Ooo
   elif iIIIiIii < 0 :
    iIIIiIii = ooo
    if 42 - 42: i1IIi . I1IiiI / i1IIi + Ii1I
    break
    if 54 - 54: ooOoO0o % OOooOOo . I1Ii111 + oO0o - OOooOOo * I1IiiI
 OOo00O = list ( Ii1i1i1111 )
 if O0OO00oo0 < 0 or iIIIiIii < 0 :
  O0OO00oo0 = 12
  iIIIiIii = 13
 OOo00O [ O0OO00oo0 ] = Ii1i1i1111 [ iIIIiIii ]
 OOo00O [ iIIIiIii ] = Ii1i1i1111 [ O0OO00oo0 ]
 OOo00O = '' . join ( OOo00O )
 if 81 - 81: IiII . o0oOOo0O0Ooo / I1Ii111
 return OOo00O
 if 17 - 17: i11iIiiIii - OOooOOo . IiII % iIii1I11I1II1 + I11i - ooOoO0o
 if 78 - 78: I11i * OoOoOO00 . O0 / O0
def OooOOOo0 ( ) :
 O0O0o0o0o = [ ]
 IIIIIiI = sys . argv [ 2 ]
 if len ( IIIIIiI ) >= 2 :
  Oo0000O0OOooO = sys . argv [ 2 ]
  O00OO = Oo0000O0OOooO . replace ( '?' , '' )
  if ( Oo0000O0OOooO [ len ( Oo0000O0OOooO ) - 1 ] == '/' ) :
   Oo0000O0OOooO = Oo0000O0OOooO [ 0 : len ( Oo0000O0OOooO ) - 2 ]
  Oo0 = O00OO . split ( '&' )
  O0O0o0o0o = { }
  for ooo in range ( len ( Oo0 ) ) :
   i1111IIiii1 = { }
   i1111IIiii1 = Oo0 [ ooo ] . split ( '=' )
   if ( len ( i1111IIiii1 ) ) == 2 :
    O0O0o0o0o [ i1111IIiii1 [ 0 ] ] = i1111IIiii1 [ 1 ]
    if 49 - 49: OOooOOo . iIii1I11I1II1
 return O0O0o0o0o
 if 62 - 62: OoOoOO00 / I1IiiI - I1ii11iIi11i - I1IiiI + i11iIiiIii + i1IIi
Oo0000O0OOooO = OooOOOo0 ( )
IIi1i = None
I1I1iIiII1 = None
ii = None
I11i1ii1 = None
I1i11II = None
if 31 - 31: oO0o / IiII * o0oOOo0O0Ooo . II111iiii
if 89 - 89: O0
try :
 IIi1i = urllib . unquote_plus ( Oo0000O0OOooO [ "url" ] )
except :
 pass
try :
 I1I1iIiII1 = urllib . unquote_plus ( Oo0000O0OOooO [ "name" ] )
except :
 pass
try :
 ii = urllib . unquote_plus ( Oo0000O0OOooO [ "iconimage" ] )
except :
 pass
try :
 I11i1ii1 = int ( Oo0000O0OOooO [ "mode" ] )
except :
 pass
try :
 iii1i = urllib . unquote_plus ( Oo0000O0OOooO [ "fanart" ] )
except :
 pass
try :
 I1i11II = urllib . unquote_plus ( Oo0000O0OOooO [ "description" ] )
except :
 pass
 if 2 - 2: I1ii11iIi11i . I1ii11iIi11i + I1ii11iIi11i * o0oOOo0O0Ooo
 if 100 - 100: Oo0Ooo % Ii1I / I11i
print str ( OooO0OO ) + ': ' + str ( iiiIi )
print "Mode: " + str ( I11i1ii1 )
print "URL: " + str ( IIi1i )
print "Name: " + str ( I1I1iIiII1 )
print "IconImage: " + str ( ii )
if 30 - 30: Oo0Ooo - OOooOOo - iII111i
def OOO ( url ) :
 try :
  url = url . replace ( '/embed-' , '/' )
  url = re . compile ( '//.+?/([\w]+)' ) . findall ( url ) [ 0 ]
  I1ii = 'http://allmyvideos.net/%s' % url
  if 18 - 18: ooOoO0o - OoOoOO00 % i1IIi + O0 + i11iIiiIii + i1IIi
  oOo0o0O = client . request ( I1ii , close = False )
  if 83 - 83: o0oOOo0O0Ooo / OOooOOo / OOooOOo + o0oOOo0O0Ooo * I1Ii111 + o0oOOo0O0Ooo
  IIIIiii = { }
  OO0oIII111i11IiI = client . parseDOM ( oOo0o0O , 'form' , attrs = { 'action' : '' } )
  oO0oIIIii1iiIi = client . parseDOM ( OO0oIII111i11IiI , 'input' , ret = 'name' , attrs = { 'type' : 'hidden' } )
  for ooo in oO0oIIIii1iiIi : IIIIiii . update ( { ooo : client . parseDOM ( OO0oIII111i11IiI , 'input' , ret = 'value' , attrs = { 'name' : ooo } ) [ 0 ] } )
  IIIIiii = urllib . urlencode ( IIIIiii )
  if 63 - 63: I1ii11iIi11i
  oOo0o0O = client . request ( I1ii , post = IIIIiii )
  if 6 - 6: ooOoO0o / I1ii11iIi11i
  url = re . compile ( '"file" *: *"(http.+?)"' ) . findall ( oOo0o0O ) [ - 1 ]
  url += '&direct=false&ua=false'
  return url
 except :
  return
  if 57 - 57: I11i
def oO0oO00oOo0OOO ( ) :
 O0OOO ( 'Top 20 Most Viewed' , 'http://cnfstudio.com' , 173 , OooO0 + 'Movies.png' )
 O0OOO ( 'Box Office' , 'http://cnfstudio.com/category/box-office/' , 89 , OooO0 + 'Movies.png' )
 O0OOO ( 'Genres' , 'http://cnfstudio.com/movies/' , 164 , OooO0 + 'Movies.png' )
 O0OOO ( 'By Year' , 'http://cnfstudio.com' , 174 , OooO0 + 'Movies.png' )
 O0OOO ( 'Search Movies' , '' , 171 , OooO0 + 'Movies.png' )
 xbmcplugin . endOfDirectory ( int ( sys . argv [ 1 ] ) )
 if 23 - 23: i1IIi . o0oOOo0O0Ooo * OoO0O00
 if 15 - 15: OoOoOO00
 if 62 - 62: Ii1I
 if 51 - 51: OoOoOO00
if I11i1ii1 == None : Iii111II ( )
elif I11i1ii1 == 9 : yt . PlayVideo ( IIi1i )
elif I11i1ii1 == 10 : Films . Films ( )
elif I11i1ii1 == 11 : TV . TV_Shows ( )
elif I11i1ii1 == 12 : Standup . Stand_Up ( )
elif I11i1ii1 == 13 : oOO0 ( )
elif I11i1ii1 == 14 : TV . Animated_TV ( )
elif I11i1ii1 == 15 : TV . Action_TV ( )
elif I11i1ii1 == 16 : TV . Childrens_TV ( )
elif I11i1ii1 == 17 : TV . Comedy_TV ( )
elif I11i1ii1 == 18 : TV . Drama_TV ( )
elif I11i1ii1 == 19 : TV . Entertainment_TV ( )
elif I11i1ii1 == 20 : TV . Fantasy_TV ( )
elif I11i1ii1 == 21 : TV . Music_TV ( )
elif I11i1ii1 == 22 : TV . Scifi_TV ( )
elif I11i1ii1 == 23 : SoapsCatchup . Soap_TV ( )
elif I11i1ii1 == 24 : Standup . Jeff_Dunham ( )
elif I11i1ii1 == 25 : TV . DrWho ( )
elif I11i1ii1 == 26 : TV . Arrow ( )
elif I11i1ii1 == 27 : TV . Flash ( )
elif I11i1ii1 == 28 : utube . Mock_the_week ( )
elif I11i1ii1 == 29 : utube . Inbetweeners ( )
elif I11i1ii1 == 30 : utube . WouldILieToYou ( )
elif I11i1ii1 == 31 : TV . Flash_Series2 ( )
elif I11i1ii1 == 32 : TV . The_Last_Man_On_Earth ( )
elif I11i1ii1 == 33 : TV . Fargo ( )
elif I11i1ii1 == 34 : TV . The_Knick ( )
elif I11i1ii1 == 35 : TV . Gotham ( )
elif I11i1ii1 == 36 : TV . Sons_Of_Anarchy ( )
elif I11i1ii1 == 37 : TV . Homelands ( )
elif I11i1ii1 == 38 : TV . Daredevil ( )
elif I11i1ii1 == 39 : TV . New_girl ( )
elif I11i1ii1 == 40 : TV . Dexter ( )
elif I11i1ii1 == 41 : TV . Live_TV ( )
elif I11i1ii1 == 42 : TV . Breaking_bad ( )
elif I11i1ii1 == 43 : TV . Grimm ( )
elif I11i1ii1 == 44 : TV . Brooklyn_Nine_Nine ( )
elif I11i1ii1 == 45 : TV . Game_of_thrones ( )
elif I11i1ii1 == 46 : TV . Bates_motel ( )
elif I11i1ii1 == 47 : TV . Black_list ( )
elif I11i1ii1 == 48 : TV . Legends ( )
elif I11i1ii1 == 49 : TV . Suits ( )
elif I11i1ii1 == 50 : TV . Once_upon_a_time ( )
elif I11i1ii1 == 51 : TV . How_I_Met_Your_Mother ( )
elif I11i1ii1 == 52 : o00oO0oo0OO ( )
elif I11i1ii1 == 53 : lists . Lists ( )
elif I11i1ii1 == 54 : OOo0oO00ooO00 ( )
elif I11i1ii1 == 55 : i11Iii ( )
elif I11i1ii1 == 56 : iI1II ( )
elif I11i1ii1 == 57 : III1iII1I1ii ( )
elif I11i1ii1 == 58 : IiII111i1i11 ( )
elif I11i1ii1 == 59 : oo0OO00OoooOo ( IIi1i )
elif I11i1ii1 == 60 : FootballFixturesChannel ( )
elif I11i1ii1 == 61 : Sponge_TV ( )
elif I11i1ii1 == 62 : ii1ii1ii ( IIi1i )
elif I11i1ii1 == 63 : OOO0o ( )
elif I11i1ii1 == 64 : Oo0O ( )
elif I11i1ii1 == 65 : OOOoOO ( IIi1i )
elif I11i1ii1 == 66 : TV . WorldNews ( )
elif I11i1ii1 == 67 : TV . WorldPlayUrl ( IIi1i )
elif I11i1ii1 == 68 : TV . WorldPlayVid ( IIi1i )
elif I11i1ii1 == 69 : i11II1I11I1 ( )
elif I11i1ii1 == 70 : Iii1iI ( )
elif I11i1ii1 == 71 : O0OoooO0 ( )
elif I11i1ii1 == 72 : NewsCat ( )
elif I11i1ii1 == 73 : NewsStory ( IIi1i )
elif I11i1ii1 == 74 : Ii111 ( I1I1iIiII1 , IIi1i )
elif I11i1ii1 == 75 : premierleague . Premier_League_Table ( )
elif I11i1ii1 == 76 : iI1i11II1i ( )
elif I11i1ii1 == 77 : oO0oO00oOo0OOO ( )
elif I11i1ii1 == 78 : Oo0OO0000oooo ( IIi1i )
elif I11i1ii1 == 79 : oO00oo0o00o0o ( IIi1i )
elif I11i1ii1 == 80 : ii11I1 ( IIi1i )
elif I11i1ii1 == 81 : OOoO ( )
elif I11i1ii1 == 82 : I1i11i ( IIi1i )
elif I11i1ii1 == 83 : OOooo ( IIi1i )
elif I11i1ii1 == 84 : cnfTVPlay1 ( IIi1i )
elif I11i1ii1 == 85 : cnfTVPlay2 ( IIi1i )
elif I11i1ii1 == 86 : TV . List_LiveTVFull ( I1I1iIiII1 )
elif I11i1ii1 == 87 : TV . LiveTVFull ( I1I1iIiII1 )
elif I11i1ii1 == 88 : TV . LiveTVFullCat ( )
elif I11i1ii1 == 89 : CNF_Studio_Indexer . Box_Office ( IIi1i )
elif I11i1ii1 == 90 : Alluc_Indexer . Search_Alluc ( )
elif I11i1ii1 == 91 : Alluc_Indexer . Get_Alluc_Page ( IIi1i , I1I1iIiII1 )
elif I11i1ii1 == 92 : Alluc_Indexer . Get_Playlink ( IIi1i , I1I1iIiII1 )
elif I11i1ii1 == 93 : FootballReplays . Replay_Menu ( )
elif I11i1ii1 == 94 : FootballReplays . get_All_Rows ( IIi1i )
elif I11i1ii1 == 95 : SoapsCatchup . Hollyoaks ( )
elif I11i1ii1 == 96 : SoapsCatchup . Eastenders ( )
elif I11i1ii1 == 97 : SoapsCatchup . Emmerdale ( )
elif I11i1ii1 == 98 : SoapsCatchup . CoronationStreet ( )
elif I11i1ii1 == 99 : O00Oo ( )
elif I11i1ii1 == 100 : O0iII1 ( I1I1iIiII1 , IIi1i , ii )
elif I11i1ii1 == 101 : SoapsCatchup . ImACeleb ( )
elif I11i1ii1 == 102 : documentary . DOC1 ( )
elif I11i1ii1 == 103 : documentary . DOC2 ( IIi1i )
elif I11i1ii1 == 104 : documentary . DOC3 ( IIi1i )
elif I11i1ii1 == 105 : documentary . DOCLIST ( IIi1i )
elif I11i1ii1 == 106 : IMDBsearch . Get_imdb_movie_search ( )
elif I11i1ii1 == 107 : IMDBsearch . Get_movie ( I1I1iIiII1 , IIi1i , ii )
elif I11i1ii1 == 108 : IMDBsearch . Get_imdb_TV_Episode ( I1I1iIiII1 , IIi1i )
elif I11i1ii1 == 109 : M3Uscrape . Get_m3u_links ( )
elif I11i1ii1 == 110 : M3Uscrape . Get_m3u_playlinks ( IIi1i )
elif I11i1ii1 == 111 : IMDBsearch . find_Alluc_Link ( I1I1iIiII1 )
elif I11i1ii1 == 112 : M3Uscrape . next_page ( IIi1i )
elif I11i1ii1 == 113 : search_addon . Get_Episode_2 ( IIi1i )
elif I11i1ii1 == 164 : i1II1I1Iii1 ( )
elif I11i1ii1 == 165 : CNF_Studio_Indexer . List_Movies ( IIi1i )
elif I11i1ii1 == 166 : CNF_Studio_Indexer . Get_Movie_Page ( IIi1i )
elif I11i1ii1 == 167 : LiveTVFull ( I1I1iIiII1 )
elif I11i1ii1 == 168 : List_LiveTVFull ( I1I1iIiII1 )
elif I11i1ii1 == 169 : CNF_Studio_Indexer . Resolve_CNF_Link ( I1I1iIiII1 , IIi1i , ii )
elif I11i1ii1 == 170 : List_LiveTVCats ( )
elif I11i1ii1 == 171 : CNF_Studio_Indexer . Search_Movie ( )
elif I11i1ii1 == 172 : oO0oO00oOo0OOO ( )
elif I11i1ii1 == 173 : CNF_Studio_Indexer . MV_Movies ( IIi1i )
elif I11i1ii1 == 174 : CNF_Studio_Indexer . Movie_ByYear ( IIi1i )
elif I11i1ii1 == 175 : search_addon . Search_Addon_Menu ( )
elif I11i1ii1 == 176 : search_addon . Search_Pandoras_Films ( )
elif I11i1ii1 == 177 : search_addon . Search_Pandoras_TV ( )
elif I11i1ii1 == 178 : search_addon . Search_Films_Lists ( )
elif I11i1ii1 == 179 : search_addon . Search_LiveTV ( )
elif I11i1ii1 == 180 : search_addon . Search_TV_Lists ( )
elif I11i1ii1 == 181 : search_addon . search_test ( )
elif I11i1ii1 == 182 : search_addon . Get_Episode ( IIi1i )
elif I11i1ii1 == 183 : search_addon . Play_link ( IIi1i )
elif I11i1ii1 == 185 : TV . Recent_Scraped ( )
elif I11i1ii1 == 186 : SEO_INFO . Get_Group ( )
elif I11i1ii1 == 187 : SEO_INFO . Get_Page ( IIi1i )
elif I11i1ii1 == 188 : SEO_INFO . Get_Info ( IIi1i )
elif I11i1ii1 == 189 : SEO_INFO . Install_Addon ( IIi1i , I1I1iIiII1 )
elif I11i1ii1 == 190 : SEO_INFO . Get_Download_File ( IIi1i )
elif I11i1ii1 == 191 : TV . get_Country ( )
elif I11i1ii1 == 192 : TV . get_Channel ( IIi1i )
elif I11i1ii1 == 193 : TV . get_Part_1_Link ( IIi1i )
elif I11i1ii1 == 401 : OOo ( IIi1i )
elif I11i1ii1 == 400 : I1I1i11 ( IIi1i )
elif I11i1ii1 == 402 : streams . ParseURL ( IIi1i )
elif I11i1ii1 == 403 : ooo000o0ooO0 ( IIi1i )
elif I11i1ii1 == 404 : Ii1II ( I1I1iIiII1 , IIi1i , ii )
elif I11i1ii1 == 405 : lists . TESTCATS2 ( )
elif I11i1ii1 == 406 : o00O ( )
elif I11i1ii1 == 407 : iiI11i1II ( IIi1i )
elif I11i1ii1 == 408 : o0O00OooOOOOO ( IIi1i )
elif I11i1ii1 == 409 : iiIII1i ( IIi1i )
elif I11i1ii1 == 410 : lists . TestDizi ( )
elif I11i1ii1 == 411 : iiIiI1i1 ( )
elif I11i1ii1 == 412 : M3UPLAY ( IIi1i )
elif I11i1ii1 == 413 : I1i1I11I ( )
elif I11i1ii1 == 414 : I1i1i1iii ( )
elif I11i1ii1 == 415 : Oo0OO ( )
elif I11i1ii1 == 416 : iiI11ii1I1 ( )
elif I11i1ii1 == 417 : Parsem3uURL ( IIi1i )
elif I11i1ii1 == 418 : TVParser . GetLinks ( IIi1i )
elif I11i1ii1 == 419 : TVParser . m3uCategory ( IIi1i )
elif I11i1ii1 == 420 : ii1I1IIii11 ( IIi1i )
elif I11i1ii1 == 421 : ooOoOo0 ( IIi1i )
elif I11i1ii1 == 422 : iII1i1 ( IIi1i )
elif I11i1ii1 == 423 : o00oO0oOo00 ( IIi1i )
elif I11i1ii1 == 424 : I11i1II ( IIi1i )
elif I11i1ii1 == 425 : SoapsCatchup . SOAPPLAYER ( I1I1iIiII1 , IIi1i )
elif I11i1ii1 == 426 : II111iiiI1Ii ( IIi1i )
elif I11i1ii1 == 427 : O0Oooo0O ( I1I1iIiII1 , IIi1i , I11i1ii1 , ii , iii1i , I1i11II )
elif I11i1ii1 == 428 : streams . ParseURL_search ( IIi1i )
elif I11i1ii1 == 501 : Ooooo00o0OoO ( IIi1i )
elif I11i1ii1 == 1000 : ChangeLog ( )
elif I11i1ii1 == 1001 : TV . TESTING ( )
elif I11i1ii1 == 1002 : Xvideos . X_vid_Menu ( )
elif I11i1ii1 == 1003 : Xvideos . tags ( IIi1i )
elif I11i1ii1 == 1004 : Xvideos . Pornstars ( IIi1i )
elif I11i1ii1 == 1005 : Xvideos . New_Videos ( IIi1i )
elif I11i1ii1 == 1006 : Xvideos . Genres ( IIi1i )
elif I11i1ii1 == 1007 : Xvideos . Search_X ( )
elif I11i1ii1 == 1008 : Xvideos . PlayLink ( IIi1i )
if 14 - 14: IiII % oO0o % Oo0Ooo - i11iIiiIii
xbmcplugin . endOfDirectory ( int ( sys . argv [ 1 ] ) )
# dd678faae9ac167bc83abf78e5cb2f3f0688d3a3
