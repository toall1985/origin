if 64 - 64: i11iIiiIii
if 65 - 65: O0 / iIii1I11I1II1 % OoooooooOO - i1IIi
if 73 - 73: II111iiii
if 22 - 22: I1IiiI * Oo0Ooo / OoO0O00 . OoOoOO00 . o0oOOo0O0Ooo / I1ii11iIi11i
if 48 - 48: oO0o / OOooOOo / I11i / Ii1I
if 48 - 48: iII111i % IiII + I1Ii111 / ooOoO0o * Ii1I
if 46 - 46: ooOoO0o * I11i - OoooooooOO
if 30 - 30: o0oOOo0O0Ooo - O0 % o0oOOo0O0Ooo - OoooooooOO * O0 * OoooooooOO
if 60 - 60: iIii1I11I1II1 / i1IIi * oO0o - I1ii11iIi11i + o0oOOo0O0Ooo
if 94 - 94: i1IIi % Oo0Ooo
if 68 - 68: Ii1I / O0
if 46 - 46: O0 * II111iiii / IiII * Oo0Ooo * iII111i . I11i
if 62 - 62: i11iIiiIii - II111iiii % I1Ii111 - iIii1I11I1II1 . I1ii11iIi11i . II111iiii
if 61 - 61: oO0o / OoOoOO00 / iII111i * OoO0O00 . II111iiii
if 1 - 1: II111iiii - I1ii11iIi11i % i11iIiiIii + IiII . I1Ii111
if 55 - 55: iIii1I11I1II1 - I1IiiI . Ii1I * IiII * i1IIi / iIii1I11I1II1
import sys
import urlparse
import yt
import urllib , urllib2 , datetime , re , os , base64 , xbmc , xbmcplugin , xbmcgui , xbmcaddon , xbmcvfs , traceback , cookielib , urlparse , httplib , time
import urlresolver
from bs4 import BeautifulSoup
from BeautifulSoup import BeautifulStoneSoup , BeautifulSOAP
try :
 import json
except :
 import simplejson as json
import time
import requests
from t0mm0 . common . addon import Addon
from t0mm0 . common . net import Net
from resources import streams , lists , utube , TV , Standup , Films , premierleague , Google , client , CNF_Studio_Indexer , Alluc_Indexer , FootballReplays , SoapsCatchup , documentary
from resources import M3Uscrape , search_addon , SEO_INFO , Xvideos
from resources . lib . parsers import TVParser
from datetime import datetime
if 79 - 79: oO0o + I1Ii111 . ooOoO0o * IiII % I11i . I1IiiI
O0o0o00o0Oo0 = base64 . decodestring
ii11 = lists . BASE2
I1I1i1 = lists . BASE3
IiI1i = lists . BASE4
OOo0o0 = lists . BASE5
O0OoOoo00o = lists . BASE6
iiiI11 = lists . BASE7
OOooO = lists . CAT
OOoO00o = lists . BASE
II111iiiiII = 'plugin.video.originentertainment'
oOoOo00oOo = sys . argv [ 0 ]
Oo = int ( sys . argv [ 1 ] )
o00O00O0O0O = urlparse . parse_qs ( sys . argv [ 2 ] [ 1 : ] )
OooO0OO = "Origin Entertainment"
iiiIi = "1.0.1"
IiIIIiI1I1 = 'Mozilla/5.0 (Windows NT 6.1; WOW64; Trident/7.0; AS; rv:11.0) like Gecko'
OoO000 = 'Mozilla/5.0 (Windows NT 6.3; rv:36.0) Gecko/20100101 Firefox/36.0'
IIiiIiI1 = 'Mozilla/5.0 (iPhone; CPU iPhone OS 6_0 like Mac OS X) AppleWebKit/536.26 (KHTML, like Gecko) Version/6.0 Mobile/10A5376e Safari/8536.25'
iiIiIIi = 'Mozilla/5.0 (Linux; Android 4.4.2; Nexus 4 Build/KOT49H) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/34.0.1847.114 Mobile Safari/537.36'
if 65 - 65: OoOoOO00
ii1I = xbmc . translatePath ( os . path . join ( 'special://home' , 'addons' , '' ) )
OooO0 = os . path . join ( ii1I , II111iiiiII , 'resources' , 'art' ) + os . sep
II11iiii1Ii = xbmc . translatePath ( os . path . join ( ii1I , II111iiiiII , 'fanart.jpg' ) )
OO0o = Net ( )
Ooo = [ ]
O0o0Oo = [ ]
Oo00OOOOO = [ ]
O0O = xbmcaddon . Addon ( id = II111iiiiII )
O00o0OO = O0O . getSetting ( 'Password' )
I11i1 = O0o0o00o0Oo0 ( 'aHR0cDovL2JhY2syYmFzaWNzLngxMGhvc3QuY29tL0FkdWx0L2luZGV4LnBocD9tb2RlPVh4WCZwYXNzd29yZD0=' )
iIi1ii1I1 = I11i1 + O00o0OO
o0 = O0o0o00o0Oo0 ( 'aHR0cDovL2lkYS5vbXJvZXAubmwvbnBvcGxheWVyL2kuanM=' )
I11II1i = xbmc . translatePath ( os . path . join ( 'special://home/userdata/addon_data/' + II111iiiiII + 'Article_Dump.txt' ) )
if 23 - 23: I1ii11iIi11i / o0oOOo0O0Ooo + I11i + I11i / II111iiii
if 26 - 26: OoooooooOO
IiiI11Iiiii = os . path . join ( xbmc . translatePath ( "special://userdata/addon_data" ) . decode ( "utf-8" ) , II111iiiiII )
if not os . path . exists ( IiiI11Iiiii ) :
 os . makedirs ( IiiI11Iiiii )
 if 18 - 18: o0oOOo0O0Ooo
I1i1I1II = os . path . join ( IiiI11Iiiii , 'tempList.txt' )
if 45 - 45: I1Ii111 . OoOoOO00
#def ChangeLog():
#    TextBoxes('Change Log, Future Plans and General Info', ' [CR] ---------------------------------------------------------------------------------------------------------- [CR]Going to look at adding TV guide to new live tv streams [CR] ---------------------------------------------------------------------------------------------------------- [CR]Hoping to get search function in soon to make things easier to find [CR] ---------------------------------------------------------------------------------------------------------- [CR]Am thinking of making a second release of the addon once my knowledge grows to tidy things up a bit [CR] ---------------------------------------------------------------------------------------------------------- [CR]11/12/15 Fixed Scraper, still need to work on some streams not playing [CR] ---------------------------------------------------------------------------------------------------------- [CR]Massive thanks and respect to Chris for all his help lately helping me push forwards [CR] ---------------------------------------------------------------------------------------------------------- [CR]Also to Jay, Damian and Sponge head for being here from the start and of course Team H20 [CR] ---------------------------------------------------------------------------------------------------------- [CR]Will look at adding a music section once search function in and working properly [CR] ---------------------------------------------------------------------------------------------------------- [CR]Fixes Needed - Scraper streams not working. Newspaper Article and Prem League table windows not working on android  ')
if 83 - 83: oO0o . iIii1I11I1II1 . I1ii11iIi11i
if 31 - 31: Ii1I . Ii1I - o0oOOo0O0Ooo / OoO0O00 + ooOoO0o * I1IiiI
if 63 - 63: I1Ii111 % i1IIi / OoooooooOO - OoooooooOO
def iIii11I ( query ) :
 return oOoOo00oOo + '?' + urllib . urlencode ( query )
 if 69 - 69: oO0o % I1Ii111 - o0oOOo0O0Ooo + I1Ii111 - O0 % OoooooooOO
def Iii111II ( ) :
 if 9 - 9: OoO0O00
 if 33 - 33: ooOoO0o . iII111i
 O0oo0OO0oOOOo ( '24/7 Shows' , OOoO00o + '24-7' + OOooO , 400 , OooO0 + '24shows.png' )
 i1i1i11IIi ( 'Lists' , '' , 53 , OooO0 + 'lists.png' , OooO0 + 'background.png' , '' )
 i1i1i11IIi ( 'Live TV' , '' , 41 , OooO0 + 'livetv.png' , OooO0 + 'background.png' , '' )
 i1i1i11IIi ( 'M3U8 Lists' , '' , 54 , OooO0 + 'm3u8.png' , OooO0 + 'background.png' , '' )
 i1i1i11IIi ( 'Movies' , '' , 10 , OooO0 + 'movies.png' , OooO0 + 'background.png' , '' )
 i1i1i11IIi ( 'News' , '' , 72 , OooO0 + 'News2.png' , OooO0 + 'background.png' , '' )
 i1i1i11IIi ( 'Pandoras Box' , '' , 55 , OooO0 + 'pandorasbox.png' , OooO0 + 'background.png' , '' )
 i1i1i11IIi ( 'Radio' , '' , 63 , OooO0 + 'radio.png' , OooO0 + 'background.png' , '' )
 i1i1i11IIi ( 'Scraper' , '' , 76 , OooO0 + 'scraper.png' , OooO0 + 'background.png' , '' )
 i1i1i11IIi ( 'Search' , '' , 175 , OooO0 + 'search.png' , OooO0 + 'background.png' , '' )
 i1i1i11IIi ( 'Seo Guides' , '' , 186 , OooO0 + 'icon.png' , OooO0 + 'background.png' , '' )
 i1i1i11IIi ( 'Sports' , '' , 64 , OooO0 + 'sports.png' , OooO0 + 'background.png' , '' )
 i1i1i11IIi ( 'Stand Up' , '' , 12 , OooO0 + 'comedy.png' , OooO0 + 'background.png' , '' )
 i1i1i11IIi ( 'Test Area' , '' , 52 , OooO0 + 'testarea.png' , OooO0 + 'background.png' , '' )
 i1i1i11IIi ( 'TV Guide' , '' , 69 , OooO0 + 'tvguide.png' , OooO0 + 'background.png' , '' )
 i1i1i11IIi ( 'TV Shows' , '' , 11 , OooO0 + 'tv.png' , OooO0 + 'background.png' , '' )
 O0oo0OO0oOOOo ( 'World Cams' , OOoO00o + 'worldcams' + OOooO , 400 , OooO0 + 'worldcams.png' )
 if O00o0OO == O0o0o00o0Oo0 ( 'Zm9yZGZpZXN0YQ==' ) :
  O0oo0OO0oOOOo ( 'Adult Movies' , '' , 1002 , OooO0 + 'icon.png' )
  if 33 - 33: o0oOOo0O0Ooo + OOooOOo * OoO0O00 - Oo0Ooo / oO0o % Ii1I
  if 21 - 21: OoO0O00 * iIii1I11I1II1 % oO0o * i1IIi
def Ii11Ii1I ( ) :
 if 72 - 72: iII111i / i1IIi * Oo0Ooo - I1Ii111
 i1i1i11IIi ( 'Football' , '' , 57 , OooO0 + 'icon.png' , OooO0 + 'background.png' , '' )
 i1i1i11IIi ( 'Sports Channels' , '' , 86 , OooO0 + 'icon.png' , OooO0 + 'background.png' , '' )
 if 51 - 51: II111iiii * OoO0O00 % o0oOOo0O0Ooo * II111iiii % I1ii11iIi11i / ooOoO0o
 if 49 - 49: o0oOOo0O0Ooo
 xbmcplugin . endOfDirectory ( Oo )
 if 35 - 35: OoOoOO00 - OoooooooOO / I1ii11iIi11i % i1IIi
 if 78 - 78: I11i
def OO00Oo ( ) :
 if 51 - 51: IiII * o0oOOo0O0Ooo + I11i + OoO0O00
 o0O0O00 = o000o ( O0o0o00o0Oo0 ( 'aHR0cDovL3d3dy5saXN0ZW5saXZlLmV1Lw==' ) )
 I11IiI1I11i1i = re . compile ( '<tr>.+?<a href="(.+?)">(.+?)</a>' , re . DOTALL ) . findall ( o0O0O00 )
 for iI1ii1Ii , oooo000 in I11IiI1I11i1i :
  O0oo0OO0oOOOo ( ( oooo000 ) . replace ( 'email me' , '' ) . replace ( 'External services' , '' ) , O0o0o00o0Oo0 ( 'aHR0cDovL3d3dy5saXN0ZW5saXZlLmV1LyVz' ) % iI1ii1Ii , 62 , OooO0 + 'icon.png' )
  if 16 - 16: I1ii11iIi11i + OoO0O00 - II111iiii
  if 85 - 85: OoOoOO00 + i1IIi
def Oo0OoO00oOO0o ( url ) :
 if 80 - 80: oO0o + OOooOOo - OOooOOo % iII111i
 o0O0O00 = o000o ( url )
 I11IiI1I11i1i = re . compile ( '<tr>.+?<td><a href=".+?"><b>(.+?)</b>.+?<td><a href="(.+?)">' , re . DOTALL ) . findall ( o0O0O00 )
 for oooo000 , url in I11IiI1I11i1i :
  OoOO0oo0o ( oooo000 , url , 401 , OooO0 + 'icon.png' )
  if 14 - 14: o0oOOo0O0Ooo * iII111i * iII111i / OoOoOO00
  if 81 - 81: iIii1I11I1II1 + iIii1I11I1II1 * IiII * ooOoO0o % ooOoO0o
def ooOO00O00oo ( ) :
 O0oo0OO0oOOOo ( 'Fixtures' , '' , 58 , OooO0 + 'icon.png' )
 if 3 - 3: I1Ii111 - O0 / I1Ii111 % OoO0O00 / I1Ii111 . I1IiiI
 iiI111I1iIiI ( 'Replays' , '' , 93 , OooO0 + 'icon.png' )
 if 41 - 41: Oo0Ooo . ooOoO0o + O0 * o0oOOo0O0Ooo % Oo0Ooo * Oo0Ooo
 if 19 - 19: iII111i
 if 46 - 46: I1ii11iIi11i - Ii1I . iIii1I11I1II1 / I1ii11iIi11i
 if 7 - 7: i1IIi / I1IiiI * I1Ii111 . IiII . iIii1I11I1II1
 if 13 - 13: OOooOOo / i11iIiiIii
 if 2 - 2: I1IiiI / O0 / o0oOOo0O0Ooo % OoOoOO00 % Ii1I
 if 52 - 52: o0oOOo0O0Ooo
 if 95 - 95: Ii1I
 if 87 - 87: ooOoO0o + OoOoOO00 . OOooOOo + OoOoOO00
def oO ( ) :
 if 7 - 7: o0oOOo0O0Ooo - I1IiiI
 o0O0O00 = o000o ( O0o0o00o0Oo0 ( 'aHR0cDovL3NlZWR1cmdyZWVkLngxMGhvc3QuY29tL29yaWdpbi9zcG9uZ2VtYWluLnBocA==' ) )
 I11IiI1I11i1i = re . compile ( '<item>.+?<title>(.+?)</title>.+?<description>(.+?)</description>.+?<link>(.+?)</link>.+?<thumbnail>(.+?)</thumbnail>.+?<fanart>(.+?)</fanart>.+?<mode>(.+?)</mode>.+?</item>' , re . DOTALL ) . findall ( o0O0O00 )
 for oooo000 , OOo00O0 , iI1ii1Ii , ooOOOoO , o0o , o00 in I11IiI1I11i1i :
  OooOO000 ( oooo000 , iI1ii1Ii , o00 , ooOOOoO , o0o , OOo00O0 )
  if 97 - 97: I1ii11iIi11i + OOooOOo / iIii1I11I1II1 / iII111i
def I1111IIi ( url ) :
 if 93 - 93: OoooooooOO / I1IiiI % i11iIiiIii + I1ii11iIi11i * OoO0O00
 xbmcplugin . addSortMethod ( handle = int ( sys . argv [ 1 ] ) , sortMethod = xbmcplugin . SORT_METHOD_TITLE )
 I1 = ( '%s%s' % ( OOoO00o , url ) )
 iI11Ii = o000o ( url )
 I11IiI1I11i1i = re . compile ( '<a href="(.+?)" target="_blank"><img src="(.+?)" style="max-width:200px;" /><description = "(.+?)" /><background = "(.+?)" </background></a><br><b>(.+?)</b>' ) . findall ( iI11Ii )
 for url , i1iIIIi1i , OOo00O0 , iI1iIIiiii , oooo000 in I11IiI1I11i1i :
  OooOO000 ( oooo000 , url , 401 , i1iIIIi1i , iI1iIIiiii , OOo00O0 )
  if 26 - 26: I11i . OoooooooOO
  I11i1ii1 ( 'tvshows' , 'Media Info 3' )
  if 87 - 87: I11i - iIii1I11I1II1 + I1IiiI . iII111i
  xbmcplugin . addSortMethod ( Oo , xbmcplugin . SORT_METHOD_TITLE ) ;
  if 62 - 62: O0 * i1IIi * o0oOOo0O0Ooo - I1IiiI + I1IiiI
  if 34 - 34: iIii1I11I1II1 - o0oOOo0O0Ooo
def o00oooO0Oo ( url ) :
 if 78 - 78: Ii1I % I1Ii111 + I1ii11iIi11i
 o0O0O00 = o000o ( url )
 I11IiI1I11i1i = re . compile ( '<item>.+?<title>(.+?)</title>.+?<description>(.+?)</description>.+?<link>(.+?)</link>.+?<thumbnail>(.+?)</thumbnail>.+?<fanart>(.+?)</fanart>.+?<mode>(.+?)</mode>.+?</item>' , re . DOTALL ) . findall ( o0O0O00 )
 for oooo000 , OOo00O0 , url , ooOOOoO , o0o , o00 in I11IiI1I11i1i :
  OOooOoooOoOo ( oooo000 , url , o00 , ooOOOoO , o0o , OOo00O0 )
  if 84 - 84: IiII
 I11i1ii1 ( 'tvshows' , 'Media Info 3' )
 if 86 - 86: OoOoOO00 - Ii1I - OoO0O00 * iII111i
 if 66 - 66: OoooooooOO + O0
 xbmcplugin . addSortMethod ( Oo , xbmcplugin . SORT_METHOD_TITLE ) ;
 if 11 - 11: I11i + OoooooooOO - OoO0O00 / o0oOOo0O0Ooo + Oo0Ooo . II111iiii
def OooOO000 ( name , url , mode , iconimage , fanart , description ) :
 if 41 - 41: Ii1I - O0 - O0
 oO00OOoO00 = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage ) + "&fanart=" + urllib . quote_plus ( fanart ) + "&description=" + urllib . quote_plus ( description )
 IiI111111IIII = True
 i1Ii = xbmcgui . ListItem ( name , iconImage = "DefaultFolder.png" , thumbnailImage = iconimage )
 i1Ii . setInfo ( type = "Video" , infoLabels = { "Title" : name , "Plot" : description } )
 i1Ii . setProperty ( "Fanart_Image" , fanart )
 IiI111111IIII = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = oO00OOoO00 , listitem = i1Ii , isFolder = False )
 return IiI111111IIII
 if 14 - 14: iII111i
def OOooOoooOoOo ( name , url , mode , iconimage , fanart , description ) :
 if 11 - 11: IiII * I1IiiI . iIii1I11I1II1 % OoooooooOO + iII111i
 oO00OOoO00 = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage ) + "&fanart=" + urllib . quote_plus ( fanart ) + "&description=" + urllib . quote_plus ( description )
 IiI111111IIII = True
 i1Ii = xbmcgui . ListItem ( name , iconImage = "DefaultFolder.png" , thumbnailImage = iconimage )
 i1Ii . setInfo ( type = "Video" , infoLabels = { "Title" : name , "Plot" : description } )
 i1Ii . setProperty ( "Fanart_Image" , fanart )
 IiI111111IIII = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = oO00OOoO00 , listitem = i1Ii , isFolder = True )
 return IiI111111IIII
 if 78 - 78: OoO0O00 . OOooOOo + OoO0O00 / I11i / OoO0O00
 if 54 - 54: OoOoOO00 % iII111i
 if 37 - 37: OoOoOO00 * Oo0Ooo / ooOoO0o - iII111i % II111iiii . oO0o
 if 88 - 88: iII111i . II111iiii * II111iiii % I1Ii111
def I11i1ii1 ( content , viewType ) :
 if content :
  xbmcplugin . setContent ( int ( sys . argv [ 1 ] ) , content )
  if 15 - 15: i1IIi * I1IiiI + i11iIiiIii
  if 6 - 6: ooOoO0o / i11iIiiIii + iII111i * oO0o
  if 80 - 80: II111iiii
def O0Oi1I1I ( ) :
 if 12 - 12: i11iIiiIii / OoO0O00
 O0oo0OO0oOOOo ( 'List 1' , '' , 411 , OooO0 + 'icon.png' )
 O0oo0OO0oOOOo ( 'List 2' , '' , 413 , OooO0 + 'icon.png' )
 O0oo0OO0oOOOo ( 'List 3' , '' , 414 , OooO0 + 'icon.png' )
 O0oo0OO0oOOOo ( 'List 4' , '' , 415 , OooO0 + 'icon.png' )
 O0oo0OO0oOOOo ( 'List 5' , '' , 416 , OooO0 + 'icon.png' )
 if 80 - 80: I1Ii111 . i11iIiiIii - o0oOOo0O0Ooo
 if 25 - 25: OoO0O00
def oOo0oO ( ) :
 if 51 - 51: Oo0Ooo - oO0o + II111iiii * Ii1I . I11i + oO0o
 O0oo0OO0oOOOo ( 'Test Area' , OOoO00o + 'test' + OOooO , 400 , OooO0 + 'icon.png' )
 O0oo0OO0oOOOo ( 'Sponge Test' , OOo0o0 + 'badlands' + OOooO , 400 , OooO0 + 'icon.png' )
 O0oo0OO0oOOOo ( 'Dizilab Scraper Test' , '' , 410 , OooO0 + 'icon.png' )
 if 78 - 78: i11iIiiIii / iII111i - Ii1I / OOooOOo + oO0o
 if 82 - 82: Ii1I
 xbmcplugin . endOfDirectory ( Oo )
 if 46 - 46: OoooooooOO . i11iIiiIii
 if 94 - 94: o0oOOo0O0Ooo * Ii1I / Oo0Ooo / Ii1I
 if 87 - 87: Oo0Ooo . IiII
 if 75 - 75: ooOoO0o + OoOoOO00 + o0oOOo0O0Ooo * I11i % oO0o . iII111i
def i1i1i11IIi ( name , url , mode , iconimage , fanart , description ) :
 oO00OOoO00 = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage ) + "&fanart=" + urllib . quote_plus ( fanart ) + "&description=" + urllib . quote_plus ( description )
 IiI111111IIII = True
 i1Ii = xbmcgui . ListItem ( name , iconImage = "DefaultFolder.png" , thumbnailImage = iconimage )
 i1Ii . setInfo ( type = "Video" , infoLabels = { "Title" : name , "Plot" : description } )
 i1Ii . setProperty ( "Fanart_Image" , fanart )
 if mode == 5 :
  IiI111111IIII = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = oO00OOoO00 , listitem = i1Ii , isFolder = False )
 else :
  IiI111111IIII = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = oO00OOoO00 , listitem = i1Ii , isFolder = True )
  if 55 - 55: OOooOOo . I1IiiI
 return IiI111111IIII
 if 61 - 61: Oo0Ooo % IiII . Oo0Ooo
 if 100 - 100: I1Ii111 * O0
def iiI111I1iIiI ( name , url , mode , iconimage ) :
 oO00OOoO00 = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name )
 IiI111111IIII = True
 i1Ii = xbmcgui . ListItem ( name , iconImage = "DefaultFolder.png" , thumbnailImage = iconimage )
 i1Ii . setInfo ( type = "Video" , infoLabels = { "Title" : name } )
 IiI111111IIII = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = oO00OOoO00 , listitem = i1Ii , isFolder = True )
 return IiI111111IIII
 if 64 - 64: OOooOOo % iIii1I11I1II1 * oO0o
def OoOO0oo0o ( name , url , mode , iconimage ) :
 oO00OOoO00 = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name )
 IiI111111IIII = True
 i1Ii = xbmcgui . ListItem ( name , iconImage = "DefaultFolder.png" , thumbnailImage = iconimage )
 i1Ii . setInfo ( type = "Video" , infoLabels = { "Title" : name } )
 IiI111111IIII = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = oO00OOoO00 , listitem = i1Ii , isFolder = False )
 return IiI111111IIII
if 79 - 79: O0
if 78 - 78: I1ii11iIi11i + OOooOOo - I1Ii111
if 38 - 38: o0oOOo0O0Ooo - oO0o + iIii1I11I1II1 / OoOoOO00 % Oo0Ooo
if 57 - 57: OoO0O00 / ooOoO0o
if 29 - 29: iIii1I11I1II1 + OoOoOO00 * OoO0O00 * OOooOOo . I1IiiI * I1IiiI
if 7 - 7: IiII * I1Ii111 % Ii1I - o0oOOo0O0Ooo
if 13 - 13: Ii1I . i11iIiiIii
if 56 - 56: I1ii11iIi11i % O0 - I1IiiI
if 100 - 100: Ii1I - O0 % oO0o * OOooOOo + I1IiiI
def Oo0O0oooo ( ) :
 o0O0O00 = o000o ( 'http://back2basics.x10host.com/back2basics/test/m3u1.m3u' )
 I11IiI1I11i1i = re . compile ( '^#EXTINF:-?[0-9]*(.*?),(.*?)\n(.*?)$' , re . I + re . M + re . U + re . S ) . findall ( o0O0O00 )
 for I111iI , oooo000 , iI1ii1Ii in I11IiI1I11i1i :
  OoOO0oo0o ( oooo000 , iI1ii1Ii , 401 , OooO0 + 'icon.png' )
  if 56 - 56: I1IiiI
def O0oO ( ) :
 o0O0O00 = o000o ( 'http://back2basics.x10host.com/back2basics/test/m3u2.m3u' )
 I11IiI1I11i1i = re . compile ( '^#EXTINF:-?[0-9]*(.*?),(.*?)\n(.*?)$' , re . I + re . M + re . U + re . S ) . findall ( o0O0O00 )
 for I111iI , oooo000 , iI1ii1Ii in I11IiI1I11i1i :
  OoOO0oo0o ( oooo000 , iI1ii1Ii , 401 , OooO0 + 'icon.png' )
  if 73 - 73: I1ii11iIi11i * i11iIiiIii % oO0o . I1ii11iIi11i
def OOOOo0 ( ) :
 o0O0O00 = o000o ( 'http://back2basics.x10host.com/back2basics/test/m3u3.m3u' )
 I11IiI1I11i1i = re . compile ( '^#EXTINF:-?[0-9]*(.*?),(.*?)\n(.*?)$' , re . I + re . M + re . U + re . S ) . findall ( o0O0O00 )
 for I111iI , oooo000 , iI1ii1Ii in I11IiI1I11i1i :
  OoOO0oo0o ( oooo000 , iI1ii1Ii , 401 , OooO0 + 'icon.png' )
  if 49 - 49: II111iiii % O0 . OoOoOO00 + oO0o / I1IiiI
def O0oOOoOooooO ( ) :
 o0O0O00 = o000o ( 'http://back2basics.x10host.com/back2basics/test/m3u4.m3u' )
 I11IiI1I11i1i = re . compile ( '^#EXTINF:-?[0-9]*(.*?),(.*?)\n(.*?)$' , re . I + re . M + re . U + re . S ) . findall ( o0O0O00 )
 for I111iI , oooo000 , iI1ii1Ii in I11IiI1I11i1i :
  OoOO0oo0o ( oooo000 , iI1ii1Ii , 401 , OooO0 + 'icon.png' )
  if 62 - 62: OoooooooOO * I1IiiI
def oOOOoo0O0oO ( ) :
 o0O0O00 = o000o ( 'http://back2basics.x10host.com/back2basics/test/m3u5.m3u' )
 I11IiI1I11i1i = re . compile ( '^#EXTINF:-?[0-9]*(.*?),(.*?)\n(.*?)$' , re . I + re . M + re . U + re . S ) . findall ( o0O0O00 )
 for I111iI , oooo000 , iI1ii1Ii in I11IiI1I11i1i :
  OoOO0oo0o ( oooo000 , iI1ii1Ii , 401 , OooO0 + 'icon.png' )
  if 6 - 6: OOooOOo * o0oOOo0O0Ooo + iII111i
  if 44 - 44: Ii1I % OoO0O00 + OoooooooOO - O0 - Ii1I - II111iiii
  if 99 - 99: ooOoO0o . Ii1I + I1Ii111 + OoooooooOO % o0oOOo0O0Ooo
  if 51 - 51: iIii1I11I1II1
  if 34 - 34: oO0o + I1IiiI - oO0o
def IiI1I1i1I1 ( ) :
 o0O0O00 = o000o ( O0o0o00o0Oo0 ( 'aHR0cDovL2xpdmVvbnNhdC5jb20vcXVpY2tpbmRleC5odG1s' ) )
 I11IiI1I11i1i = re . compile ( '<a target="_self" href="(.+?)".+?src="(.+?)" alt="(.+?)"' , re . DOTALL ) . findall ( o0O0O00 )
 for iI1ii1Ii , ooOOOoO , oooo000 in I11IiI1I11i1i :
  iiI111I1iIiI ( ( oooo000 ) . replace ( 'amp;' , '' ) , O0o0o00o0Oo0 ( 'aHR0cDovL2xpdmVvbnNhdC5jb20v' ) + iI1ii1Ii , 59 , O0o0o00o0Oo0 ( 'aHR0cDovL2xpdmVvbnNhdC5jb20v' ) + ooOOOoO )
  if 98 - 98: I11i % i11iIiiIii % ooOoO0o + Ii1I
def OOoOO0o0o0 ( url ) :
 ii1I1 = o000o ( url )
 OooooOOoo0 = re . compile ( 'AndClearL.+?><h2.+?head>(.*?)float' , re . DOTALL ) . findall ( ii1I1 )
 for OooooOOoo0 in OooooOOoo0 :
  i1I1IiiIi1i = re . compile ( '(.*?)</h2>' ) . findall ( str ( OooooOOoo0 ) )
  for iiI11ii1I1 in i1I1IiiIi1i :
   iiI11ii1I1 = iiI11ii1I1
  Ooo0OOoOoO0 = re . compile ( 'comp_head>(.*?)</span>.*?<div class = fLeft width = ".*?"><img src="(.*?)">.*?</div>.*?ST:(.*?)</div>(.+?)<!-- around all of channel types ENDS 2-->' , re . DOTALL ) . findall ( str ( OooooOOoo0 ) )
  for oOo0OOoO0 , ooOOOoO , time , II in Ooo0OOoOoO0 :
   o0Oo0oO0oOO00 = re . compile ( ",CAPTION, '(.+?)&nbsp" ) . findall ( II )
   OOooOoooOoOo ( iiI11ii1I1 + ' - ' + oOo0OOoO0 + ' - ' + time , '' , 65 , O0o0o00o0Oo0 ( 'aHR0cDovL2xpdmVvbnNhdC5jb20=' ) + ooOOOoO , '' , ( str ( o0Oo0oO0oOO00 ) ) )
   if 92 - 92: OoooooooOO * I1Ii111
 I11i1ii1 ( 'tvshows' , 'Media Info 3' )
 if 100 - 100: I1Ii111 + I1Ii111 * IiII
def I1i ( ) :
 if 99 - 99: I1Ii111 + OoOoOO00 * iIii1I11I1II1 / OoooooooOO
 if 46 - 46: I11i / Ii1I
 i1i1i11IIi ( 'Basic' , '' , 65 , OooO0 + 'tvguide.png' , OooO0 + 'background.png' , '' )
 i1i1i11IIi ( 'Full' , '' , 71 , OooO0 + 'tvguide.png' , OooO0 + 'background.png' , '' )
 i1i1i11IIi ( 'Sky Basic' , '' , 70 , OooO0 + 'tvguide.png' , OooO0 + 'background.png' , '' )
 if 57 - 57: IiII / iII111i * O0 - OoooooooOO % iIii1I11I1II1
 if 33 - 33: i1IIi / Ii1I
def ooO0oooOO0 ( ) :
 o0O0O00 = o000o ( 'http://www.locatetv.com/uk/listings/sky' )
 I11IiI1I11i1i = re . compile ( '<li>.+?<li class="channel" data-name="(.+?)">.+?<a href="(.+?)">.+?<img src="(.+?)" alt=".+?title="(.+?)" class' , re . DOTALL ) . findall ( o0O0O00 )
 for oooo000 , iI1ii1Ii , ooOOOoO , o0ooo0 in I11IiI1I11i1i :
  iiI111I1iIiI ( ( oooo000 + ' - ' + o0ooo0 ) . replace ( '&#039;s' , '' ) . replace ( '&amp;' , '&' ) , 'http://www.locatetv.com' + iI1ii1Ii , '' , ooOOOoO )
  if 61 - 61: OoOoOO00 - OOooOOo - i1IIi
  if 25 - 25: O0 * I11i + I1ii11iIi11i . o0oOOo0O0Ooo . o0oOOo0O0Ooo
def oOooO ( ) :
 o0O0O00 = o000o ( 'http://tvguideuk.telegraph.co.uk/' )
 I11IiI1I11i1i = re . compile ( '<li class="tabs"><span><a href="(.+?)">(.+?)</a></span></li>' ) . findall ( o0O0O00 )
 for iI1ii1Ii , oooo000 in I11IiI1I11i1i :
  if 'amp;' in iI1ii1Ii :
   iI1ii1Ii = iI1ii1Ii . replace ( 'amp;' , '' )
  iiI111I1iIiI ( oooo000 , 'http://tvguideuk.telegraph.co.uk/' + iI1ii1Ii , 65 , '' )
  if 10 - 10: OoOoOO00 % OoOoOO00 - OoOoOO00 . iII111i
def o0OoOo00o0o ( ) :
 i1i1i11IIi ( 'Site 1 Films' , '' , 77 , OooO0 + 'scraper.png' , OooO0 + 'background.png' , '' )
 i1i1i11IIi ( 'Search Alluc*in testing*' , '' , 90 , OooO0 + 'scraper.png' , OooO0 + 'background.png' , '' )
 i1i1i11IIi ( 'Scraped M3U8 Lists' , '' , 109 , OooO0 + 'scraper.png' , OooO0 + 'background.png' , '' )
 i1i1i11IIi ( 'IMDB Search' , '' , 106 , OooO0 + 'scraper.png' , OooO0 + 'background.png' , '' )
 if 41 - 41: ooOoO0o % OoO0O00 - Oo0Ooo * I1Ii111 * Oo0Ooo
 if 69 - 69: OOooOOo - OoooooooOO + o0oOOo0O0Ooo - I11i
 if 23 - 23: i11iIiiIii
def II1iIi11 ( url ) :
 o0O0O00 = o000o ( url )
 I11IiI1I11i1i = re . compile ( '<div class="channel_name">(.+?)<.+?channel_id=(.+?).+?>(.+?)</a>' , re . DOTALL ) . findall ( o0O0O00 )
 for oooo000 , id , II1iIi11 in I11IiI1I11i1i :
  iiI111I1iIiI ( oooo000 + ' - ' + II1iIi11 , '' , 41 , '' )
  if 12 - 12: Ii1I + i11iIiiIii * iIii1I11I1II1 / I1ii11iIi11i . I11i
def Iii1iI ( ) :
 o0O0O00 = o000o ( '' )
 I11IiI1I11i1i = re . compile ( '<td><a href="(.+?)"><img src="(.+?)" width="100" height="100" border="0"><br>(.+?)</a></td>' ) . findall ( o0O0O00 )
 for iI1ii1Ii , ooOOOoO , oooo000 in I11IiI1I11i1i :
  iiI111I1iIiI ( oooo000 , '' , 420 , OooO0 + 'icon.png' )
  if 29 - 29: I1IiiI % OOooOOo - I1IiiI / OOooOOo . i1IIi
def i11III1111iIi ( url ) :
 o0O0O00 = o000o ( url )
 I11IiI1I11i1i = re . compile ( '' , re . DOTALL ) . findall ( o0O0O00 )
 for url , oooo000 , ooOOOoO in I11IiI1I11i1i :
  iiI111I1iIiI ( oooo000 , url , 421 , 'http://www.movietubenow.biz%s' % ooOOOoO )
  if 38 - 38: iII111i + I11i / I1Ii111 % ooOoO0o - I1ii11iIi11i
def iI11 ( url ) :
 o0O0O00 = o000o ( url )
 I11IiI1I11i1i = re . compile ( '<iframe width="680" height="430" scrolling="no" frameborder="0" src="(.+?)"' , re . DOTALL ) . findall ( o0O0O00 )
 for url in I11IiI1I11i1i :
  iiI111I1iIiI ( oooo000 , url , 422 , OooO0 + 'icon.png' )
  if 10 - 10: II111iiii / oO0o % OoooooooOO * I11i % I1ii11iIi11i
def I1i11 ( url ) :
 o0O0O00 = o000o ( url )
 I11IiI1I11i1i = re . compile ( '<source src="(.+?)" type="video/mp4"/>' ) . findall ( o0O0O00 )
 for url in I11IiI1I11i1i :
  iiI111I1iIiI ( oooo000 , url , 401 , '' )
  if 12 - 12: i1IIi + i1IIi - I1ii11iIi11i * Oo0Ooo % Oo0Ooo - II111iiii
  if 52 - 52: ooOoO0o . iII111i + I1Ii111
def iiii1IIi ( ) :
 o0O0O00 = o000o ( 'http://www.animetoon.org/cartoon' )
 I11IiI1I11i1i = re . compile ( '<td><a href="(.+?)">(.+)</a></td>' ) . findall ( o0O0O00 )
 for iI1ii1Ii , oooo000 in I11IiI1I11i1i :
  iiI111I1iIiI ( oooo000 , iI1ii1Ii , 407 , OooO0 + 'icon.png' )
  if 33 - 33: OoOoOO00 * OOooOOo - II111iiii
def OOo0o0O0O ( ) :
 o0O0O00 = o000o ( 'http://www.mirror.co.uk/' )
 I11IiI1I11i1i = re . compile ( '<a href="(.+?)" data-type="section-head_.+?" data-action="section:.+?">(.+?)</a>' ) . findall ( o0O0O00 )
 for iI1ii1Ii , oooo000 in I11IiI1I11i1i :
  iiI111I1iIiI ( ( oooo000 ) . replace ( 'amp;' , '' ) , iI1ii1Ii , 73 , OooO0 + 'icon.png' )
  if 65 - 65: i11iIiiIii
  if 85 - 85: Ii1I % iII111i + I11i / o0oOOo0O0Ooo . oO0o + OOooOOo
def ooOoOo0 ( url ) :
 o0O0O00 = o000o ( url )
 I11IiI1I11i1i = re . compile ( '<figure>.+?<img src="(.+?)" class="aboveHeadline .+?<a href="(.+?)".+?&#xa;(.+?)</a>' , re . DOTALL ) . findall ( o0O0O00 )
 for ooOOOoO , url , oooo000 in I11IiI1I11i1i :
  OoOO0oo0o ( ( oooo000 ) . replace ( 'amp;' , '' ) . replace ( '&#x3a' , '' ) . replace ( '&#xa; </a>' , '' ) . replace ( '&#xa;' , '' ) . replace ( '&quot;' , '' ) . replace ( '&#x27;' , '' ) , url , 74 , ooOOOoO )
  print '>>>>>>>>>>' + url
  if 2 - 2: iII111i % iIii1I11I1II1 * iIii1I11I1II1 . o0oOOo0O0Ooo / iII111i
  if 27 - 27: OoO0O00 + ooOoO0o - i1IIi
def O00oOOooo ( url ) :
 o0O0O00 = o000o ( url )
 I11IiI1I11i1i = re . compile ( '&nbsp;<a href="(.+?)">(.+?)</a>' ) . findall ( o0O0O00 )
 for url , oooo000 in I11IiI1I11i1i :
  iiI111I1iIiI ( oooo000 , url , 408 , OooO0 + 'icon.png' )
  if 50 - 50: I1ii11iIi11i % O0 * o0oOOo0O0Ooo
def i1Iii11Ii1i1 ( url ) :
 o0O0O00 = o000o ( url )
 I11IiI1I11i1i = re . compile ( '"playlist">(.+?)</span></div><div><iframe src="(.+?)"' ) . findall ( o0O0O00 )
 for oooo000 , url in I11IiI1I11i1i :
  iiI111I1iIiI ( oooo000 , url , 409 , OooO0 + 'icon.png' )
  if 59 - 59: Oo0Ooo % OoooooooOO . iII111i / IiII + I1IiiI
def o0O0oO0O00O0o ( url ) :
 o0O0O00 = o000o ( url )
 I11IiI1I11i1i = re . compile ( "url: '(.+?)'," ) . findall ( o0O0O00 )
 for url in I11IiI1I11i1i :
  OoOO0oo0o ( 'STREAM' , url , 401 , OooO0 + 'icon.png' )
  if 28 - 28: Oo0Ooo + OoO0O00 * OOooOOo % oO0o . I11i % O0
def I1iiiiIii ( ) :
 o0O0O00 = o000o ( 'http://tvshows.cnfstudio.com/' )
 I11IiI1I11i1i = re . compile ( '<a href="http://tvshows.cnfstudio.com/genre/(.+?)">(.+?)</a>' ) . findall ( o0O0O00 )
 for iI1ii1Ii , oooo000 in I11IiI1I11i1i :
  iiI111I1iIiI ( oooo000 , 'http://tvshows.cnfstudio.com/genre/' + iI1ii1Ii , 82 , OooO0 + 'icon.png' )
  print '>>>>>>>>>>' + iI1ii1Ii
  if 19 - 19: OoO0O00 - Oo0Ooo . O0
def ooOo00 ( url ) :
 o0O0O00 = o000o ( url )
 I11IiI1I11i1i = re . compile ( '<div class="movie">.+?<img src="(.+?)" alt=".+?" />.+?<a href="(.+?)"><span class="player"></span></a>.+?<h2>(.+?)</h2>' , re . DOTALL ) . findall ( o0O0O00 )
 OOoo = re . compile ( "<link rel='prev' href='(.+?)'/>" ) . findall ( o0O0O00 )
 next = re . compile ( "<link rel='next' href='(.+?)'/>" ) . findall ( o0O0O00 )
 for ooOOOoO , url , oooo000 in I11IiI1I11i1i :
  iiI111I1iIiI ( ( oooo000 ) . replace ( '&#038;' , '' ) . replace ( '&#8216;' , '' ) . replace ( '&#8217;' , '' ) . replace ( '&#8211;' , '' ) , url , 83 , ooOOOoO )
 OOoo = OOoo
 for url in OOoo :
  iiI111I1iIiI ( 'Prev' , url , 82 , '' )
 next = next
 for url in next :
  iiI111I1iIiI ( 'Next' , url , 82 , '' )
  if 50 - 50: OoO0O00
def ii ( url ) :
 o0O0O00 = o000o ( url )
 I11IiI1I11i1i = re . compile ( '<li>.+?<a href="(.+?)" target="_blank">.+?<span class="datex">(.+?)</span>.+?</b>(.+?)</span>.+?</li>' , re . DOTALL ) . findall ( o0O0O00 )
 for url , Iiii1iI1i , oooo000 in I11IiI1I11i1i :
  OoOO0oo0o ( ( 'Season' ) + Iiii1iI1i + ( '  ' ) + oooo000 , url , 100 , OooO0 + 'icon.png' )
  if 34 - 34: ooOoO0o * I1IiiI . i1IIi * ooOoO0o / ooOoO0o
def IIiI1Ii ( ) :
 o0O0O00 = o000o ( 'http://cnfstudio.com/' )
 I11IiI1I11i1i = re . compile ( '<a href="http://cnfstudio.com/genre/(.+?)">(.+?)</a>' ) . findall ( o0O0O00 )
 for iI1ii1Ii , oooo000 in I11IiI1I11i1i :
  iiI111I1iIiI ( oooo000 , 'http://cnfstudio.com/genre/' + iI1ii1Ii , 78 , OooO0 + 'icon.png' )
  if 57 - 57: OOooOOo - ooOoO0o - I11i + OoO0O00
I1IIIiI11i1 = xbmcgui . Dialog ( )
if 48 - 48: I1Ii111 - o0oOOo0O0Ooo % Ii1I
def IIi1IIIi ( url ) :
 if 99 - 99: Ii1I + OoO0O00 * II111iiii . o0oOOo0O0Ooo - I1ii11iIi11i
 o0OOOo = 1
 ii1iiIiIII1ii = 0
 oO0o0oooO0oO = o000o ( url )
 IiIiII1 = re . compile ( '<iframe width=".*?" height=".*?" frameborder=".*?" src="(.*?)" scrolling=".*?" marginwidth=".*?" marginheight=".*?" vspace=".*?" hspace=".*?" allowfullscreen=".*?" webkitallowfullscreen=".*?" mozallowfullscreen=".*?"></iframe>' , re . DOTALL ) . findall ( oO0o0oooO0oO )
 for url in IiIiII1 :
  if 21 - 21: O0 % IiII . I1IiiI / II111iiii + IiII
  try :
   OOOO0O00o = Google . resolve ( url )
  except :
   pass
   if 62 - 62: iIii1I11I1II1
  i1II = re . findall ( r"{'url': u'(.*?)', 'quality': 'HD'}, {'url': u'(.*?)', 'quality': 'SD'}" , str ( OOOO0O00o ) )
  for iI1I , OooOoOo in i1II :
   if 14 - 14: o0oOOo0O0Ooo * OOooOOo + iII111i + O0 + i11iIiiIii
   Ooo . append ( iI1I )
   O0o0Oo . append ( OooOoOo )
   if 77 - 77: o0oOOo0O0Ooo / OoooooooOO
   if 46 - 46: o0oOOo0O0Ooo % iIii1I11I1II1 . iII111i % iII111i + i11iIiiIii
  OoOO0oo0o ( 'HD LINKS' , '' , '' , '' )
  for iI11Ii in Ooo :
   OoOO0oo0o ( 'Part ' + o0OOOo , Ooo [ ii1iiIiIII1ii ] , 100 , '' )
   o0OOOo = o0OOOo + 1
   ii1iiIiIII1ii = ii1iiIiIII1ii + 1
   if 72 - 72: iIii1I11I1II1 * Ii1I % ooOoO0o / OoO0O00
  o0OOOo = 0
  ii1iiIiIII1ii = 0
  OoOO0oo0o ( 'SD LINKS' , '' , '' , '' )
  for iI11Ii in O0o0Oo :
   OoOO0oo0o ( 'Part ' + o0OOOo , O0o0Oo [ ii1iiIiIII1ii ] , 100 , '' )
   o0OOOo = o0OOOo + 1
   ii1iiIiIII1ii = ii1iiIiIII1ii + 1
   if 35 - 35: ooOoO0o + i1IIi % I1ii11iIi11i % I11i + oO0o
  o0OOOo = 0
  ii1iiIiIII1ii = 0
  if 17 - 17: i1IIi
  if 21 - 21: Oo0Ooo
def I1ii1 ( url ) :
 o0O0O00 = o000o ( url )
 I11IiI1I11i1i = re . compile ( '<div class="movie">.+?<img src="(.+?)" alt=".+?" />.+?<a href="(.+?)"><span class="player"></span></a>.+?<h2>(.+?)</h2>' , re . DOTALL ) . findall ( o0O0O00 )
 OOoo = re . compile ( "<link rel='next' href='(.+?)'/>" ) . findall ( o0O0O00 )
 for ooOOOoO , url , oooo000 in I11IiI1I11i1i :
  OoOO0oo0o ( ( oooo000 ) . replace ( '&#038;' , '' ) . replace ( '&#8216;' , '' ) . replace ( '&#8217;' , '' ) . replace ( '&#8211;' , '' ) , url , 169 , ooOOOoO )
 OOoo = OOoo
 for url in OOoo :
  iiI111I1iIiI ( 'Next Page' , url , 79 , '' )
  if 99 - 99: ooOoO0o . I1Ii111 % IiII * IiII . i1IIi
  if 72 - 72: OOooOOo % I1ii11iIi11i + OoO0O00 / oO0o + IiII
  if 10 - 10: I1Ii111 / ooOoO0o + i11iIiiIii / Ii1I
  if 74 - 74: OOooOOo + O0 + i1IIi - i1IIi + II111iiii
def oOOO0oo0 ( url ) :
 if 46 - 46: IiII
 o0O0O00 = o000o ( url )
 I11IiI1I11i1i = re . compile ( '<div id="play-1" class="player-content"><iframe class="playerframe" src="(.+?)" scrolling="no".+?</div>' , re . DOTALL ) . findall ( o0O0O00 )
 for url in I11IiI1I11i1i :
  iI11Ii = url + '&fv=&sou='
  iI11Ii = iI11Ii . replace ( 'player' , 'watch' )
  ii1iIi1iIiI1i = iiI1iIii1i ( iI11Ii )
  OOooO0oo0o00o = iiI1iIii1i ( url )
  if 100 - 100: o0oOOo0O0Ooo
  if 1 - 1: I11i + OoooooooOO - OOooOOo + IiII
def iiI1iIii1i ( url ) :
 if 9 - 9: Ii1I
 o0O0O00 = o000o ( url )
 I11IiI1I11i1i = re . compile ( '<video id=".+?<source src="(.+?)" type="video/mp4">' , re . DOTALL ) . findall ( o0O0O00 )
 for url in I11IiI1I11i1i :
  oooooOOO000Oo ( url )
  if 52 - 52: II111iiii % IiII . OoOoOO00 * iIii1I11I1II1
  if 50 - 50: ooOoO0o - I1Ii111 * IiII . I1ii11iIi11i
def I11iiiii1II ( type , name , url , mode , iconimage = '' , fanart = '' , video = '' , description = '' ) :
 if type != 'folder2' and type != 'addon' :
  if len ( iconimage ) > 0 :
   iconimage = OooO0 + iconimage
  else :
   iconimage = 'DefaultFolder.png'
 if type == 'addon' :
  if len ( iconimage ) > 0 :
   iconimage = iconimage
  else :
   iconimage = 'http://totalxbmc.tv/addons/cache/images/4c79319887e240789ca125f144d989_addon-dummy.png'
 if fanart == '' :
  fanart = II11iiii1Ii
 oO00OOoO00 = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&fanart=" + urllib . quote_plus ( fanart ) + "&video=" + urllib . quote_plus ( video ) + "&description=" + urllib . quote_plus ( description )
 IiI111111IIII = True
 i1Ii = xbmcgui . ListItem ( name , iconImage = "DefaultFolder.png" , thumbnailImage = iconimage )
 i1Ii . setInfo ( type = "Video" , infoLabels = { "Title" : name , "Plot" : description } )
 i1Ii . setProperty ( "Fanart_Image" , fanart )
 i1Ii . setProperty ( "Build.Video" , video )
 if ( type == 'folder' ) or ( type == 'folder2' ) or ( type == 'tutorial_folder' ) or ( type == 'news_folder' ) :
  IiI111111IIII = ooOOooOo0O ( handle = int ( sys . argv [ 1 ] ) , url = oO00OOoO00 , listitem = i1Ii , isFolder = True )
 else :
  IiI111111IIII = ooOOooOo0O ( handle = int ( sys . argv [ 1 ] ) , url = oO00OOoO00 , listitem = i1Ii , isFolder = False )
 return IiI111111IIII
 if 40 - 40: OOooOOo * OOooOOo . iII111i % O0
def ooOOooOo0O ( handle , url , listitem , isFolder ) :
 if 9 - 9: oO0o + I11i / I11i
 xbmcplugin . addDirectoryItem ( handle , url , listitem , isFolder )
 if 12 - 12: OoooooooOO % o0oOOo0O0Ooo * I11i % iIii1I11I1II1 / Ii1I
 if 27 - 27: i11iIiiIii % II111iiii % I11i . O0 - Oo0Ooo + OoOoOO00
def ooO0o ( name , url , img ) :
 ii1I1 = o000o ( url )
 ooOOo00O00Oo = re . compile ( '<iframe class="playerframe" src="(.+?)" scrolling=".+?" marginwidth=".+?" marginheight=".+?" vspace=".+?" hspace=".+?" allowfullscreen=".+?" webkitallowfullscreen=".+?" mozallowfullscreen=".+?" width=".+?" height=".+?" frameborder=".+?"></iframe>' , re . DOTALL ) . findall ( ii1I1 )
 IiII1 = len ( ooOOo00O00Oo )
 if 18 - 18: ooOoO0o * OoOoOO00 . iII111i / I1ii11iIi11i / i11iIiiIii
 if 21 - 21: oO0o / I1ii11iIi11i + Ii1I + OoooooooOO
 if IiII1 == 1 :
  for OoOo in ooOOo00O00Oo :
   OoOo = OoOo . replace ( 'player' , 'watch' )
   I1iI11iIiIi1 = OoOo + '&fv=&sou='
   o0O0O0ooo0oOO = o000o ( I1iI11iIiIi1 )
   oo000 = re . compile ( '<source src="(.+?)" type=".+?">' , re . DOTALL ) . findall ( o0O0O0ooo0oOO )
   for iiOoO in oo000 :
    Iiiiii111i1ii = False
    oooooOOO000Oo ( iiOoO )
    if 25 - 25: OOooOOo - ooOoO0o / i11iIiiIii
 elif IiII1 > 1 :
  if 41 - 41: i1IIi % iII111i + iIii1I11I1II1
  for OoOo in ooOOo00O00Oo :
   oO0o0oooO0oO = o000o ( OoOo )
   IiIiII1 = re . compile ( '<iframe width=".*?" height=".*?" frameborder=".*?" src="(.*?)" scrolling=".*?" marginwidth=".*?" marginheight=".*?" vspace=".*?" hspace=".*?" allowfullscreen=".*?" webkitallowfullscreen=".*?" mozallowfullscreen=".*?"></iframe>' , re . DOTALL ) . findall ( oO0o0oooO0oO )
   Ii1IIIIi1ii1I = IiIiII1
   Ii1IIIIi1ii1I = ( str ( Ii1IIIIi1ii1I ) ) . replace ( '[\'' , '' ) . replace ( '\']' , '' ) ;
   print 'Stripped url : ' + Ii1IIIIi1ii1I
   OoOO0oo0o ( 'DOUBLE LINK' , Ii1IIIIi1ii1I , 424 , '' )
   if 13 - 13: I1IiiI % OoOoOO00 . I1ii11iIi11i / Oo0Ooo % OOooOOo . OoooooooOO
   for url in IiIiII1 :
    iiI111I1iIiI ( 'DOUBLE LINK' , url , 424 , '' )
    try :
     OOOO0O00o = Google . resolve ( url )
    except :
     pass
    try :
     i1II = re . findall ( r"{'url': u'(.*?)', 'quality': 'HD'}, {'url': u'(.*?)', 'quality': 'SD'}" , str ( OOOO0O00o ) )
     for iI1I , OooOoOo in i1II :
      if 22 - 22: IiII / i11iIiiIii
      Ooo . append ( iI1I )
      O0o0Oo . append ( OooOoOo )
    except :
     pass
 else :
  pass
  if 62 - 62: OoO0O00 / I1ii11iIi11i
  if 7 - 7: OoooooooOO . IiII
def o000o ( url ) :
 if 53 - 53: Ii1I % Ii1I * o0oOOo0O0Ooo + OoOoOO00
 if 92 - 92: OoooooooOO + i1IIi / Ii1I * O0
 if 100 - 100: ooOoO0o % iIii1I11I1II1 * II111iiii - iII111i
 if 92 - 92: ooOoO0o
 if 22 - 22: Oo0Ooo % iII111i * I1ii11iIi11i / OOooOOo % i11iIiiIii * I11i
 if 95 - 95: OoooooooOO - IiII * I1IiiI + OoOoOO00
 if 10 - 10: o0oOOo0O0Ooo / i11iIiiIii
 if 92 - 92: I11i . I1Ii111
 if 85 - 85: I1ii11iIi11i . I1Ii111
 if 78 - 78: ooOoO0o * I1Ii111 + iIii1I11I1II1 + iIii1I11I1II1 / I1Ii111 . Ii1I
 if 97 - 97: ooOoO0o / I1Ii111 % i1IIi % I1ii11iIi11i
 ii111I11iI = urllib2 . Request ( url )
 IiIIIiI1I1 = 'Mozilla/5.0 (Windows NT 6.1; WOW64; Trident/7.0; AS; rv:11.0) like Gecko'
 OoO000 = 'Mozilla/5.0 (Windows NT 6.3; rv:36.0) Gecko/20100101 Firefox/36.0'
 IIiiIiI1 = 'Mozilla/5.0 (iPhone; CPU iPhone OS 6_0 like Mac OS X) AppleWebKit/536.26 (KHTML, like Gecko) Version/6.0 Mobile/10A5376e Safari/8536.25'
 iiIiIIi = 'Mozilla/5.0 (Linux; Android 4.4.2; Nexus 4 Build/KOT49H) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/34.0.1847.114 Mobile Safari/537.36'
 ii111I11iI . add_header ( 'User-Agent' , 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3' )
 OO0ooo0o0O0Oooooo = urllib2 . urlopen ( ii111I11iI )
 iI11Ii = OO0ooo0o0O0Oooooo . read ( )
 OO0ooo0o0O0Oooooo . close ( )
 return iI11Ii
 if 1 - 1: ooOoO0o % OoOoOO00 * Oo0Ooo
def o0O0oo0 ( url ) :
 xbmcplugin . addSortMethod ( handle = int ( sys . argv [ 1 ] ) , sortMethod = xbmcplugin . SORT_METHOD_TITLE )
 I1 = ( '%s%s' % ( OOoO00o , url ) )
 iI11Ii = o000o ( url )
 I11IiI1I11i1i = re . compile ( '<a.href="(.+?)".target="_blank"><img.src="(.+?)".style="max-width:200px;"./></a><br><b>(.+?)</b>' ) . findall ( iI11Ii )
 for url , i1iIIIi1i , oooo000 in I11IiI1I11i1i :
  iiiI1I1iIIIi1 ( '%s' % ( oooo000 ) . replace ( 'Origin Entertainment' , 'Origin Entertainment' ) . replace ( '.' , ' ' ) . replace ( 'mp4' , '' ) . replace ( 'mkv' , '' ) . replace ( '_' , ' ' ) , '%s' % ( url ) , 401 , '%s' % ( i1iIIIi1i ) )
  if 17 - 17: iIii1I11I1II1 . OoooooooOO / I11i % II111iiii % i1IIi / i11iIiiIii
 xbmcplugin . addSortMethod ( Oo , xbmcplugin . SORT_METHOD_TITLE ) ;
 if 58 - 58: Oo0Ooo . II111iiii + oO0o - i11iIiiIii / II111iiii / O0
 if 85 - 85: OoOoOO00 + OOooOOo
def I1II ( url ) :
 xbmcplugin . addSortMethod ( handle = int ( sys . argv [ 1 ] ) , sortMethod = xbmcplugin . SORT_METHOD_TITLE )
 I1 = ( '%s%s' % ( OOoO00o , url ) )
 iI11Ii = o000o ( url )
 I11IiI1I11i1i = re . compile ( '<a.href="(.+?)".target="_blank"><img.src="(.+?)".style="max-width:200px;"./></a><br><b>(.+?)</b>' ) . findall ( iI11Ii )
 for url , i1iIIIi1i , oooo000 in I11IiI1I11i1i :
  iii1 ( oooo000 , url , 402 , i1iIIIi1i )
  if 67 - 67: I1IiiI
 xbmcplugin . addSortMethod ( Oo , xbmcplugin . SORT_METHOD_TITLE ) ;
 if 55 - 55: I1ii11iIi11i - iII111i * o0oOOo0O0Ooo + OoOoOO00 * OoOoOO00 * O0
 if 91 - 91: I1Ii111 - OOooOOo % iIii1I11I1II1 - OoooooooOO % ooOoO0o
def OO0 ( url ) :
 if 44 - 44: iII111i - I1Ii111 / O0 * Oo0Ooo + II111iiii / OoOoOO00
 xbmcplugin . addSortMethod ( handle = int ( sys . argv [ 1 ] ) , sortMethod = xbmcplugin . SORT_METHOD_TITLE )
 OOOOoO000 = ( '%s%s' % ( OOoO00o , url ) )
 iI11Ii = o000o ( url )
 I11IiI1I11i1i = re . compile ( "addDir('','','','','','')" ) . findall ( iI11Ii )
 if 57 - 57: II111iiii
 if 54 - 54: Oo0Ooo + oO0o + i11iIiiIii
 if 28 - 28: oO0o
def oooooOOO000Oo ( url ) :
 ooo000o0ooO0 = xbmc . Player ( I1I ( ) )
 import urlresolver
 try : ooo000o0ooO0 . play ( url )
 except : pass
 from urlresolver import common
 oOoo000 = xbmcgui . DialogProgress ( )
 oOoo000 . create ( 'LOADING' , 'Opening %s Now' % ( oooo000 ) )
 ooo000o0ooO0 = xbmc . Player ( I1I ( ) )
 url = urlresolver . HostedMediaFile ( url ) . resolve ( )
 if oOoo000 . iscanceled ( ) :
  print "[COLORred]STREAM CANCELLED[/COLOR]"
  I1IIIiI11i1 = xbmcgui . Dialog ( )
  if I1IIIiI11i1 . yesno ( "[B]CANCELLED[/B]" , '[B]Was There A Problem[/B]' , '' , "" , 'Yes' , 'No' ) :
   I1IIIiI11i1 . ok ( "Message Send" , "Your Message Has Been Sent" )
  else :
   return
 else :
  try : ooo000o0ooO0 . play ( url )
  except : pass
  try : O0O . resolve_url ( url )
  except : pass
  oOoo000 . close ( )
  if 87 - 87: OoooooooOO - o0oOOo0O0Ooo / IiII . i11iIiiIii * OoooooooOO
def OO00 ( url ) :
 ooo000o0ooO0 = xbmc . Player ( I1I ( ) )
 import urlresolver
 try : ooo000o0ooO0 . play ( url )
 except : pass
 if 28 - 28: oO0o - i11iIiiIii . I1ii11iIi11i + IiII / I1ii11iIi11i
 if 35 - 35: IiII
def OOoO0 ( ) :
 OoOo00o0OO = ''
 ii1IIIIiI11 = xbmc . Keyboard ( OoOo00o0OO , 'Search' )
 ii1IIIIiI11 . doModal ( )
 if ( ii1IIIIiI11 . isConfirmed ( ) == False ) :
  return
 OoOo00o0OO = ii1IIIIiI11 . getText ( )
 if len ( OoOo00o0OO ) == 0 :
  return
 else :
  return OoOo00o0OO
  if 40 - 40: o0oOOo0O0Ooo
def OOOooo ( name , url , iconimage = None ) :
 print '--- Playing "{0}". {1}' . format ( name , url )
 Oo00oo0000OO = xbmcgui . ListItem ( path = url , thumbnailImage = iconimage )
 Oo00oo0000OO . setInfo ( type = "Video" , infoLabels = { "Title" : name } )
 xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , Oo00oo0000OO )
 if 69 - 69: ooOoO0o - OoO0O00 / i11iIiiIii + I1ii11iIi11i % OoooooooOO
def I1I ( ) :
 try :
  o000O000 = getSet ( "core-player" )
  if ( o000O000 == 'DVDPLAYER' ) : ii1 = xbmc . PLAYER_CORE_DVDPLAYER
  elif ( o000O000 == 'MPLAYER' ) : ii1 = xbmc . PLAYER_CORE_MPLAYER
  elif ( o000O000 == 'PAPLAYER' ) : ii1 = xbmc . PLAYER_CORE_PAPLAYER
  else : ii1 = xbmc . PLAYER_CORE_AUTO
 except : ii1 = xbmc . PLAYER_CORE_AUTO
 return ii1
 return True
 if 77 - 77: I1IiiI % O0
def O0oo0OO0oOOOo ( name , url , mode , iconimage ) :
 oO00OOoO00 = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name )
 IiI111111IIII = True
 i1Ii = xbmcgui . ListItem ( name , iconImage = "DefaultFolder.png" , thumbnailImage = iconimage )
 i1Ii . setInfo ( type = "Video" , infoLabels = { "Title" : name } )
 IiI111111IIII = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = oO00OOoO00 , listitem = i1Ii , isFolder = True )
 return IiI111111IIII
def iii1 ( name , url , mode , iconimage ) :
 oO00OOoO00 = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name )
 IiI111111IIII = True
 i1Ii = xbmcgui . ListItem ( name , iconImage = "DefaultFolder.png" , thumbnailImage = iconimage )
 i1Ii . setInfo ( type = "Video" , infoLabels = { "Title" : name } )
 IiI111111IIII = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = oO00OOoO00 , listitem = i1Ii , isFolder = True )
 return IiI111111IIII
def iiiI1I1iIIIi1 ( name , url , mode , iconimage ) :
 oO00OOoO00 = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name )
 IiI111111IIII = True
 i1Ii = xbmcgui . ListItem ( name , iconImage = "DefaultFolder.png" , thumbnailImage = iconimage )
 i1Ii . setInfo ( type = "Video" , infoLabels = { "Title" : name } )
 IiI111111IIII = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = oO00OOoO00 , listitem = i1Ii , isFolder = False )
 return IiI111111IIII
 if 36 - 36: Ii1I / II111iiii / IiII / IiII + I1ii11iIi11i
 if 95 - 95: IiII
def Ooo0oo ( name , url ) :
 ii111I11iI = o000o ( url )
 IIi11IIiIii1 = BeautifulSoup ( ii111I11iI )
 I1iIII1 = open ( I11II1i , 'w' )
 iIii = name
 if 84 - 84: oO0o % i1IIi
 oOO = IIi11IIiIii1 . find_all ( 'div' , { 'class' : 'body' } )
 for Ii1II in oOO :
  O0Oo00 = Ii1II . find_all ( 'p' )
  for ii1IiIIi1i in O0Oo00 :
   ii1IiIIi1i = ii1IiIIi1i . text
   ii1IiIIi1i = ii1IiIIi1i . encode ( 'utf-8' )
   if 54 - 54: ooOoO0o
   O0iIi1IiII = open ( I11II1i , 'a' )
   O0iIi1IiII . write ( ii1IiIIi1i )
   O0iIi1IiII . write ( '\n' )
   if 27 - 27: iII111i . I11i . iIii1I11I1II1 . iIii1I11I1II1
  iIi1i = open ( I11II1i , 'r' )
  i1ii = iIi1i . read ( )
  O0ooO0ooo0oO ( iIii , i1ii )
  O0iIi1IiII . close ( )
  if 10 - 10: II111iiii . iII111i
def O0ooO0ooo0oO ( heading , announce ) :
 class I1iOOOO ( ) :
  WINDOW = 10147
  CONTROL_LABEL = 1
  CONTROL_TEXTBOX = 5
  isFolder = True
  def __init__ ( self , * args , ** kwargs ) :
   xbmc . executebuiltin ( "ActivateWindow(%d)" % ( self . WINDOW , ) )
   self . win = xbmcgui . Window ( self . WINDOW )
   xbmc . sleep ( 500 )
   self . setControls ( )
  def setControls ( self ) :
   self . win . getControl ( self . CONTROL_LABEL ) . setLabel ( heading )
   try : ooO0oO00O0o = open ( announce ) ; ooOO00oOOo000 = ooO0oO00O0o . read ( )
   except : ooOO00oOOo000 = announce
   self . win . getControl ( self . CONTROL_TEXTBOX ) . setText ( str ( ooOO00oOOo000 ) )
   return
 I1iOOOO ( )
 if 14 - 14: OoO0O00 . II111iiii . I11i / Ii1I % I1ii11iIi11i - ooOoO0o
 if 67 - 67: I11i - OOooOOo . i1IIi
def I1I1iI ( ) :
 ii111I11iI = urllib2 . Request ( o0 )
 ii111I11iI . add_header ( 'User-Agent' , USER_AGENT )
 OO0ooo0o0O0Oooooo = urllib2 . urlopen ( ii111I11iI )
 I1iIi1iiIIiI = OO0ooo0o0O0Oooooo . read ( )
 OO0ooo0o0O0Oooooo . close ( )
 oOoOOoOOooOO = re . search ( r'npoplayer.token = "(.*?)"' , I1iIi1iiIIiI ) . group ( 1 )
 if 31 - 31: OOooOOo / Oo0Ooo * i1IIi . OoOoOO00
 if 57 - 57: OOooOOo + iIii1I11I1II1 % i1IIi % I1IiiI
 OO0oo = - 1
 IiIi1II11i = - 1
 for II1II1iIIi11 in range ( 5 , len ( oOoOOoOOooOO ) - 5 , 1 ) :
  if 49 - 49: OoooooooOO * I11i - Oo0Ooo . oO0o
  if oOoOOoOOooOO [ II1II1iIIi11 ] . isdigit ( ) :
   if OO0oo < 0 :
    OO0oo = II1II1iIIi11
    if 89 - 89: ooOoO0o + Ii1I * ooOoO0o / ooOoO0o
   elif IiIi1II11i < 0 :
    IiIi1II11i = II1II1iIIi11
    if 46 - 46: OoO0O00
    break
    if 71 - 71: I11i / I11i * oO0o * oO0o / II111iiii
 II1I1iiIII1I1 = list ( oOoOOoOOooOO )
 if OO0oo < 0 or IiIi1II11i < 0 :
  OO0oo = 12
  IiIi1II11i = 13
 II1I1iiIII1I1 [ OO0oo ] = oOoOOoOOooOO [ IiIi1II11i ]
 II1I1iiIII1I1 [ IiIi1II11i ] = oOoOOoOOooOO [ OO0oo ]
 II1I1iiIII1I1 = '' . join ( II1I1iiIII1I1 )
 if 85 - 85: iII111i * o0oOOo0O0Ooo
 return II1I1iiIII1I1
 if 3 - 3: OOooOOo
 if 20 - 20: II111iiii . iII111i / II111iiii % i11iIiiIii % iII111i
def I11Ii11iI1 ( ) :
 IiIiiI11111I1 = [ ]
 O0oo0ooOOOO = sys . argv [ 2 ]
 if len ( O0oo0ooOOOO ) >= 2 :
  Ii1ii = sys . argv [ 2 ]
  iIIIII1iiiiII = Ii1ii . replace ( '?' , '' )
  if ( Ii1ii [ len ( Ii1ii ) - 1 ] == '/' ) :
   Ii1ii = Ii1ii [ 0 : len ( Ii1ii ) - 2 ]
  oooO = iIIIII1iiiiII . split ( '&' )
  IiIiiI11111I1 = { }
  for II1II1iIIi11 in range ( len ( oooO ) ) :
   I111i1I1 = { }
   I111i1I1 = oooO [ II1II1iIIi11 ] . split ( '=' )
   if ( len ( I111i1I1 ) ) == 2 :
    IiIiiI11111I1 [ I111i1I1 [ 0 ] ] = I111i1I1 [ 1 ]
    if 62 - 62: OOooOOo * I1Ii111 / Oo0Ooo * o0oOOo0O0Ooo
 return IiIiiI11111I1
 if 29 - 29: Oo0Ooo % OoO0O00 % IiII . o0oOOo0O0Ooo / OoooooooOO * ooOoO0o
Ii1ii = I11Ii11iI1 ( )
iI1ii1Ii = None
oooo000 = None
i1iIIIi1i = None
o00 = None
o0OoO000O = None
if 94 - 94: OoOoOO00 . O0 / Ii1I . I1ii11iIi11i - i1IIi
if 26 - 26: OoO0O00 - OOooOOo . o0oOOo0O0Ooo
try :
 iI1ii1Ii = urllib . unquote_plus ( Ii1ii [ "url" ] )
except :
 pass
try :
 oooo000 = urllib . unquote_plus ( Ii1ii [ "name" ] )
except :
 pass
try :
 i1iIIIi1i = urllib . unquote_plus ( Ii1ii [ "iconimage" ] )
except :
 pass
try :
 o00 = int ( Ii1ii [ "mode" ] )
except :
 pass
try :
 o0o = urllib . unquote_plus ( Ii1ii [ "fanart" ] )
except :
 pass
try :
 o0OoO000O = urllib . unquote_plus ( Ii1ii [ "description" ] )
except :
 pass
 if 65 - 65: I1ii11iIi11i % O0 % iIii1I11I1II1 * Ii1I
 if 31 - 31: Ii1I
print str ( OooO0OO ) + ': ' + str ( iiiIi )
print "Mode: " + str ( o00 )
print "URL: " + str ( iI1ii1Ii )
print "Name: " + str ( oooo000 )
print "IconImage: " + str ( i1iIIIi1i )
if 44 - 44: OoOoOO00 - iIii1I11I1II1 - Oo0Ooo
def Oo0000O0OOooO ( url ) :
 try :
  url = url . replace ( '/embed-' , '/' )
  url = re . compile ( '//.+?/([\w]+)' ) . findall ( url ) [ 0 ]
  I1iIi1iiIIiI = 'http://allmyvideos.net/%s' % url
  if 54 - 54: I11i / I1IiiI * oO0o + OoooooooOO - iII111i / OoooooooOO
  I111IIiii1Ii = client . request ( I1iIi1iiIIiI , close = False )
  if 13 - 13: oO0o . I1IiiI * oO0o + I1IiiI
  OoOooo = { }
  ooO0oO00O0o = client . parseDOM ( I111IIiii1Ii , 'form' , attrs = { 'action' : '' } )
  oo00OOoOoO00 = client . parseDOM ( ooO0oO00O0o , 'input' , ret = 'name' , attrs = { 'type' : 'hidden' } )
  for II1II1iIIi11 in oo00OOoOoO00 : OoOooo . update ( { II1II1iIIi11 : client . parseDOM ( ooO0oO00O0o , 'input' , ret = 'value' , attrs = { 'name' : II1II1iIIi11 } ) [ 0 ] } )
  OoOooo = urllib . urlencode ( OoOooo )
  if 15 - 15: IiII / O0 . o0oOOo0O0Ooo . i11iIiiIii
  I111IIiii1Ii = client . request ( I1iIi1iiIIiI , post = OoOooo )
  if 59 - 59: I1Ii111 - o0oOOo0O0Ooo - ooOoO0o
  url = re . compile ( '"file" *: *"(http.+?)"' ) . findall ( I111IIiii1Ii ) [ - 1 ]
  url += '&direct=false&ua=false'
  return url
 except :
  return
  if 48 - 48: i1IIi + I11i % OoOoOO00 / Oo0Ooo - o0oOOo0O0Ooo
def OOoOOo0O00O ( ) :
 iiI111I1iIiI ( 'Top 20 Most Viewed' , 'http://cnfstudio.com' , 173 , OooO0 + 'Movies.png' )
 iiI111I1iIiI ( 'Box Office' , 'http://cnfstudio.com/category/box-office/' , 89 , OooO0 + 'Movies.png' )
 iiI111I1iIiI ( 'Genres' , 'http://cnfstudio.com/movies/' , 164 , OooO0 + 'Movies.png' )
 iiI111I1iIiI ( 'By Year' , 'http://cnfstudio.com' , 174 , OooO0 + 'Movies.png' )
 iiI111I1iIiI ( 'Search Movies' , '' , 171 , OooO0 + 'Movies.png' )
 xbmcplugin . endOfDirectory ( int ( sys . argv [ 1 ] ) )
 if 36 - 36: O0 + Oo0Ooo
 if 5 - 5: Oo0Ooo * OoOoOO00
 if 46 - 46: ooOoO0o
 if 33 - 33: iII111i - II111iiii * OoooooooOO - Oo0Ooo - OOooOOo
if o00 == None : Iii111II ( )
elif o00 == 9 : yt . PlayVideo ( iI1ii1Ii )
elif o00 == 10 : Films . Films ( )
elif o00 == 11 : TV . TV_Shows ( )
elif o00 == 12 : Standup . Stand_Up ( )
elif o00 == 13 : OOoO0 ( )
elif o00 == 14 : TV . Animated_TV ( )
elif o00 == 15 : TV . Action_TV ( )
elif o00 == 16 : TV . Childrens_TV ( )
elif o00 == 17 : TV . Comedy_TV ( )
elif o00 == 18 : TV . Drama_TV ( )
elif o00 == 19 : TV . Entertainment_TV ( )
elif o00 == 20 : TV . Fantasy_TV ( )
elif o00 == 21 : TV . Music_TV ( )
elif o00 == 22 : TV . Scifi_TV ( )
elif o00 == 23 : SoapsCatchup . Soap_TV ( )
elif o00 == 24 : Standup . Jeff_Dunham ( )
elif o00 == 25 : TV . DrWho ( )
elif o00 == 26 : TV . Arrow ( )
elif o00 == 27 : TV . Flash ( )
elif o00 == 28 : utube . Mock_the_week ( )
elif o00 == 29 : utube . Inbetweeners ( )
elif o00 == 30 : utube . WouldILieToYou ( )
elif o00 == 31 : TV . Flash_Series2 ( )
elif o00 == 32 : TV . The_Last_Man_On_Earth ( )
elif o00 == 33 : TV . Fargo ( )
elif o00 == 34 : TV . The_Knick ( )
elif o00 == 35 : TV . Gotham ( )
elif o00 == 36 : TV . Sons_Of_Anarchy ( )
elif o00 == 37 : TV . Homelands ( )
elif o00 == 38 : TV . Daredevil ( )
elif o00 == 39 : TV . New_girl ( )
elif o00 == 40 : TV . Dexter ( )
elif o00 == 41 : TV . Live_TV ( )
elif o00 == 42 : TV . Breaking_bad ( )
elif o00 == 43 : TV . Grimm ( )
elif o00 == 44 : TV . Brooklyn_Nine_Nine ( )
elif o00 == 45 : TV . Game_of_thrones ( )
elif o00 == 46 : TV . Bates_motel ( )
elif o00 == 47 : TV . Black_list ( )
elif o00 == 48 : TV . Legends ( )
elif o00 == 49 : TV . Suits ( )
elif o00 == 50 : TV . Once_upon_a_time ( )
elif o00 == 51 : TV . How_I_Met_Your_Mother ( )
elif o00 == 52 : oOo0oO ( )
elif o00 == 53 : lists . Lists ( )
elif o00 == 54 : O0Oi1I1I ( )
elif o00 == 55 : oO ( )
elif o00 == 56 : Iii1iI ( )
elif o00 == 57 : ooOO00O00oo ( )
elif o00 == 58 : IiI1I1i1I1 ( )
elif o00 == 59 : OOoOO0o0o0 ( iI1ii1Ii )
elif o00 == 60 : FootballFixturesChannel ( )
elif o00 == 61 : Sponge_TV ( )
elif o00 == 62 : Oo0OoO00oOO0o ( iI1ii1Ii )
elif o00 == 63 : OO00Oo ( )
elif o00 == 64 : Ii11Ii1I ( )
elif o00 == 65 : II1iIi11 ( iI1ii1Ii )
elif o00 == 66 : TV . WorldNews ( )
elif o00 == 67 : TV . WorldPlayUrl ( iI1ii1Ii )
elif o00 == 68 : TV . WorldPlayVid ( iI1ii1Ii )
elif o00 == 69 : I1i ( )
elif o00 == 70 : ooO0oooOO0 ( )
elif o00 == 71 : oOooO ( )
elif o00 == 72 : OOo0o0O0O ( )
elif o00 == 73 : ooOoOo0 ( iI1ii1Ii )
elif o00 == 74 : Ooo0oo ( oooo000 , iI1ii1Ii )
elif o00 == 75 : premierleague . Premier_League_Table ( )
elif o00 == 76 : o0OoOo00o0o ( )
elif o00 == 77 : OOoOOo0O00O ( )
elif o00 == 78 : I1ii1 ( iI1ii1Ii )
elif o00 == 79 : oOOO0oo0 ( iI1ii1Ii )
elif o00 == 80 : iiI1iIii1i ( iI1ii1Ii )
elif o00 == 81 : I1iiiiIii ( )
elif o00 == 82 : ooOo00 ( iI1ii1Ii )
elif o00 == 83 : ii ( iI1ii1Ii )
elif o00 == 84 : cnfTVPlay1 ( iI1ii1Ii )
elif o00 == 85 : cnfTVPlay2 ( iI1ii1Ii )
elif o00 == 86 : TV . List_LiveTVFull ( oooo000 )
elif o00 == 87 : TV . LiveTVFull ( oooo000 )
elif o00 == 88 : TV . LiveTVFullCat ( )
elif o00 == 89 : CNF_Studio_Indexer . Box_Office ( iI1ii1Ii )
elif o00 == 90 : Alluc_Indexer . Search_Alluc ( )
elif o00 == 91 : Alluc_Indexer . Get_Alluc_Page ( iI1ii1Ii , oooo000 )
elif o00 == 92 : Alluc_Indexer . Get_Playlink ( iI1ii1Ii , oooo000 )
elif o00 == 93 : FootballReplays . Replay_Menu ( )
elif o00 == 94 : FootballReplays . get_All_Rows ( iI1ii1Ii )
elif o00 == 95 : SoapsCatchup . Hollyoaks ( )
elif o00 == 96 : SoapsCatchup . Eastenders ( )
elif o00 == 97 : SoapsCatchup . Emmerdale ( )
elif o00 == 98 : SoapsCatchup . CoronationStreet ( )
elif o00 == 99 : I1I1iI ( )
elif o00 == 100 : ooO0o ( oooo000 , iI1ii1Ii , i1iIIIi1i )
elif o00 == 101 : SoapsCatchup . ImACeleb ( )
elif o00 == 102 : documentary . DOC1 ( )
elif o00 == 103 : documentary . DOC2 ( iI1ii1Ii )
elif o00 == 104 : documentary . DOC3 ( iI1ii1Ii )
elif o00 == 105 : documentary . DOCLIST ( iI1ii1Ii )
elif o00 == 106 : IMDBsearch . Get_imdb_movie_search ( )
elif o00 == 107 : IMDBsearch . Get_movie ( oooo000 , iI1ii1Ii , i1iIIIi1i )
elif o00 == 108 : IMDBsearch . Get_imdb_TV_Episode ( oooo000 , iI1ii1Ii )
elif o00 == 109 : M3Uscrape . Get_m3u_links ( )
elif o00 == 110 : M3Uscrape . Get_m3u_playlinks ( iI1ii1Ii )
elif o00 == 111 : IMDBsearch . find_Alluc_Link ( oooo000 )
elif o00 == 112 : M3Uscrape . next_page ( iI1ii1Ii )
elif o00 == 113 : search_addon . Get_Episode_2 ( iI1ii1Ii )
elif o00 == 164 : IIiI1Ii ( )
elif o00 == 165 : CNF_Studio_Indexer . List_Movies ( iI1ii1Ii )
elif o00 == 166 : CNF_Studio_Indexer . Get_Movie_Page ( iI1ii1Ii )
elif o00 == 167 : LiveTVFull ( oooo000 )
elif o00 == 168 : List_LiveTVFull ( oooo000 )
elif o00 == 169 : CNF_Studio_Indexer . Resolve_CNF_Link ( oooo000 , iI1ii1Ii , i1iIIIi1i )
elif o00 == 170 : List_LiveTVCats ( )
elif o00 == 171 : CNF_Studio_Indexer . Search_Movie ( )
elif o00 == 172 : OOoOOo0O00O ( )
elif o00 == 173 : CNF_Studio_Indexer . MV_Movies ( iI1ii1Ii )
elif o00 == 174 : CNF_Studio_Indexer . Movie_ByYear ( iI1ii1Ii )
elif o00 == 175 : search_addon . Search_Addon_Menu ( )
elif o00 == 176 : search_addon . Search_Pandoras_Films ( )
elif o00 == 177 : search_addon . Search_Pandoras_TV ( )
elif o00 == 178 : search_addon . Search_Films_Lists ( )
elif o00 == 179 : search_addon . Search_LiveTV ( )
elif o00 == 180 : search_addon . Search_TV_Lists ( )
elif o00 == 181 : search_addon . search_test ( )
elif o00 == 182 : search_addon . Get_Episode ( iI1ii1Ii )
elif o00 == 183 : search_addon . Play_link ( iI1ii1Ii )
elif o00 == 184 : TV . Recent_Episodes_Now ( )
elif o00 == 185 : TV . Recent_Scraped ( )
elif o00 == 186 : SEO_INFO . Get_Group ( )
elif o00 == 187 : SEO_INFO . Get_Page ( iI1ii1Ii )
elif o00 == 188 : SEO_INFO . Get_Info ( iI1ii1Ii )
elif o00 == 189 : SEO_INFO . Install_Addon ( iI1ii1Ii , oooo000 )
elif o00 == 190 : SEO_INFO . Get_Download_File ( iI1ii1Ii )
elif o00 == 191 : TV . get_Country ( )
elif o00 == 192 : TV . get_Channel ( iI1ii1Ii )
elif o00 == 193 : TV . get_Part_1_Link ( iI1ii1Ii )
elif o00 == 401 : oooooOOO000Oo ( iI1ii1Ii )
elif o00 == 400 : o0O0oo0 ( iI1ii1Ii )
elif o00 == 402 : streams . ParseURL ( iI1ii1Ii )
elif o00 == 403 : I1II ( iI1ii1Ii )
elif o00 == 404 : OOOooo ( oooo000 , iI1ii1Ii , i1iIIIi1i )
elif o00 == 405 : lists . TESTCATS2 ( )
elif o00 == 406 : iiii1IIi ( )
elif o00 == 407 : O00oOOooo ( iI1ii1Ii )
elif o00 == 408 : i1Iii11Ii1i1 ( iI1ii1Ii )
elif o00 == 409 : o0O0oO0O00O0o ( iI1ii1Ii )
elif o00 == 410 : lists . TestDizi ( )
elif o00 == 411 : Oo0O0oooo ( )
elif o00 == 412 : M3UPLAY ( iI1ii1Ii )
elif o00 == 413 : O0oO ( )
elif o00 == 414 : OOOOo0 ( )
elif o00 == 415 : O0oOOoOooooO ( )
elif o00 == 416 : oOOOoo0O0oO ( )
elif o00 == 417 : Parsem3uURL ( iI1ii1Ii )
elif o00 == 418 : TVParser . GetLinks ( iI1ii1Ii )
elif o00 == 419 : TVParser . m3uCategory ( iI1ii1Ii )
elif o00 == 420 : i11III1111iIi ( iI1ii1Ii )
elif o00 == 421 : iI11 ( iI1ii1Ii )
elif o00 == 422 : I1i11 ( iI1ii1Ii )
elif o00 == 423 : o00oooO0Oo ( iI1ii1Ii )
elif o00 == 424 : IIi1IIIi ( iI1ii1Ii )
elif o00 == 425 : SoapsCatchup . SOAPPLAYER ( oooo000 , iI1ii1Ii )
elif o00 == 426 : I1111IIi ( iI1ii1Ii )
elif o00 == 427 : OooOO000 ( oooo000 , iI1ii1Ii , o00 , i1iIIIi1i , o0o , o0OoO000O )
elif o00 == 428 : streams . ParseURL_search ( iI1ii1Ii )
elif o00 == 501 : OO00 ( iI1ii1Ii )
elif o00 == 1000 : ChangeLog ( )
elif o00 == 1001 : TV . TESTING ( )
elif o00 == 1002 : Xvideos . X_vid_Menu ( )
elif o00 == 1003 : Xvideos . tags ( iI1ii1Ii )
elif o00 == 1004 : Xvideos . Pornstars ( iI1ii1Ii )
elif o00 == 1005 : Xvideos . New_Videos ( iI1ii1Ii )
elif o00 == 1006 : Xvideos . Genres ( iI1ii1Ii )
elif o00 == 1007 : Xvideos . Search_X ( )
elif o00 == 1008 : Xvideos . PlayLink ( iI1ii1Ii )
if 84 - 84: I1Ii111 + Oo0Ooo - OoOoOO00 * OoOoOO00
xbmcplugin . endOfDirectory ( int ( sys . argv [ 1 ] ) )
# dd678faae9ac167bc83abf78e5cb2f3f0688d3a3
