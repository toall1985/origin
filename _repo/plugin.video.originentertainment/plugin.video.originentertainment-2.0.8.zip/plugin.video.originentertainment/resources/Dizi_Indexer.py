import re,urllib,urlparse
from resources import Google, cloudflare

