if 64 - 64: i11iIiiIii
if 65 - 65: O0 / iIii1I11I1II1 % OoooooooOO - i1IIi
if 73 - 73: II111iiii
if 22 - 22: I1IiiI * Oo0Ooo / OoO0O00 . OoOoOO00 . o0oOOo0O0Ooo / I1ii11iIi11i
if 48 - 48: oO0o / OOooOOo / I11i / Ii1I
if 48 - 48: iII111i % IiII + I1Ii111 / ooOoO0o * Ii1I
if 46 - 46: ooOoO0o * I11i - OoooooooOO
if 30 - 30: o0oOOo0O0Ooo - O0 % o0oOOo0O0Ooo - OoooooooOO * O0 * OoooooooOO
if 60 - 60: iIii1I11I1II1 / i1IIi * oO0o - I1ii11iIi11i + o0oOOo0O0Ooo
if 94 - 94: i1IIi % Oo0Ooo
if 68 - 68: Ii1I / O0
if 46 - 46: O0 * II111iiii / IiII * Oo0Ooo * iII111i . I11i
if 62 - 62: i11iIiiIii - II111iiii % I1Ii111 - iIii1I11I1II1 . I1ii11iIi11i . II111iiii
if 61 - 61: oO0o / OoOoOO00 / iII111i * OoO0O00 . II111iiii
if 1 - 1: II111iiii - I1ii11iIi11i % i11iIiiIii + IiII . I1Ii111
if 55 - 55: iIii1I11I1II1 - I1IiiI . Ii1I * IiII * i1IIi / iIii1I11I1II1
import sys
import urlparse
import urllib , urllib2 , datetime , re , os , base64 , xbmc , xbmcplugin , xbmcgui , xbmcaddon , xbmcvfs , traceback , cookielib , urlparse , httplib , time
import urlresolver , yt
import time
from t0mm0 . common . addon import Addon
from t0mm0 . common . net import Net
from datetime import datetime
if 79 - 79: oO0o + I1Ii111 . ooOoO0o * IiII % I11i . I1IiiI
O0o0o00o0Oo0 = xbmcgui . Dialog ( )
ii11 = base64 . decodestring
I1I1i1 = ii11 ( 'LnBocA==' )
IiI1i = ( ii11 ( 'aHR0cDovL3d3dy5jb3VjaHRyaXBwZXIuY29tL2ZvcnVtMi9wYWdlLnBocD9wYWdlPTM=' ) )
OOo0o0 = 'plugin.video.getupstandup'
O0OoOoo00o = sys . argv [ 0 ]
iiiI11 = int ( sys . argv [ 1 ] )
OOooO = urlparse . parse_qs ( sys . argv [ 2 ] [ 1 : ] )
OOoO00o = "Get Up - Stand Up"
II111iiiiII = "1.0.1"
oOoOo00oOo = 'Mozilla/5.0 (Windows NT 6.1; WOW64; Trident/7.0; AS; rv:11.0) like Gecko'
Oo = 'Mozilla/5.0 (Windows NT 6.3; rv:36.0) Gecko/20100101 Firefox/36.0'
o00O00O0O0O = 'Mozilla/5.0 (iPhone; CPU iPhone OS 6_0 like Mac OS X) AppleWebKit/536.26 (KHTML, like Gecko) Version/6.0 Mobile/10A5376e Safari/8536.25'
OooO0OO = 'Mozilla/5.0 (Linux; Android 4.4.2; Nexus 4 Build/KOT49H) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/34.0.1847.114 Mobile Safari/537.36'
if 28 - 28: II111iiii
iii11iII = xbmc . translatePath ( os . path . join ( 'special://home' , 'addons' , '' ) )
i1I111I = os . path . join ( iii11iII , OOo0o0 , 'resources' , 'art' ) + os . sep
i11I1IIiiIi = xbmc . translatePath ( os . path . join ( iii11iII , OOo0o0 , 'fanart.jpg' ) )
IiIiIi = i1I111I + 'icon.png'
if 40 - 40: oO0o . OoOoOO00 . Oo0Ooo . i1IIi
def I11iii ( ) :
 if 54 - 54: OOooOOo + OOooOOo % I1Ii111 % i11iIiiIii / iIii1I11I1II1 . OOooOOo
 o0oO0o00oo ( 'Stand Up' , '' , 1 , IiIiIi , i11I1IIiiIi , '' )
 o0oO0o00oo ( 'Search Comedian' , '' , 2 , IiIiIi , i11I1IIiiIi , '' )
 if 32 - 32: Oo0Ooo * O0 % oO0o % Ii1I . IiII
def o0OOOOO00o0O0 ( ) :
 o0o0OOO0o0 = O0o0o00o0Oo0 . input ( 'Search' , type = xbmcgui . INPUT_ALPHANUM )
 ooOOOo0oo0O0 = o0o0OOO0o0 . lower ( )
 o0 = I11II1i ( IiI1i )
 IIIII = re . compile ( '<tr>.+?<td width=".+?" align=".+?">.+?<img border=".+?" src="..(.+?)" width=".+?" height=".+?"></td>.+?<td width=".+?" valign=".+?" align=".+?"><font size=".+?">(.+?)</font></td>.+?<td width=".+?">(.+?)</td>' , re . DOTALL ) . findall ( o0 )
 for ooooooO0oo , IIiiiiiiIi1I1 , I1IIIii in IIIII :
  for o0o0OOO0o0 in IIiiiiiiIi1I1 :
   print '<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< img >>>>>>>>>>>>>>>>>>>>>>>>>>'
   oOoOooOo0o0 = re . compile ( '<a href="(.+?)">(.+?)</a>' , re . DOTALL ) . findall ( I1IIIii )
   for OOOO , OOO00 in oOoOooOo0o0 :
    if 'tube' in OOOO :
     pass
    elif 'stage' in OOOO :
     iiiiiIIii ( IIiiiiiiIi1I1 + '   -   ' + OOO00 , ( OOOO ) . replace ( '" target="_blank' , '' ) , 3 , 'http://couchtripper.com/' + ooooooO0oo , i11I1IIiiIi , '' )
    elif 'vee' in OOOO :
     pass
     if 71 - 71: OOooOOo + Ii1I * OOooOOo - OoO0O00 * o0oOOo0O0Ooo
def Oooo0Ooo000 ( ) :
 o0 = I11II1i ( IiI1i )
 IIIII = re . compile ( '<tr>.+?<td width=".+?" align=".+?">.+?<img border=".+?" src="..(.+?)" width=".+?" height=".+?"></td>.+?<td width=".+?" valign=".+?" align=".+?"><font size=".+?">(.+?)</font></td>.+?<td width=".+?">(.+?)</td>' , re . DOTALL ) . findall ( o0 )
 for ooooooO0oo , IIiiiiiiIi1I1 , I1IIIii in IIIII :
  print '<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< img >>>>>>>>>>>>>>>>>>>>>>>>>>'
  oOoOooOo0o0 = re . compile ( '<a href="(.+?)">(.+?)</a>' , re . DOTALL ) . findall ( I1IIIii )
  for OOOO , OOO00 in oOoOooOo0o0 :
   if 'tube' in OOOO :
    pass
   elif 'stage' in OOOO :
    iiiiiIIii ( IIiiiiiiIi1I1 + '   -   ' + OOO00 , ( OOOO ) . replace ( '" target="_blank' , '' ) , 3 , 'http://couchtripper.com/' + ooooooO0oo , i11I1IIiiIi , '' )
   elif 'vee' in OOOO :
    pass
    if 51 - 51: i11iIiiIii . I1IiiI + II111iiii
    if 10 - 10: I1ii11iIi11i * ooOoO0o * II111iiii % Ii1I . OOooOOo + I1Ii111
 xbmcplugin . addSortMethod ( iiiI11 , xbmcplugin . SORT_METHOD_TITLE ) ;
 if 19 - 19: OoOoOO00 - I1IiiI . OOooOOo / IiII
def I11II ( url ) :
 o0 = I11II1i ( url )
 print '>>>>>>>>>>>>>>>>>>>>>>>>' + url + '<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<'
 iII1IIIiI1I1i = re . compile ( "url\[.+?\] = '(.+?)';" ) . findall ( o0 )
 print '>>>>>>>>>>>>>>>>>>>>>>>' + ( str ( iII1IIIiI1I1i ) ) + '>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>'
 for url in iII1IIIiI1I1i :
  O0o0Ooo ( ( url ) . replace ( '[' , '' ) . replace ( ']' , '' ) . replace ( '\'' , '' ) )
  if 56 - 56: ooOoO0o . OoOoOO00 * iII111i . OoOoOO00
def iiiiiIIii ( name , url , mode , iconimage , fanart , description ) :
 if 72 - 72: iII111i / i1IIi * Oo0Ooo - I1Ii111
 Oo0O0O0ooO0O = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage ) + "&fanart=" + urllib . quote_plus ( fanart ) + "&description=" + urllib . quote_plus ( description )
 IIIIii = True
 O0o0 = xbmcgui . ListItem ( name , iconImage = "DefaultFolder.png" , thumbnailImage = iconimage )
 O0o0 . setInfo ( type = "Video" , infoLabels = { "Title" : name , "Plot" : description } )
 O0o0 . setProperty ( "Fanart_Image" , fanart )
 IIIIii = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = Oo0O0O0ooO0O , listitem = O0o0 , isFolder = False )
 return IIIIii
 if 71 - 71: OOooOOo + ooOoO0o % i11iIiiIii + I1ii11iIi11i - IiII
def o0oO0o00oo ( name , url , mode , iconimage , fanart , description ) :
 if 88 - 88: OoOoOO00 - OoO0O00 % OOooOOo
 Oo0O0O0ooO0O = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage ) + "&fanart=" + urllib . quote_plus ( fanart ) + "&description=" + urllib . quote_plus ( description )
 IIIIii = True
 O0o0 = xbmcgui . ListItem ( name , iconImage = "DefaultFolder.png" , thumbnailImage = iconimage )
 O0o0 . setInfo ( type = "Video" , infoLabels = { "Title" : name , "Plot" : description } )
 O0o0 . setProperty ( "Fanart_Image" , fanart )
 IIIIii = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = Oo0O0O0ooO0O , listitem = O0o0 , isFolder = True )
 return IIIIii
 if 16 - 16: I1IiiI * oO0o % IiII
def Oo000o ( ) :
 try :
  I11IiI1I11i1i = getSet ( "core-player" )
  if ( I11IiI1I11i1i == 'DVDPLAYER' ) : iI1ii1Ii = xbmc . PLAYER_CORE_DVDPLAYER
  elif ( I11IiI1I11i1i == 'MPLAYER' ) : iI1ii1Ii = xbmc . PLAYER_CORE_MPLAYER
  elif ( I11IiI1I11i1i == 'PAPLAYER' ) : iI1ii1Ii = xbmc . PLAYER_CORE_PAPLAYER
  else : iI1ii1Ii = xbmc . PLAYER_CORE_AUTO
 except : iI1ii1Ii = xbmc . PLAYER_CORE_AUTO
 return iI1ii1Ii
 return True
 if 92 - 92: OoOoOO00
 if 26 - 26: iII111i . I1Ii111
def oOOOOo0 ( ) :
 iiII1i1 = [ ]
 o00oOO0o = sys . argv [ 2 ]
 if len ( o00oOO0o ) >= 2 :
  OOO00O = sys . argv [ 2 ]
  OOoOO0oo0ooO = OOO00O . replace ( '?' , '' )
  if ( OOO00O [ len ( OOO00O ) - 1 ] == '/' ) :
   OOO00O = OOO00O [ 0 : len ( OOO00O ) - 2 ]
  O0o0O00Oo0o0 = OOoOO0oo0ooO . split ( '&' )
  iiII1i1 = { }
  for O00O0oOO00O00 in range ( len ( O0o0O00Oo0o0 ) ) :
   i1 = { }
   i1 = O0o0O00Oo0o0 [ O00O0oOO00O00 ] . split ( '=' )
   if ( len ( i1 ) ) == 2 :
    iiII1i1 [ i1 [ 0 ] ] = i1 [ 1 ]
    if 57 - 57: O0 / I1Ii111 % OoO0O00 / I1Ii111 . OoOoOO00 / O0
 return iiII1i1
 if 89 - 89: OoOoOO00
OOO00O = oOOOOo0 ( )
OOOO = None
OOO00 = None
OO0oOoOO0oOO0 = None
oO0OOoo0OO = None
O0ii1ii1ii = None
if 91 - 91: IiII
if 15 - 15: II111iiii
try :
 OOOO = urllib . unquote_plus ( OOO00O [ "url" ] )
except :
 pass
try :
 OOO00 = urllib . unquote_plus ( OOO00O [ "name" ] )
except :
 pass
try :
 OO0oOoOO0oOO0 = urllib . unquote_plus ( OOO00O [ "iconimage" ] )
except :
 pass
try :
 oO0OOoo0OO = int ( OOO00O [ "mode" ] )
except :
 pass
try :
 Ii = urllib . unquote_plus ( OOO00O [ "fanart" ] )
except :
 pass
try :
 O0ii1ii1ii = urllib . unquote_plus ( OOO00O [ "description" ] )
except :
 pass
 if 79 - 79: OoooooooOO / O0
 if 75 - 75: OoOoOO00 % o0oOOo0O0Ooo % o0oOOo0O0Ooo . I1Ii111
print str ( OOoO00o ) + ': ' + str ( II111iiiiII )
print "Mode: " + str ( oO0OOoo0OO )
print "URL: " + str ( OOOO )
print "Name: " + str ( OOO00 )
print "IconImage: " + str ( OO0oOoOO0oOO0 )
if 5 - 5: o0oOOo0O0Ooo * ooOoO0o + OoOoOO00 . OOooOOo + OoOoOO00
def O0o0Ooo ( url ) :
 oO = xbmc . Player ( Oo000o ( ) )
 import urlresolver
 try : oO . play ( url )
 except : pass
 if 7 - 7: o0oOOo0O0Ooo - I1IiiI
def I11II1i ( url ) :
 OOo00O0 = urllib2 . Request ( url )
 oOoOo00oOo = 'Mozilla/5.0 (Windows NT 6.1; WOW64; Trident/7.0; AS; rv:11.0) like Gecko'
 Oo = 'Mozilla/5.0 (Windows NT 6.3; rv:36.0) Gecko/20100101 Firefox/36.0'
 o00O00O0O0O = 'Mozilla/5.0 (iPhone; CPU iPhone OS 6_0 like Mac OS X) AppleWebKit/536.26 (KHTML, like Gecko) Version/6.0 Mobile/10A5376e Safari/8536.25'
 OooO0OO = 'Mozilla/5.0 (Linux; Android 4.4.2; Nexus 4 Build/KOT49H) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/34.0.1847.114 Mobile Safari/537.36'
 OOo00O0 . add_header ( 'User-Agent' , 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3' )
 ooOOOoO = urllib2 . urlopen ( OOo00O0 )
 o0o = ooOOOoO . read ( )
 ooOOOoO . close ( )
 return o0o
 if 84 - 84: O0
def OOOooOO0 ( content , viewType ) :
 if content :
  xbmcplugin . setContent ( int ( sys . argv [ 1 ] ) , content )
  if 87 - 87: oO0o * I1ii11iIi11i + OOooOOo / iIii1I11I1II1 / iII111i
  if 37 - 37: iII111i - ooOoO0o * oO0o % i11iIiiIii - I1Ii111
if oO0OOoo0OO == None : Oooo0Ooo000 ( )
elif oO0OOoo0OO == 2 : o0OOOOO00o0O0 ( )
elif oO0OOoo0OO == 3 : I11II ( OOOO )
elif oO0OOoo0OO == 5 : O0o0Ooo ( OOOO )
elif oO0OOoo0OO == 9 : yt . PlayVideo ( OOOO )
if 83 - 83: I11i / I1IiiI
xbmcplugin . endOfDirectory ( int ( sys . argv [ 1 ] ) )
# dd678faae9ac167bc83abf78e5cb2f3f0688d3a3
