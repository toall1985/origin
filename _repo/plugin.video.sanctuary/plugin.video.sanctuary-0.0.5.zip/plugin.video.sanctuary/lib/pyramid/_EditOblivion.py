import base64

MainBase = base64.decodestring('aHR0cDovL3Zwcy5vYmxpdmlvbmJ1aWxkcy5jb20vRnJlZS54bWw=')
