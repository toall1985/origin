import xbmcaddon

MainBase = 'http://www.kodeeresurrection.com/TigensWorldtxt/home.txt'
addon = xbmcaddon.Addon('plugin.video.sanctuary')