MainBase = 'https://www.dropbox.com/s/iq4nogib32nnchd/BAMF%20IPTV.txt?dl=1'
