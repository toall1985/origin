MainBase = 'https://www.dropbox.com/s/trn3seigs0ptgkc/BAMF.xml?dl=1'
