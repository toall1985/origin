MainBase = 'http://vps.oblivionbuilds.com/Free.xml'
