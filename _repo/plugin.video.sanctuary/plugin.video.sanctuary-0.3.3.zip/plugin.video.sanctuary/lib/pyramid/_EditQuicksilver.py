MainBase = 'http://quicksilver-music.com/addoncore/Texts/home.txt'
